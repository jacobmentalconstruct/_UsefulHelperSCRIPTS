import os
import shutil
import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext
from datetime import datetime

# Palette
BG = "#1e1e2e"
BG2 = "#2a2a3e"
FG = "#cdd6f4"
ACCENT = "#7c6af7"
ACCENT_SUCCESS = "#a6e3a1"


class ChatPanel(tk.Frame):
    """A reusable chat column with an integrated Ollama model selector."""
    def __init__(self, parent, on_submit_callback, **kwargs):
        super().__init__(parent, bg=BG2, **kwargs)
        self.on_submit = on_submit_callback
        
        # Initialize the Microservice (Uncomment when ready to link)
        # self.model_selector = OllamaModelSelectorMS()
        self.current_model = tk.StringVar(value="Loading models...")

        self._build_ui()
        self._fetch_models()

    def _build_ui(self):
        # Header Frame
        header = tk.Frame(self, bg=BG2)
        header.pack(fill="x", padx=10, pady=(10, 5))

        tk.Label(header, text="AI Assistant", bg=BG2, fg=ACCENT, font=("Segoe UI Semibold", 10)).pack(side="left")

        # Ollama Model Picker
        self.model_combo = ttk.Combobox(header, textvariable=self.current_model, state="readonly", width=15)
        self.model_combo.pack(side="right")
        self.model_combo.bind("<<ComboboxSelected>>", self._on_model_change)

        # Chat History
        self.history = scrolledtext.ScrolledText(self, bg=BG, fg=FG, font=("Consolas", 9), state="disabled", wrap="word")
        self.history.pack(fill="both", expand=True, padx=10, pady=5)

        # Input Area
        self.input_box = tk.Text(self, bg=BG, fg=FG, font=("Consolas", 10), height=4, wrap="word")
        self.input_box.pack(fill="x", padx=10, pady=(0, 5))
        self.input_box.bind("<Return>", self._handle_return)

        # Submit Button
        tk.Button(self, text="Send", bg=ACCENT, fg="white", relief="flat", command=self._submit).pack(side="right", padx=10, pady=(0, 10))

    def _fetch_models(self):
        """Fetches available local models from Ollama."""
        # TODO: Wire to the microservice
        # try:
        #     models = self.model_selector.list_models()
        #     if models:
        #         self.model_combo['values'] = models
        #         self.current_model.set(models[0])
        #     else:
        #         self.current_model.set("No models found")
        # except Exception as e:
        #     self.current_model.set("Ollama offline")
        
        # Placeholder for UI testing:
        dummy_models = ["llama3:8b", "phi3:mini", "mistral:instruct"]
        self.model_combo['values'] = dummy_models
        self.current_model.set(dummy_models[0])

    def _on_model_change(self, event):
        selected = self.current_model.get()
        self.append_message("System", f"Switched model to: {selected}")
        # self.model_selector.set_active_model(selected)

    def _handle_return(self, event):
        if not event.state & 0x0001:  # Shift not pressed
            self._submit()
            return "break"

    def _submit(self):
        user_text = self.input_box.get("1.0", tk.END).strip()
        if not user_text:
            return
            
        self.input_box.delete("1.0", tk.END)
        self.append_message("You", user_text)
        
        # Pass both the text and the chosen model to the orchestrator
        self.on_submit(user_text, self.current_model.get())

    def append_message(self, sender, text):
        self.history.config(state="normal")
        self.history.insert(tk.END, f"\n{sender}:\n{text}\n\n")
        self.history.see(tk.END)
        self.history.config(state="disabled")


class LiveViewer(tk.Toplevel):
    """A detached scratchpad window with live-reload and a toggleable chat panel."""
    def __init__(self, parent, file_path):
        super().__init__(parent)
        self.title(f"Scratchpad: {os.path.basename(file_path)}")
        self.geometry("1000x700")
        self.configure(bg=BG)
        
        self.file_path = file_path
        self.last_mtime = 0
        self.is_dirty = False # Tracks unsaved changes
        self.chat_visible = False

        self._build_ui()
        self._check_for_updates()

    def _build_ui(self):
        # 1. Toolbar
        toolbar = tk.Frame(self, bg=BG2, pady=5)
        toolbar.pack(fill="x", side="top")

        self.btn_save = tk.Button(toolbar, text="💾 Save Changes", bg=BG2, fg=FG, relief="flat", command=self._save_file)
        self.btn_save.pack(side="left", padx=10)

        self.backup_var = tk.BooleanVar(value=True)
        tk.Checkbutton(toolbar, text="Backup to _backupBIN on save", variable=self.backup_var, 
                       bg=BG2, fg=FG, selectcolor=BG, activebackground=BG2).pack(side="left", padx=10)

        self.status_lbl = tk.Label(toolbar, text="(Live Sync Active)", bg=BG2, fg=ACCENT_SUCCESS)
        self.status_lbl.pack(side="left", padx=20)

        tk.Button(toolbar, text="💬 Toggle Chat", bg=ACCENT, fg="white", relief="flat", 
                  command=self._toggle_chat).pack(side="right", padx=10)

        # 2. Main Area (PanedWindow allows user to resize the chat sidebar)
        self.paned = tk.PanedWindow(self, orient=tk.HORIZONTAL, bg=BG, sashwidth=4)
        self.paned.pack(fill="both", expand=True)

        # Left side: Text Editor
        self.text_area = scrolledtext.ScrolledText(self.paned, bg=BG, fg=FG, font=("Consolas", 10), wrap="none", undo=True)
        self.text_area.bind("<KeyPress>", self._mark_dirty)
        self.paned.add(self.text_area, stretch="always")

        # Right side: Chat Panel (Created but hidden initially)
        self.chat_panel = ChatPanel(self.paned, on_submit_callback=self._handle_chat_submit, width=350)

    def _mark_dirty(self, event=None):
        """Pauses live reload the moment the user types something."""
        # Ignore modifier keys that don't change text
        if event and event.keysym in ("Shift_L", "Shift_R", "Control_L", "Control_R", "Alt_L", "Alt_R", "Caps_Lock"):
            return
            
        if not self.is_dirty:
            self.is_dirty = True
            self.status_lbl.config(text="✏️ Unsaved Changes (Live Sync Paused)", fg="#f38ba8")
            self.btn_save.config(bg=ACCENT, fg="white")

    def _toggle_chat(self):
        if self.chat_visible:
            self.paned.remove(self.chat_panel)
            self.chat_visible = False
        else:
            self.paned.add(self.chat_panel, stretch="never")
            self.chat_visible = True

    def _handle_chat_submit(self, text):
        """This is the placeholder hook for your AI logic."""
        # Echo response for now
        self.chat_panel.append_message("System", f"Message received. Waiting for AI integration hooks.")

    def _save_file(self):
        """Handles backups and saving the scratchpad back to disk."""
        content = self.text_area.get("1.0", tk.END).rstrip("\n") # ScrolledText adds an extra newline

        # Handle Auto-Archive / Backup
        if self.backup_var.get() and os.path.exists(self.file_path):
            backup_dir = os.path.join(os.path.dirname(self.file_path), "_backupBIN")
            os.makedirs(backup_dir, exist_ok=True)
            
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            base, ext = os.path.splitext(os.path.basename(self.file_path))
            backup_path = os.path.join(backup_dir, f"{base}_{timestamp}{ext}")
            
            shutil.copy2(self.file_path, backup_path)
            print(f"Archived previous version to {backup_path}")

        # Save to disk
        with open(self.file_path, "w", encoding="utf-8") as f:
            f.write(content)

        # Reset states so live polling can safely resume
        self.is_dirty = False
        self.last_mtime = os.path.getmtime(self.file_path)
        self.status_lbl.config(text="✓ Saved (Live Sync Active)", fg=ACCENT_SUCCESS)
        self.btn_save.config(bg=BG2, fg=FG)

    def _check_for_updates(self):
        """Polls the file system, but ONLY reloads if there are no unsaved changes."""
        if not self.is_dirty:
            try:
                current_mtime = os.path.getmtime(self.file_path)
                if current_mtime > self.last_mtime:
                    self._reload_file()
                    self.last_mtime = current_mtime
            except FileNotFoundError:
                pass # Handled on next save
            
        self.after(1000, self._check_for_updates)

    def _reload_file(self):
        scroll_pos = self.text_area.yview()
        with open(self.file_path, "r", encoding="utf-8") as f:
            content = f.read()
            
        self.text_area.delete("1.0", tk.END)
        self.text_area.insert("1.0", content)
        self.text_area.yview_moveto(scroll_pos[0])

class DismantlerHub(tk.Tk):
    """The main control panel for your refactoring tools."""
    def __init__(self):
        super().__init__()
        self.title("God Object Dismantler")
        self.geometry("400x300")
        self.configure(bg=BG)
        
        self.target_file = None
        self.viewer_window = None

        self._build_ui()

    def _build_ui(self):
        # File Selection
        tk.Label(self, text="Target File:", bg=BG, fg=FG).pack(pady=(20, 5))
        
        self.file_lbl = tk.Label(self, text="(No file loaded)", bg=BG2, fg=FG, width=40)
        self.file_lbl.pack(pady=5)
        
        tk.Button(self, text="Browse / Load File", bg=ACCENT, fg="white", 
                  relief="flat", command=self._load_file).pack(pady=10)

        # Tools Section (The Bakery)
        tk.Frame(self, bg=FG, height=1).pack(fill="x", padx=20, pady=20)
        tk.Label(self, text="Curator Tools", bg=BG, fg=FG).pack(pady=5)

        self.btn_ast_marker = tk.Button(
            self, text="1. Run AST + AI Auto-Marker", bg=BG2, fg=FG, relief="flat",
            state="disabled", command=self._run_ast_tool
        )
        self.btn_ast_marker.pack(pady=5, fill="x", padx=50)

    def _load_file(self):
        file_path = filedialog.askopenfilename(filetypes=[("Python Files", "*.py"), ("All Files", "*.*")])
        if not file_path:
            return
            
        self.target_file = file_path
        self.file_lbl.config(text=os.path.basename(file_path))
        self.btn_ast_marker.config(state="normal")
        
        # Spawn or update the viewer
        if self.viewer_window and tk.Toplevel.winfo_exists(self.viewer_window):
            self.viewer_window.destroy()
        
        self.viewer_window = LiveViewer(self, self.target_file)

    def _run_ast_tool(self):
        """This is where you plug in your custom tools."""
        if not self.target_file:
            return
        
        print(f"Running AST tool on {self.target_file}...")
        # TODO: Import your AST tool here.
        # example: ast_marker.process_file(self.target_file)
        
        messagebox.showinfo("Tool Finished", "AST markup complete! Viewer should auto-refresh.")

if __name__ == "__main__":
    app = DismantlerHub()
    app.mainloop()