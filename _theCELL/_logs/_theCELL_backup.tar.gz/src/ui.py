import tkinter as tk
from tkinter import ttk, messagebox

class CELL_UI:
    def __init__(self, shell, backend):
        self.shell = shell
        self.backend = backend
        self.container = shell.get_main_container() # [cite: 104]
        self.colors = shell.colors # [cite: 102]
        
        self._setup_main_window()
        self._build_context_menu()

    def _setup_main_window(self):
        # --- Top Label ---
        tk.Label(self.container, text="Type in your idea HERE.", 
                 fg=self.colors.get('foreground'), bg=self.colors.get('background'),
                 font=("Segoe UI", 12, "bold")).pack(pady=(10, 5))

        # --- Formatting Toolbar ---
        toolbar = tk.Frame(self.container, bg=self.colors.get('panel_bg'))
        toolbar.pack(fill='x', padx=10)
        
        btn_opts = {"bg": self.colors.get('panel_bg'), "fg": "white", "relief": "flat", "padx": 5}
        tk.Button(toolbar, text="B", font=("TkDefaultFont", 9, "bold"), **btn_opts, command=self._bold_text).pack(side='left')
        tk.Button(toolbar, text="I", font=("TkDefaultFont", 9, "italic"), **btn_opts, command=self._italic_text).pack(side='left')
        tk.Button(toolbar, text="• List", **btn_opts, command=self._bullet_list).pack(side='left')
        
        # Gear Icon for Settings (Unicode placeholder)
        tk.Button(toolbar, text="⚙", **btn_opts, command=self._open_settings).pack(side='right')

        # --- Main Input Box ---
        self.input_box = tk.Text(self.container, undo=True, wrap="word",
                                 bg="#252526", fg="#d4d4d4", 
                                 insertbackground="white", # Visible blinking cursor
                                 selectbackground="#264f78", # Highlight color
                                 font=("Consolas", 11))
        self.input_box.pack(fill='both', expand=True, padx=10, pady=5)
        self.input_box.focus_set()

        # --- Inference Config Bar ---
        config_bar = tk.Frame(self.container, bg=self.colors.get('background'))
        config_bar.pack(fill='x', padx=10, pady=10)

        self.model_var = tk.StringVar()
        model_dropdown = ttk.Combobox(config_bar, textvariable=self.model_var)
        model_dropdown['values'] = self.backend.get_models()
        model_dropdown.pack(side='left', padx=5)

        tk.Button(config_bar, text="Set System Role", command=self._open_role_popup).pack(side='left', padx=5)
        
        # --- Submit Button ---
        tk.Button(self.container, text="SUBMIT", bg="#007acc", fg="white", 
                  font=("Segoe UI", 10, "bold"), command=self._submit).pack(fill='x', padx=10, pady=(0, 10))

    # --- UI Logic Stubs ---
    def _apply_markdown_style(self, prefix, suffix=""):
        """Wraps selected text in Markdown markers for AI readability."""
        try:
            start = self.input_box.index("sel.first")
            end = self.input_box.index("sel.second")
            selected_text = self.input_box.get(start, end)
            self.input_box.delete(start, end)
            self.input_box.insert(start, f"{prefix}{selected_text}{suffix or prefix}")
        except tk.TclError:
            pass

    def _bold_text(self):
        self._apply_markdown_style("**")

    def _italic_text(self):
        self._apply_markdown_style("_")

    def _bullet_list(self):
        """Converts selected lines into a Markdown bulleted list."""
        try:
            start = self.input_box.index("sel.first linestart")
            end = self.input_box.index("sel.second lineend")
            lines = self.input_box.get(start, end).splitlines()
            bulleted_lines = [f"* {line.lstrip('* ')}" for line in lines]
            self.input_box.delete(start, end)
            self.input_box.insert(start, "\n".join(bulleted_lines))
        except tk.TclError:
            self.input_box.insert("insert", "* ")

    def _open_settings(self):
        settings = tk.Toplevel(self.shell.root)
        settings.title("Settings")
        settings.geometry("300x200")
        tk.Label(settings, text="Theme:").pack()
        ttk.Combobox(settings, values=["Dark", "Light"]).pack()
        tk.Label(settings, text="Window Size:").pack()
        tk.Entry(settings).pack() # Width x Height

    def _open_role_popup(self):
        role_win = tk.Toplevel(self.shell.root)
        role_win.title("System Role")
        role_text = tk.Text(role_win, height=5)
        role_text.insert("1.0", self.backend.system_role)
        role_text.pack()
        tk.Button(role_win, text="Save", command=lambda: self.backend.set_system_role(role_text.get("1.0", "end-1c"))).pack()

    def _build_context_menu(self):
        self.menu = tk.Menu(self.input_box, tearoff=0)
        self.menu.add_command(label="Cut", command=lambda: self.input_box.event_generate("<<Cut>>"))
        self.menu.add_command(label="Copy", command=lambda: self.input_box.event_generate("<<Copy>>"))
        self.menu.add_command(label="Paste", command=lambda: self.input_box.event_generate("<<Paste>>"))
        self.input_box.bind("<Button-3>", lambda e: self.menu.post(e.x_root, e.y_root))

    def _submit(self):
        content = self.input_box.get("1.0", "end-1c")
        model = self.model_var.get()
        self.backend.process_submission(content, model)
