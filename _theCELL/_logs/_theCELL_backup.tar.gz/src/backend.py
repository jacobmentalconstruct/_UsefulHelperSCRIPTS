from src.microservices._IngestEngineMS import IngestEngineMS

class Backend:
    def __init__(self):
        # Use the existing IngestEngine to talk to Ollama [cite: 46]
        self.engine = IngestEngineMS()
        self.system_role = "You are a helpful AI assistant."

    def get_models(self):
        """Fetches available Ollama models."""
        models = self.engine.get_available_models()
        return models if models else ["No Models Found"]

    def set_system_role(self, role_text):
        self.system_role = role_text

    def process_submission(self, content, model):
        """
        Refined submission logic.
        1. Strips UI-only whitespace.
        2. Prepared for Cognitive Memory short-term persistence.
        """
        clean_content = content.strip()
        
        # Debug indicators
        print(f"[SENT TO MEMORY] Role: {self.system_role}")
        print(f"[INFERENCE] Model: {model}")
        print(f"[CONTENT] {clean_content[:50]}...")
