#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
== TokenizingPATCHER Patchwright (Prototype) ==

Tkinter app that runs HITL tasklists (chained inference cycles) against:
- target file text
- snippet text
- existing patch JSON + error log

Guarantees final output is a schema-valid TokenizingPATCHER patch JSON.

Entry modes:
- GUI: `py -m src.app`
- CLI: `py -m src.app validate --patch patch.json --target file.py`
"""

# 1. IMPORTS
import sys
import os
import argparse
import json
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

# Local imports
from src._microservices.state import new_state
from src._microservices.tasklists import get_tasklist_names, load_tasklist_by_name
from src._microservices.runner import run_tasklist
from src._microservices.patch_validators import (
    validate_patch_schema_strict,
    check_search_blocks_exist,
)

# 2. CONSTANTS
APP_TITLE = "Patchwright (TokenizingPATCHER) - Prototype"
DARK_BG = "#0f1115"
DARK_FG = "#e7e7e7"
PANEL_BG = "#141822"
ENTRY_BG = "#0b0e14"
ACCENT = "#2a6ef2"


# -----------------------------
# 3. CORE FUNCTIONALITY (Importable)
# -----------------------------

def run_cli_validate(patch_text: str, target_text: str, require_match: bool) -> dict:
    """CLI helper: validate + (optionally) require search_block substring matches."""
    ok, errs = validate_patch_schema_strict(patch_text)
    if not ok:
        return {"ok": False, "stage": "schema", "errors": errs}

    if require_match:
        patch_obj = json.loads(patch_text)
        found, missing = check_search_blocks_exist(target_text, patch_obj)
        if missing:
            return {"ok": False, "stage": "match", "missing_hunks": missing, "found_hunks": found}

    return {"ok": True}


# -----------------------------
# 4. TKINTER UI
# -----------------------------

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_TITLE)
        self.configure(bg=DARK_BG)
        self.geometry("1400x850")

        self.state = new_state()

        self._build_style()
        self._build_layout()
        self._load_tasklist_choices()

    def _build_style(self):
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass

        style.configure("TFrame", background=DARK_BG)
        style.configure("Panel.TFrame", background=PANEL_BG)
        style.configure("TLabel", background=PANEL_BG, foreground=DARK_FG)
        style.configure("Header.TLabel", background=PANEL_BG, foreground=DARK_FG, font=("Segoe UI", 11, "bold"))
        style.configure("TButton", font=("Segoe UI", 10))
        style.configure("Accent.TButton", foreground=DARK_FG)

    def _build_layout(self):
        # Main grid: Inputs | Tasklist | Output/State
        self.columnconfigure(0, weight=3)
        self.columnconfigure(1, weight=2)
        self.columnconfigure(2, weight=3)
        self.rowconfigure(0, weight=1)

        self.inputs_panel = ttk.Frame(self, style="Panel.TFrame", padding=10)
        self.task_panel = ttk.Frame(self, style="Panel.TFrame", padding=10)
        self.output_panel = ttk.Frame(self, style="Panel.TFrame", padding=10)

        self.inputs_panel.grid(row=0, column=0, sticky="nsew", padx=8, pady=8)
        self.task_panel.grid(row=0, column=1, sticky="nsew", padx=8, pady=8)
        self.output_panel.grid(row=0, column=2, sticky="nsew", padx=8, pady=8)

        self._build_inputs_panel()
        self._build_task_panel()
        self._build_output_panel()

    # ---------- Inputs ----------
    def _build_inputs_panel(self):
        p = self.inputs_panel
        p.rowconfigure(1, weight=1)
        p.rowconfigure(3, weight=1)
        p.rowconfigure(5, weight=1)

        ttk.Label(p, text="Inputs", style="Header.TLabel").grid(row=0, column=0, sticky="w")

        # Target file
        bar1 = ttk.Frame(p, style="Panel.TFrame")
        bar1.grid(row=0, column=1, sticky="e")
        ttk.Button(bar1, text="Load Target File", command=self._load_target_file).pack(side="left", padx=4)
        ttk.Button(bar1, text="Clear", command=lambda: self._set_text(self.target_txt, "")).pack(side="left", padx=4)

        self.target_txt = self._make_text(p)
        self.target_txt.grid(row=1, column=0, columnspan=2, sticky="nsew", pady=(6, 10))
        self._label_above(p, "Target file text", row=1)

        # Snippet
        ttk.Label(p, text="Snippet text", style="TLabel").grid(row=2, column=0, sticky="w")
        self.snippet_txt = self._make_text(p, height=8)
        self.snippet_txt.grid(row=3, column=0, columnspan=2, sticky="nsew", pady=(6, 10))

        # Existing patch + error log
        ttk.Label(p, text="Existing patch JSON (optional)", style="TLabel").grid(row=4, column=0, sticky="w")
        bar2 = ttk.Frame(p, style="Panel.TFrame")
        bar2.grid(row=4, column=1, sticky="e")
        ttk.Button(bar2, text="Load Patch JSON", command=self._load_patch_file).pack(side="left", padx=4)

        self.patch_txt = self._make_text(p, height=10)
        self.patch_txt.grid(row=5, column=0, columnspan=2, sticky="nsew", pady=(6, 10))

        ttk.Label(p, text="Error log (optional)", style="TLabel").grid(row=6, column=0, sticky="w")
        self.err_txt = self._make_text(p, height=6)
        self.err_txt.grid(row=7, column=0, columnspan=2, sticky="nsew", pady=(6, 0))

        p.rowconfigure(7, weight=1)

    # ---------- Tasklist ----------
    def _build_task_panel(self):
        p = self.task_panel
        p.columnconfigure(0, weight=1)
        p.rowconfigure(3, weight=1)

        ttk.Label(p, text="Tasklists (HITL)", style="Header.TLabel").grid(row=0, column=0, sticky="w")

        # Mode + tasklist picker
        top = ttk.Frame(p, style="Panel.TFrame")
        top.grid(row=1, column=0, sticky="ew", pady=(8, 8))
        top.columnconfigure(1, weight=1)

        ttk.Label(top, text="Mode:", style="TLabel").grid(row=0, column=0, sticky="w")
        self.mode_var = tk.StringVar(value="validate_patch")
        mode = ttk.Combobox(top, textvariable=self.mode_var, state="readonly",
                            values=["validate_patch", "repair_patch", "create_patch"])
        mode.grid(row=0, column=1, sticky="ew", padx=(6, 0))
        mode.bind("<<ComboboxSelected>>", lambda _e: self._load_tasklist_choices())

        ttk.Label(top, text="Tasklist:", style="TLabel").grid(row=1, column=0, sticky="w", pady=(8, 0))
        self.tasklist_var = tk.StringVar(value="")
        self.tasklist_combo = ttk.Combobox(top, textvariable=self.tasklist_var, state="readonly", values=[])
        self.tasklist_combo.grid(row=1, column=1, sticky="ew", padx=(6, 0), pady=(8, 0))
        self.tasklist_combo.bind("<<ComboboxSelected>>", lambda _e: self._render_tasklist_editor())

        # Buttons
        btns = ttk.Frame(p, style="Panel.TFrame")
        btns.grid(row=2, column=0, sticky="ew")
        ttk.Button(btns, text="Run All Steps", command=self._run_all).pack(side="left", padx=4)
        ttk.Button(btns, text="Validate Output", command=self._validate_output).pack(side="left", padx=4)
        ttk.Button(btns, text="Copy Final Patch", command=self._copy_final).pack(side="left", padx=4)

        # Tasklist editor (raw JSON)
        ttk.Label(p, text="Editable tasklist JSON", style="TLabel").grid(row=3, column=0, sticky="w", pady=(10, 0))
        self.task_json = self._make_text(p, height=22)
        self.task_json.grid(row=4, column=0, sticky="nsew", pady=(6, 0))
        p.rowconfigure(4, weight=1)

    # ---------- Output ----------
    def _build_output_panel(self):
        p = self.output_panel
        p.columnconfigure(0, weight=1)
        p.rowconfigure(1, weight=1)
        p.rowconfigure(3, weight=1)

        ttk.Label(p, text="Outputs", style="Header.TLabel").grid(row=0, column=0, sticky="w")

        ttk.Label(p, text="Final patch JSON (schema-valid)", style="TLabel").grid(row=0, column=0, sticky="e")

        self.final_txt = self._make_text(p, height=18)
        self.final_txt.grid(row=1, column=0, sticky="nsew", pady=(10, 10))

        ttk.Label(p, text="State (debug)", style="TLabel").grid(row=2, column=0, sticky="w")
        self.state_txt = self._make_text(p, height=18)
        self.state_txt.grid(row=3, column=0, sticky="nsew")

    # ---------- Helpers ----------
    def _make_text(self, parent, height=14):
        t = tk.Text(parent, height=height, wrap="none", bg=ENTRY_BG, fg=DARK_FG, insertbackground=DARK_FG,
                    relief="flat", undo=True)
        # simple scrollbars
        y = ttk.Scrollbar(parent, orient="vertical", command=t.yview)
        x = ttk.Scrollbar(parent, orient="horizontal", command=t.xview)
        t.configure(yscrollcommand=y.set, xscrollcommand=x.set)

        # grid them as an internal frame-like pack via place in caller? easiest: return just text,
        # and caller can add scrollbars manually if desired.
        # For prototype: keep it simple: no separate scrollbar widgets.
        return t

    def _label_above(self, parent, text, row):
        # Lightweight label placed just above the widget row
        # (Prototype: already labeled elsewhere; kept for future expansion)
        pass

    def _get_text(self, widget) -> str:
        return widget.get("1.0", "end-1c")

    def _set_text(self, widget, text: str):
        widget.delete("1.0", "end")
        widget.insert("1.0", text)

    def _sync_inputs_to_state(self):
        self.state["mode"] = self.mode_var.get()
        self.state["inputs"]["target_file_text"] = self._get_text(self.target_txt)
        self.state["inputs"]["snippet_text"] = self._get_text(self.snippet_txt)
        self.state["inputs"]["existing_patch_json"] = self._get_text(self.patch_txt)
        self.state["inputs"]["error_log_text"] = self._get_text(self.err_txt)

    def _render_state(self):
        self._set_text(self.state_txt, json.dumps(self.state, indent=2))

    def _load_target_file(self):
        path = filedialog.askopenfilename(title="Select target file")
        if not path:
            return
        try:
            with open(path, "r", encoding="utf-8") as f:
                self._set_text(self.target_txt, f.read())
            self.state["inputs"]["file_path"] = path
        except Exception as e:
            messagebox.showerror("Error", f"Failed to read file:\n{e}")

    def _load_patch_file(self):
        path = filedialog.askopenfilename(title="Select patch JSON file", filetypes=[("JSON", "*.json"), ("All", "*.*")])
        if not path:
            return
        try:
            with open(path, "r", encoding="utf-8") as f:
                self._set_text(self.patch_txt, f.read())
        except Exception as e:
            messagebox.showerror("Error", f"Failed to read patch:\n{e}")

    def _load_tasklist_choices(self):
        mode = self.mode_var.get()
        names = get_tasklist_names(mode)
        self.tasklist_combo.configure(values=names)
        if names:
            self.tasklist_var.set(names[0])
            self._render_tasklist_editor()

    def _render_tasklist_editor(self):
        mode = self.mode_var.get()
        name = self.tasklist_var.get()
        if not name:
            return
        tasklist = load_tasklist_by_name(mode, name)
        self._set_text(self.task_json, json.dumps(tasklist, indent=2))

    def _run_all(self):
        self._sync_inputs_to_state()

        # Parse edited tasklist JSON (HITL)
        try:
            tasklist = json.loads(self._get_text(self.task_json))
        except Exception as e:
            messagebox.showerror("Tasklist JSON Error", str(e))
            return

        try:
            # Runner returns updated state
            self.state = run_tasklist(self.state, tasklist)
        except Exception as e:
            messagebox.showerror("Run Error", str(e))
            self._render_state()
            return

        # Update outputs
        final_patch = self.state.get("outputs", {}).get("final_patch")
        if final_patch is not None:
            self._set_text(self.final_txt, json.dumps(final_patch, indent=2))
        self._render_state()

    def _validate_output(self):
        txt = self._get_text(self.final_txt).strip()
        if not txt:
            messagebox.showwarning("No Output", "Final patch output is empty.")
            return

        ok, errs = validate_patch_schema_strict(txt)
        if not ok:
            messagebox.showerror("Invalid Patch JSON", "\n".join(errs))
            return

        # Optional: search_block match check against target file
        try:
            patch_obj = json.loads(txt)
        except Exception:
            messagebox.showerror("Invalid JSON", "Final output is not valid JSON.")
            return

        target = self._get_text(self.target_txt)
        found, missing = check_search_blocks_exist(target, patch_obj)
        if missing:
            messagebox.showwarning("Search Blocks Missing",
                                   f"These hunks do NOT match target file: {missing}\nFound: {found}")
        else:
            messagebox.showinfo("Valid", "Patch is schema-valid and all search_blocks match the target.")

    def _copy_final(self):
        txt = self._get_text(self.final_txt)
        if not txt.strip():
            return
        self.clipboard_clear()
        self.clipboard_append(txt)
        self.update()
        messagebox.showinfo("Copied", "Final patch JSON copied to clipboard.")


# -----------------------------
# 5. CLI LOGIC (kept in your boilerplate style)
# -----------------------------

def main():
    parser = argparse.ArgumentParser(
        description="Patchwright: HITL tasklists for TokenizingPATCHER patches (GUI + CLI).",
        epilog="GUI: py -m src.app\nCLI validate: py -m src.app validate --patch patch.json --target file.py"
    )

    sub = parser.add_subparsers(dest="cmd")

    v = sub.add_parser("validate", help="Validate patch JSON (and optionally match search_block against target).")
    v.add_argument("--patch", type=str, required=True, help="Path to patch JSON file.")
    v.add_argument("--target", type=str, required=True, help="Path to target file.")
    v.add_argument("--require-match", action="store_true", help="Fail if any search_block is not found in target.")
    v.add_argument("--print-json", action="store_true", help="Print result JSON to stdout.")

    args = parser.parse_args()

    if args.cmd == "validate":
        with open(args.patch, "r", encoding="utf-8") as f:
            patch_text = f.read()
        with open(args.target, "r", encoding="utf-8") as f:
            target_text = f.read()

        result = run_cli_validate(patch_text, target_text, require_match=args.require_match)
        if args.print_json:
            print(json.dumps(result, indent=2))
        sys.exit(0 if result.get("ok") else 1)

    # Default: GUI
    app = App()
    app.mainloop()


if __name__ == "__main__":
    main()
