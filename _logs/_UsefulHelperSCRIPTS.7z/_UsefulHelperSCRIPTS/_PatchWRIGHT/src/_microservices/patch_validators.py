import json
from src._microservices.patch_schema import REQUIRED_TOP_KEY, REQUIRED_HUNK_KEYS

def validate_patch_schema_strict(patch_text: str):
    errors = []
    try:
        obj = json.loads(patch_text)
    except Exception as e:
        return False, [f"JSON parse failed: {e}"]

    # no extra keys
    if not isinstance(obj, dict):
        return False, ["Top-level JSON must be an object."]
    if list(obj.keys()) != [REQUIRED_TOP_KEY]:
        return False, [f"Top-level must have ONLY key '{REQUIRED_TOP_KEY}' (no extras)."]

    hunks = obj.get(REQUIRED_TOP_KEY)
    if not isinstance(hunks, list) or len(hunks) == 0:
        return False, ["'hunks' must be a non-empty array."]

    for i, h in enumerate(hunks):
        if not isinstance(h, dict):
            errors.append(f"Hunk {i}: must be an object.")
            continue
        if sorted(h.keys()) != sorted(REQUIRED_HUNK_KEYS):
            errors.append(f"Hunk {i}: must have ONLY keys {REQUIRED_HUNK_KEYS}.")
        if not isinstance(h.get("description"), str) or not h["description"].strip():
            errors.append(f"Hunk {i}: 'description' must be a non-empty string.")
        if not isinstance(h.get("search_block"), str):
            errors.append(f"Hunk {i}: 'search_block' must be a string.")
        if not isinstance(h.get("replace_block"), str):
            errors.append(f"Hunk {i}: 'replace_block' must be a string.")
        if not isinstance(h.get("use_patch_indent"), bool):
            errors.append(f"Hunk {i}: 'use_patch_indent' must be boolean (true/false).")

    return (len(errors) == 0), errors

def check_search_blocks_exist(target_text: str, patch_obj: dict):
    found = []
    missing = []
    hunks = patch_obj.get("hunks", [])
    for i, h in enumerate(hunks):
        sb = h.get("search_block", "")
        if sb and sb in target_text:
            found.append(i)
        else:
            missing.append(i)
    return found, missing
