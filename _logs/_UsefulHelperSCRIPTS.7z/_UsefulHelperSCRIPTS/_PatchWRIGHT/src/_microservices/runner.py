import json

from src._microservices.ollama_client import OllamaClient
from src._microservices.template_engine import resolve_template
from src._microservices.patch_validators import validate_patch_schema_strict, check_search_blocks_exist

_client = OllamaClient()

def _set_by_path(state: dict, path: str, value):
    # path like "working.candidate_patch" or "outputs.final_patch"
    parts = path.split(".")
    cur = state
    for p in parts[:-1]:
        cur = cur.setdefault(p, {})
    cur[parts[-1]] = value

def _get_by_path(state: dict, path: str):
    parts = path.split(".")
    cur = state
    for p in parts:
        if not isinstance(cur, dict) or p not in cur:
            return None
        cur = cur[p]
    return cur

def _run_validators(state: dict, validators: list[str], produced_text: str, produced_obj):
    # produced_text is raw model output; produced_obj is parsed JSON if applicable
    errors = []

    for v in validators:
        if v == "json_parse":
            try:
                json.loads(produced_text)
            except Exception as e:
                errors.append(f"json_parse failed: {e}")

        elif v == "schema_strict":
            ok, errs = validate_patch_schema_strict(produced_text)
            if not ok:
                errors.extend(errs)

        elif v == "match_search_blocks":
            # requires schema-valid + target file
            ok, errs = validate_patch_schema_strict(produced_text)
            if not ok:
                errors.extend(errs)
            else:
                patch_obj = json.loads(produced_text)
                target = state["inputs"]["target_file_text"]
                found, missing = check_search_blocks_exist(target, patch_obj)
                if missing:
                    errors.append(f"search_block not found for hunks: {missing} (found: {found})")

        else:
            errors.append(f"Unknown validator: {v}")

    return errors

def run_tasklist(state: dict, tasklist: dict) -> dict:
    """
    Executes enabled steps in order. Each step is a single Ollama call.
    HITL: tasklist is provided by UI and can be edited by user.

    The runner is intentionally strict:
    - If a step claims to output patch_json, we validate schema.
    - Final output is stored into state['outputs']['final_patch'] as a dict.
    """
    steps = tasklist.get("steps", [])
    for step in steps:
        if not step.get("enabled", True):
            continue

        model = step["model"]
        system = step["system_prompt"]
        template = step["user_prompt_template"]
        options = step.get("ollama_options") or {}
        expects = step.get("expects", "text")
        output_key = step.get("output_key", "working.notes")
        validators = step.get("validators", [])
        on_fail = step.get("on_fail", "continue")

        prompt = resolve_template(template, state)
        raw = _client.generate(model=model, system=system, prompt=prompt, options=options)
        raw_stripped = raw.strip()

        produced_obj = None
        if expects in ("json", "patch_json"):
            # model should emit JSON only; attempt parse
            produced_obj = json.loads(raw_stripped)

        # validators operate on raw text
        errs = _run_validators(state, validators, raw_stripped, produced_obj)
        if errs:
            # record
            state["working"].setdefault("notes", []).append({
                "step": step["id"],
                "name": step["name"],
                "errors": errs
            })
            if on_fail == "retry":
                # naive retry once with same prompt (prototype)
                raw = _client.generate(model=model, system=system, prompt=prompt, options=options)
                raw_stripped = raw.strip()
                produced_obj = json.loads(raw_stripped) if expects in ("json", "patch_json") else None
                errs2 = _run_validators(state, validators, raw_stripped, produced_obj)
                if errs2:
                    raise RuntimeError(f"Step {step['id']} failed after retry:\n" + "\n".join(errs2))
            elif on_fail == "stop":
                raise RuntimeError(f"Step {step['id']} failed:\n" + "\n".join(errs))
            # continue means fall through

        # store outputs
        if expects == "patch_json":
            # store as dict in state, but keep raw also if you want later
            _set_by_path(state, output_key, produced_obj)
        elif expects == "json":
            _set_by_path(state, output_key, produced_obj)
        else:
            _set_by_path(state, output_key, raw_stripped)

    # If outputs.final_patch is dict, keep it; if it’s text, normalize
    fp = _get_by_path(state, "outputs.final_patch")
    if isinstance(fp, str):
        state["outputs"]["final_patch"] = json.loads(fp)

    return state
