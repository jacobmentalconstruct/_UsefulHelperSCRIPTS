def new_state() -> dict:
    return {
        "mode": "validate_patch",
        "inputs": {
            "target_file_text": "",
            "snippet_text": "",
            "existing_patch_json": "",
            "error_log_text": "",
            "file_path": "",
            "language_hint": "unknown"
        },
        "working": {
            "candidate_patch": None,
            "validation": {},
            "match_test": {},
            "notes": []
        },
        "outputs": {
            "final_patch": None
        }
    }
