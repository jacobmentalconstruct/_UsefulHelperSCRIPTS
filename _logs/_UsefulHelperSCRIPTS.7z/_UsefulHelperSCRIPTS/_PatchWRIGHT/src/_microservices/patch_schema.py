REQUIRED_TOP_KEY = "hunks"
REQUIRED_HUNK_KEYS = ["description", "search_block", "replace_block", "use_patch_indent"]
