# Patchwright (TokenizingPATCHER Companion)

Patchwright is a local, human-in-the-loop (HITL) patch generation, repair, and validation tool designed specifically for use with **_TokenizingPATCHER**.

It uses a **local LLM via Ollama** (e.g. `qwen2:7b`, `qwen2.5:7b-coder`) to:
- create patches from snippets + target files
- repair failing or malformed patches
- strictly validate patches before they reach the patcher

The system is intentionally **tasklist-driven**: every inference cycle is explicit, editable, and inspectable.

---

## Core Guarantees

Patchwright enforces **hard correctness constraints**:

- ✅ Final output is **always valid JSON**
- ✅ Output **always** conforms to the exact TokenizingPATCHER schema
- ✅ Optional enforcement that every `search_block` exists verbatim in the target file
- ❌ No placeholder text (`... existing code ...`, `TODO`, etc.) in final patches
- ❌ No hidden or implicit inference steps

If a step fails validation, it is retried, repaired, or halted — never silently passed through.

---

## TokenizingPATCHER Patch Schema (Strict)

Patchwright **only** outputs patches in this format:

```json
{
  "hunks": [
    {
      "description": "Short human description",
      "search_block": "exact text to find\n(can span multiple lines)",
      "replace_block": "replacement text\n(same or different length)",
      "use_patch_indent": false
    }
  ]
}
