import sys
import os
import json
import sqlite3
import threading
import uuid
import datetime
import math
import struct
import difflib
import tkinter as tk
from tkinter import ttk, scrolledtext, simpledialog, messagebox, filedialog

# --- OPTIONAL AI DEPENDENCIES ---
try:
    import ollama
    import chromadb
    AI_AVAILABLE = True
except ImportError:
    AI_AVAILABLE = False
    print("WARNING: 'ollama' or 'chromadb' not found. AI features will be disabled.")

# ==============================================================================
# 1. CORE ENGINES (The Backend Logic)
# ==============================================================================

class CortexLink:
    """
    The Bridge: Connects _LocalMIND to a _NeoCORTEX Knowledge Base (.db).
    Acts as a read-only neural interface for the Reference Shelf.
    """
    def __init__(self, db_path):
        self.db_path = db_path
        self.name = os.path.basename(db_path)
        self.config = self._load_manifest()
        
    def _load_manifest(self):
        """Handshake: Checks what model this brain uses."""
        meta = {}
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            # Check if manifest table exists first
            try:
                rows = cursor.execute("SELECT key, value FROM manifest").fetchall()
                for k, v in rows: meta[k] = v
            except sqlite3.OperationalError:
                meta['error'] = "No Manifest Found"
            conn.close()
        except Exception as e:
            print(f"[{self.name}] Connection Error: {e}")
        return meta

    def query(self, query_vector, limit=5):
        """
        Performs a vector search against this specific brain.
        Uses pure Python Cosine Similarity for portability.
        """
        results = []
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Fetch all chunks (Brute force for V1 reliability)
            # In V2, we can optimize with spatial indices if available
            cursor.execute("SELECT c.id, f.path, c.content, c.embedding FROM chunks c JOIN files f ON c.file_id = f.id")
            
            candidates = []
            for row in cursor.fetchall():
                _, path, content, blob = row
                if not blob: continue
                
                try:
                    # Flexible Deserialization (JSON or Binary)
                    try:
                        vec = json.loads(blob)
                    except:
                        vec = struct.unpack(f'{len(query_vector)}f', blob)
                    
                    score = self._cosine_sim(query_vector, vec)
                    candidates.append((score, path, content))
                except Exception:
                    continue
            
            # Sort and Slice
            candidates.sort(key=lambda x: x[0], reverse=True)
            results = candidates[:limit]
            conn.close()
            
        except Exception as e:
            print(f"[{self.name}] Query Error: {e}")
            
        return results

    def _cosine_sim(self, v1, v2):
        dot = sum(a*b for a,b in zip(v1, v2))
        norm_a = math.sqrt(sum(a*a for a in v1))
        norm_b = math.sqrt(sum(b*b for b in v2))
        return dot / (norm_a * norm_b) if norm_a and norm_b else 0.0

    # --- CURATION TOOLS ---
    def list_files(self):
        try:
            conn = sqlite3.connect(self.db_path)
            rows = conn.execute("SELECT path FROM files ORDER BY path").fetchall()
            conn.close()
            return [r[0] for r in rows]
        except: return []

    def get_content(self, path):
        try:
            conn = sqlite3.connect(self.db_path)
            row = conn.execute("SELECT content FROM files WHERE path=?", (path,)).fetchone()
            conn.close()
            return row[0] if row else None
        except: return None

    def update_file(self, path, new_content, author="_LocalMIND"):
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # 1. Get Old Content
            row = cursor.execute("SELECT content FROM files WHERE path=?", (path,)).fetchone()
            if not row:
                # New File Mode
                cursor.execute("INSERT INTO files (path, content, last_updated) VALUES (?,?,?)", (path, new_content, datetime.datetime.now()))
                self._log_diff(cursor, path, "CREATE", "[New File]", author)
            else:
                # Edit Mode
                old = row['content'] or ""
                diff = self._compute_diff(path, old, new_content)
                if not diff: return False # No changes
                
                self._log_diff(cursor, path, "EDIT", diff, author)
                cursor.execute("UPDATE files SET content=?, last_updated=? WHERE path=?", (new_content, datetime.datetime.now(), path))
                
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            print(f"Update Error: {e}")
            return False

    def _compute_diff(self, path, old, new):
        diff = difflib.unified_diff(old.splitlines(keepends=True), new.splitlines(keepends=True), fromfile=f"a/{path}", tofile=f"b/{path}")
        return "".join(diff)

    def _log_diff(self, cursor, path, type_, diff_blob, author):
        did = str(uuid.uuid4())
        cursor.execute("INSERT INTO diff_log (id, file_path, timestamp, change_type, diff_blob, author) VALUES (?,?,?,?,?,?)", (did, path, datetime.datetime.now(), type_, diff_blob, author))

class IdentityEngine:
    """
    The Agent Manager: Handles 'Roles' (System Prompts) and Personas.
    """
    def __init__(self, db_path):
        self.db_path = db_path
        self._init_roles()

    def _init_roles(self):
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        c.execute('''CREATE TABLE IF NOT EXISTS roles (
            id TEXT PRIMARY KEY, name TEXT UNIQUE, system_prompt TEXT, description TEXT
        )''')
        
        # Seed Defaults
        if c.execute("SELECT count(*) FROM roles").fetchone()[0] == 0:
            defaults = [
                ("gen", "Generalist", "You are a helpful, precise assistant.", "Standard helpful AI."),
                ("curator", "Data Curator", "You are a Data Curation Expert. Your job is to read provided context, identify errors, consistency issues, or outdated information, and propose exact edits. Be extremely rigorous.", "Specialist for cleaning datasets."),
                ("librarian", "Meta-Librarian", "You are the manager of the Reference Shelf. You help the user decide which data sources to mount and how to organize them.", "Helps organize the books.")
            ]
            c.executemany("INSERT INTO roles (id, name, system_prompt, description) VALUES (?,?,?,?)", defaults)
            conn.commit()
        conn.close()

    def get_roles(self):
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        rows = conn.execute("SELECT * FROM roles").fetchall()
        conn.close()
        return [dict(r) for r in rows]

    def create_role(self, name, prompt, description):
        rid = str(uuid.uuid4())[:8]
        conn = sqlite3.connect(self.db_path)
        try:
            conn.execute("INSERT INTO roles (id, name, system_prompt, description) VALUES (?,?,?,?)", (rid, name, prompt, description))
            conn.commit()
            return rid
        except sqlite3.IntegrityError:
            return None
        finally:
            conn.close()

    def get_role(self, role_id):
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        row = conn.execute("SELECT * FROM roles WHERE id = ?", (role_id,)).fetchone()
        conn.close()
        return dict(row) if row else None

class ReferenceShelf:
    """
    The Bookshelf: Manages mounted _NeoCORTEX databases.
    """
    def __init__(self):
        self.mounted_books = {} # {path: CortexLink}

    def mount(self, db_path):
        if db_path in self.mounted_books: return
        link = CortexLink(db_path)
        self.mounted_books[db_path] = link

    def unmount(self, db_path):
        if db_path in self.mounted_books:
            del self.mounted_books[db_path]

    def search_library(self, query_vec, limit=3):
        """Aggregates knowledge from ALL mounted books."""
        results = []
        for book in self.mounted_books.values():
            hits = book.query(query_vec, limit=limit)
            for score, path, content in hits:
                results.append((score, path, content, book.name))
        
        # Global Rank
        results.sort(key=lambda x: x[0], reverse=True)
        return results[:5] # Top 5 across all books

class WorkflowEngine:
    """
    The Processor: Orchestrates the Task List (Identity + Shelf -> Inference).
    """
    def __init__(self, backend):
        self.backend = backend

    def run_workflow(self, task, user_prompt, role_id):
        """Dispatcher for different task types."""
        if task == "Summarize":
            return self._run_helper_task(user_prompt, "You are a highly efficient summarizer. Condense the user input into a concise summary.")
        elif task == "Audit":
            return self._run_helper_task(user_prompt, "You are a data auditor. Check the following input for logical inconsistencies, errors, or security risks. Report only valid issues.")
        elif task == "Extract Entities":
            return self._run_helper_task(user_prompt, "Extract all named entities (People, Organizations, Locations, File Paths) from the text as a JSON list.")
        else:
            # Default: Chat
            return self._run_chat_workflow(user_prompt, role_id)

    def _run_helper_task(self, user_prompt, system_instruction):
        """Runs a task using the lightweight Helper Model."""
        model = self.backend.helper_model
        return self._inference(model, user_prompt, system_instruction)

    def _run_chat_workflow(self, user_prompt, role_id):
        """Runs the main Chat Workflow using the Active Model and RAG."""
        model = self.backend.active_model
        
        # 1. IDENTITY
        role = self.backend.identity.get_role(role_id)
        sys_prompt = role['system_prompt'] if role else "You are a helpful assistant."

        # 2. REFERENCE (The Shelf) - RAG Only on Main Chat for now
        context_str = ""
        if self.backend.shelf.mounted_books and AI_AVAILABLE:
            try:
                # Get Vector
                emb_resp = ollama.embeddings(model=model, prompt=user_prompt)
                q_vec = emb_resp['embedding']
                
                # Search
                hits = self.backend.shelf.search_library(q_vec)
                
                if hits:
                    context_str = "\n\n### REFERENCE SHELF DATA ###\n"
                    for score, path, content, book_name in hits:
                        context_str += f"[BOOK: {book_name} | SOURCE: {os.path.basename(path)}]\n{content[:600]}...\n"
            except Exception as e:
                print(f"Workflow Retrieval Error: {e}")

        # 3. SYNTHESIS
        full_system = f"{sys_prompt}{context_str}"
        
        # 4. INFERENCE
        return self._inference(model, user_prompt, full_system)

    def _inference(self, model, prompt, system_prompt):
        if not AI_AVAILABLE: return "AI Offline."
        try:
            res = ollama.chat(
                model=model,
                messages=[
                    {'role': 'system', 'content': system_prompt},
                    {'role': 'user', 'content': prompt}
                ]
            )
            return res['message']['content']
        except Exception as e:
            return f"Inference Error: {e}"

class LocalMindBackend:
    def __init__(self, root_dir):
        self.root_dir = root_dir
        self.db_path = os.path.join(root_dir, "localmind.db")
        
        # Init Main DB
        self._init_sqlite()
        
        # Init Engines
        self.identity = IdentityEngine(self.db_path)
        self.shelf = ReferenceShelf()
        self.workflow = WorkflowEngine(self)
        
        # Global State (defaults)
        self.active_model = "llama3"
        self.helper_model = "llama3"

    def _init_sqlite(self):
        conn = sqlite3.connect(self.db_path)
        # Chat History Table
        conn.execute('''CREATE TABLE IF NOT EXISTS chats (
            id INTEGER PRIMARY KEY AUTOINCREMENT, session_id TEXT, 
            role TEXT, content TEXT, timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )''')
        # Projects Table
        conn.execute('''CREATE TABLE IF NOT EXISTS projects (
            id TEXT PRIMARY KEY, name TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )''')
        conn.commit()
        conn.close()

    def get_models(self):
        if not AI_AVAILABLE: return []
        try:
            res = ollama.list()
            models = []
            # 1. Extract List
            if isinstance(res, dict) and 'models' in res: models = res['models']
            elif isinstance(res, list): models = res
            elif hasattr(res, 'models'): models = res.models
            
            # 2. Extract Names
            names = []
            for m in models:
                if isinstance(m, dict): names.append(m.get('name') or m.get('model'))
                else: names.append(getattr(m, 'model', getattr(m, 'name', None)))
            return [n for n in names if n]
        except Exception as e:
            print(f"Ollama Connect Error: {e}")
            return []

    def save_chat(self, role, content, session="default"):
        conn = sqlite3.connect(self.db_path)
        conn.execute("INSERT INTO chats (session_id, role, content) VALUES (?,?,?)", (session, role, content))
        conn.commit()
        conn.close()

    def clear_history(self, session="default"):
        conn = sqlite3.connect(self.db_path)
        conn.execute("DELETE FROM chats WHERE session_id=?", (session,))
        conn.commit()
        conn.close()

    def get_history(self, session="default"):
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        rows = conn.execute("SELECT role, content FROM chats WHERE session_id=? ORDER BY id ASC", (session,)).fetchall()
        conn.close()
        return [dict(r) for r in rows]

    def create_empty_cartridge(self, path):
        """Mints a new, empty _NeoCORTEX compatible .db (Full Schema)"""
        if os.path.exists(path): return False
        try:
            conn = sqlite3.connect(path)
            cursor = conn.cursor()
            
            # 1. Config & Graph
            cursor.execute("CREATE TABLE IF NOT EXISTS manifest (key TEXT PRIMARY KEY, value TEXT)")
            cursor.execute("CREATE TABLE IF NOT EXISTS graph_nodes (id TEXT PRIMARY KEY, type TEXT, label TEXT, data_json TEXT)")
            cursor.execute("CREATE TABLE IF NOT EXISTS graph_edges (source TEXT, target TEXT, weight REAL)")

            # 2. Files (Provenance & Content)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS files (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    path TEXT UNIQUE NOT NULL,
                    content TEXT,
                    origin_type TEXT DEFAULT 'manual',
                    origin_path TEXT,
                    vfs_path TEXT,
                    metadata TEXT DEFAULT '{}',
                    last_updated TIMESTAMP,
                    status TEXT DEFAULT 'indexed'
                )
            """)

            # 3. Chunks (Vectors)
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS chunks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                file_id INTEGER,
                chunk_index INTEGER,
                content TEXT,
                embedding BLOB,
                name TEXT,
                type TEXT,
                start_line INTEGER,
                end_line INTEGER,
                FOREIGN KEY(file_id) REFERENCES files(id)
            )
            """)

            # 4. Diff Log (History)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS diff_log (
                    id TEXT PRIMARY KEY,
                    file_path TEXT NOT NULL,
                    timestamp TIMESTAMP,
                    change_type TEXT,
                    diff_blob TEXT,
                    author TEXT
                )
            """)

            # Stamp It
            cursor.execute("INSERT INTO manifest (key, value) VALUES (?, ?)", ("created_by", "_LocalMIND"))
            cursor.execute("INSERT INTO manifest (key, value) VALUES (?, ?)", ("schema_version", "1.1"))
            
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            print(f"Creation Error: {e}")
            return False

# ==============================================================================
# 2. UI COMPONENTS (The Workbench)
# ==============================================================================

class Tooltip:
    def __init__(self, widget, text):
        self.widget = widget
        self.text = text
        self.tip = None
        widget.bind("<Enter>", self.show)
        widget.bind("<Leave>", self.hide)

    def show(self, event=None):
        x, y, _, _ = self.widget.bbox("insert")
        x += self.widget.winfo_rootx() + 25
        y += self.widget.winfo_rooty() + 20
        self.tip = tk.Toplevel(self.widget)
        self.tip.wm_overrideredirect(True)
        self.tip.wm_geometry(f"+{x}+{y}")
        tk.Label(self.tip, text=self.text, bg="#ffffe0", fg="black", font=("tahoma", 8), bd=1, relief="solid").pack()

    def hide(self, event=None):
        if self.tip: self.tip.destroy(); self.tip = None

class CartridgeBrowser(tk.Toplevel):
    """Popup to browse files inside a mounted DB"""
    def __init__(self, parent, cortex_link, on_select):
        super().__init__(parent)
        self.title(f"Browsing: {cortex_link.name}")
        self.geometry("500x400")
        self.configure(bg="#1e1e1e")
        self.on_select = on_select
        
        # Treeview
        self.tree = ttk.Treeview(self, show="tree", selectmode="browse")
        self.tree.pack(fill="both", expand=True, padx=10, pady=10)
        self.tree.bind("<Double-1>", self._on_double_click)
        
        # Populate
        files = cortex_link.list_files()
        self._build_tree(files)

    def _build_tree(self, paths):
        # Simple folder simulation from flat paths
        self.tree.delete(*self.tree.get_children())
        nodes = {}
        for p in paths:
            parts = p.split('/')
            parent = ""
            for i, part in enumerate(parts):
                current_path = "/".join(parts[:i+1])
                if current_path not in nodes:
                    if i == len(parts) - 1:
                        # It's a file
                        oid = self.tree.insert(parent, "end", text=f"📄 {part}", values=(p,))
                    else:
                        # It's a folder
                        oid = self.tree.insert(parent, "end", text=f"📁 {part}", open=False)
                    nodes[current_path] = oid
                parent = nodes[current_path]

    def _on_double_click(self, event):
        item = self.tree.selection()
        if not item: return
        values = self.tree.item(item[0], 'values')
        if values: # It's a file
            self.on_select(values[0])
            self.destroy()

class DraftingPanel(tk.Frame):
    """LEFT COLUMN: Workspace / Document Editor"""
    def __init__(self, parent, backend):
        super().__init__(parent, bg="#1e293b", width=250)
        self.backend = backend
        self.pack_propagate(False)

        # Header
        tk.Label(self, text="WORKSPACE / DRAFTING", bg="#0f172a", fg="#94a3b8", font=("Arial", 8, "bold"), pady=5).pack(fill="x")
        
        # Toolbar
        toolbar = tk.Frame(self, bg="#1e293b", pady=5)
        toolbar.pack(fill="x", padx=5)
        # Local IO
        tk.Button(toolbar, text="💾 LOC", bg="#334155", fg="white", width=6, relief="flat", font=("Arial", 8), command=self.save_file).pack(side="left", padx=1)
        tk.Button(toolbar, text="📂 LOC", bg="#334155", fg="white", width=6, relief="flat", font=("Arial", 8), command=self.open_file).pack(side="left", padx=1)
        # Cartridge IO
        tk.Label(toolbar, text="|", bg="#1e293b", fg="#64748b").pack(side="left", padx=5)
        tk.Button(toolbar, text="📥 DB", bg="#0f766e", fg="white", width=6, relief="flat", font=("Arial", 8), command=self.load_from_db).pack(side="left", padx=1)
        tk.Button(toolbar, text="📤 DB", bg="#c2410c", fg="white", width=6, relief="flat", font=("Arial", 8), command=self.commit_to_db).pack(side="left", padx=1)
        
        # State
        self.active_db = None
        self.active_path = None
        
        # Editor
        self.editor = scrolledtext.ScrolledText(self, bg="#0f172a", fg="#cbd5e1", font=("Consolas", 10), insertbackground="white", bd=0)
        self.editor.pack(fill="both", expand=True, padx=5, pady=5)
        self.editor.insert("1.0", "# Scratchpad\nUse this space to curate findings or draft outputs...")

    def save_file(self):
        path = filedialog.asksaveasfilename(defaultextension=".txt", filetypes=[("Text", "*.txt"), ("Markdown", "*.md"), ("All", "*.*")])
        if path:
            with open(path, 'w', encoding='utf-8') as f:
                f.write(self.editor.get("1.0", tk.END))

    def open_file(self):
        path = filedialog.askopenfilename(filetypes=[("Text", "*.txt"), ("Markdown", "*.md"), ("All", "*.*")])
        if path:
            with open(path, 'r', encoding='utf-8') as f:
                content = f.read()
            self.editor.delete("1.0", tk.END)
            self.editor.insert("1.0", content)

    def load_from_db(self):
        # 1. Select Cartridge (Simple List Selection)
        books = list(self.backend.shelf.mounted_books.values())
        if not books: 
            messagebox.showwarning("Shelf Empty", "Mount a cartridge first."); return
        
        # Create a simple modal to pick the book if multiple exist
        if len(books) == 1:
            target_book = books[0]
            self._open_browser(target_book)
        else:
            self._pick_book_modal(books)

    def _pick_book_modal(self, books):
        # Temporary modal to pick book
        top = tk.Toplevel(self)
        top.title("Select Cartridge")
        top.geometry("300x200")
        lb = tk.Listbox(top)
        lb.pack(fill="both", expand=True)
        for b in books: lb.insert("end", b.name)
        def confirm():
            sel = lb.curselection()
            if sel:
                target = books[sel[0]]
                top.destroy()
                self._open_browser(target)
        tk.Button(top, text="Open", command=confirm).pack(fill="x")

    def _open_browser(self, target_book):
        # 2. Open Tree Browser
        CartridgeBrowser(self, target_book, lambda path: self._load_file(target_book, path))

    def _load_file(self, book, path):
        content = book.get_content(path)
        if content:
            self.editor.delete("1.0", tk.END)
            self.editor.insert("1.0", content)
            self.active_db = book
            self.active_path = path
            # Update Header
            self.master.master.log(f"Editing: {path} [{book.name}]")

    def commit_to_db(self):
        if not self.active_db or not self.active_path:
            messagebox.showwarning("Error", "No active DB file loaded. Use 'Load DB' or Create New."); return
            
        content = self.editor.get("1.0", tk.END).strip()
        if self.active_db.update_file(self.active_path, content, author="User"):
            messagebox.showinfo("Success", "Changes committed to Cartridge Audit Log.")
        else:
            messagebox.showerror("Error", "Commit failed (No changes or DB locked).")

class ShelfPanel(tk.Frame):
    """RIGHT COLUMN: The Reference Library"""
    def __init__(self, parent, backend):
        super().__init__(parent, bg="#1e1e1e", width=250)
        self.backend = backend
        self.pack_propagate(False)

        # Header
        tk.Label(self, text="REFERENCE SHELF", bg="#000000", fg="#facc15", font=("Arial", 8, "bold"), pady=5).pack(fill="x")

        # Controls
        ctrl = tk.Frame(self, bg="#1e1e1e", pady=5)
        ctrl.pack(fill="x")
        
        # Row 1: Mount / Create
        row1 = tk.Frame(ctrl, bg="#1e1e1e")
        row1.pack(fill="x", padx=10, pady=2)
        tk.Button(row1, text="➕ MOUNT", bg="#334155", fg="white", width=10, relief="flat", command=self.mount_db).pack(side="left", fill="x", expand=True, padx=(0,2))
        tk.Button(row1, text="✨ NEW CART", bg="#15803d", fg="white", width=10, relief="flat", command=self.create_db).pack(side="left", fill="x", expand=True, padx=(2,0))

        # List
        self.listbox = tk.Listbox(self, bg="#262626", fg="#d4d4d4", bd=0, highlightthickness=0)
        self.listbox.pack(fill="both", expand=True, padx=5, pady=5)

    def mount_db(self):
        path = filedialog.askopenfilename(title="Select _NeoCORTEX Cartridge", filetypes=[("SQLite DB", "*.db")])
        if path:
            self.backend.shelf.mount(path)
            self.refresh_list()

    def create_db(self):
        path = filedialog.asksaveasfilename(title="New Brain Cartridge", defaultextension=".db", filetypes=[("SQLite DB", "*.db")])
        if path:
            if self.backend.create_empty_cartridge(path):
                self.backend.shelf.mount(path)
                self.refresh_list()
            else:
                messagebox.showerror("Error", "Failed to create Cartridge.")

    def refresh_list(self):
        self.listbox.delete(0, tk.END)
        for path, link in self.backend.shelf.mounted_books.items():
            model = link.config.get('embed_model', 'Unknown')
            self.listbox.insert(tk.END, f"📘 {link.name} [{model}]")

class WorkbenchPanel(tk.Frame):
    """CENTER COLUMN: Chat & Task Execution"""
    def __init__(self, parent, backend):
        super().__init__(parent, bg="#0f172a")
        self.backend = backend
        self.current_role_id = "gen" # Default
        
        # Top Bar: Identity Controls
        top_bar = tk.Frame(self, bg="#0f172a", pady=5)
        top_bar.pack(fill="x")
        
        tk.Label(top_bar, text="ACTIVE PERSONA:", bg="#0f172a", fg="#64748b", font=("Arial", 8, "bold")).pack(side="left", padx=(10, 5))
        
        # Persona Dropdown
        self.role_var = tk.StringVar()
        self.role_combo = ttk.Combobox(top_bar, textvariable=self.role_var, state="readonly", width=30)
        self.role_combo.pack(side="left", padx=5)
        self.role_combo.bind("<<ComboboxSelected>>", self._on_role_select)
        
        # Create Role Button (+)
        self.btn_new_role = tk.Button(top_bar, text="+", bg="#334155", fg="white", relief="flat", width=3, command=self.create_new_role)
        self.btn_new_role.pack(side="left", padx=5)
        Tooltip(self.btn_new_role, "Create a new Agent Persona")

        # Settings Gear
        self.btn_config = tk.Button(top_bar, text="⚙", bg="#334155", fg="#cbd5e1", relief="flat", width=3, command=self.open_settings)
        self.btn_config.pack(side="left", padx=5)
        Tooltip(self.btn_config, "System Configuration")

        # Clear Session Button
        self.btn_clear = tk.Button(top_bar, text="🗑️", bg="#b91c1c", fg="white", relief="flat", width=3, command=self.clear_session)
        self.btn_clear.pack(side="right", padx=10)
        Tooltip(self.btn_clear, "Flush Chat History")

        # Split Center into Chat (Top) and System Log (Bottom)
        self.paned_center = tk.PanedWindow(self, orient="vertical", bg="#0f172a", sashwidth=4, sashrelief="flat")
        self.paned_center.pack(fill="both", expand=True)

        # 1. Chat Area
        self.display = scrolledtext.ScrolledText(self.paned_center, bg="#0f172a", fg="#e2e8f0", font=("Consolas", 10), state="disabled", padx=10, pady=10)
        self.display.tag_config("user", foreground="#60a5fa", justify="right")
        self.display.tag_config("assistant", foreground="#a78bfa", justify="left")
        self.paned_center.add(self.display, height=500)

        # 2. System Log Console
        log_frame = tk.Frame(self.paned_center, bg="#000000")
        tk.Label(log_frame, text="SYSTEM LOG", bg="#1e1e1e", fg="#64748b", font=("Arial", 7, "bold"), anchor="w").pack(fill="x")
        self.log_display = scrolledtext.ScrolledText(log_frame, bg="#0a0a0a", fg="#00ff00", font=("Consolas", 9), state="disabled", padx=5, pady=5)
        self.log_display.pack(fill="both", expand=True)
        self.paned_center.add(log_frame, height=150)

        # Input Area
        input_frame = tk.Frame(self, bg="#1e293b", height=80)
        input_frame.pack(fill="x", side="bottom")
        
        # Task Selector
        self.task_var = tk.StringVar(value="Chat")
        self.task_combo = ttk.Combobox(input_frame, textvariable=self.task_var, state="readonly", width=15)
        self.task_combo['values'] = ["Chat", "Summarize", "Audit", "Extract Entities"]
        self.task_combo.pack(side="left", padx=(5,0), pady=5, anchor="n")
        
        # Context Toggle
        self.use_context = tk.BooleanVar()
        self.chk_context = tk.Checkbutton(input_frame, text="Use Draft", variable=self.use_context, bg="#1e293b", fg="#94a3b8", selectcolor="#0f172a", activebackground="#1e293b", activeforeground="white", font=("Arial", 8))
        self.chk_context.pack(side="left", padx=5, pady=5, anchor="n")
        
        self.draft_panel = None # To be linked

        self.txt_input = tk.Text(input_frame, height=4, bg="#334155", fg="white", font=("Consolas", 10), insertbackground="white")
        self.txt_input.pack(side="left", fill="both", expand=True, padx=5, pady=5)
        self.txt_input.bind("<Return>", self._on_enter)
        
        btn_send = tk.Button(input_frame, text="RUN >", bg="#6366f1", fg="white", font=("Arial", 10, "bold"), relief="flat", command=self.run_task)
        btn_send.pack(side="right", fill="y", padx=5, pady=5)
        
        # Initialize Roles & History
        self.refresh_roles()
        self.refresh_history()

    def link_draft(self, panel):
        self.draft_panel = panel

    def refresh_roles(self):
        self.roles = self.backend.identity.get_roles()
        self.role_combo['values'] = [r['name'] for r in self.roles]
        if self.roles:
            self.role_combo.current(0)
            self._on_role_select(None)

    def _on_role_select(self, event):
        name = self.role_var.get()
        role = next((r for r in self.roles if r['name'] == name), None)
        if role:
            self.current_role_id = role['id']
            self._log_system(f"Persona switched to: {role['name']}")

    def clear_session(self):
        if messagebox.askyesno("Clear Session", "Flush current chat history? This cannot be undone."):
            self.backend.clear_history()
            self.refresh_history()
            self._log_system("Session Flushed.")

    def open_settings(self):
        SettingsModal(self, self.backend)

    def create_new_role(self):
        name = simpledialog.askstring("New Persona", "Name of Role (e.g., 'Python Expert')")
        if not name: return
        prompt = simpledialog.askstring("New Persona", "System Prompt (Instructions)")
        if not prompt: return
        desc = simpledialog.askstring("New Persona", "Short Description")
        
        rid = self.backend.identity.create_role(name, prompt, desc)
        if rid:
            self.refresh_roles()
            self.role_combo.set(name)
            self._on_role_select(None)
            messagebox.showinfo("Success", "New Persona Created.")
        else:
            messagebox.showerror("Error", "Could not create role (Name might be duplicate).")

    def _log_system(self, msg):
        ts = datetime.datetime.now().strftime('%H:%M:%S')
        self.log_display.config(state="normal")
        self.log_display.insert("end", f"[{ts}] {msg}\n")
        self.log_display.see("end")
        self.log_display.config(state="disabled")

    def _on_enter(self, event):
        if not event.state & 0x0001:
            self.run_task()
            return "break"

    def refresh_history(self):
        self.display.config(state="normal")
        self.display.delete("1.0", "end")
        for msg in self.backend.get_history():
            tag = "user" if msg['role'] == 'user' else "assistant"
            self.display.insert("end", f"\n{msg['role'].upper()}:\n{msg['content']}\n", tag)
            self.display.insert("end", "-"*40, "sys")
        self.display.see("end")
        self.display.config(state="disabled")

    def run_task(self):
        prompt = self.txt_input.get("1.0", "end").strip()
        
        # Handle Context Injection
        if self.use_context.get() and self.draft_panel:
            draft_text = self.draft_panel.editor.get("1.0", "end").strip()
            if draft_text:
                # If prompt is empty (e.g. just running 'Summarize'), provide a default
                if not prompt: prompt = "[Process this document]"
                prompt = f"{prompt}\n\n--- DRAFT CONTEXT ---\n{draft_text}"
        
        if not prompt: return
        
        task = self.task_var.get()
        
        self.txt_input.delete("1.0", "end")
        self.backend.save_chat("user", prompt)
        self.refresh_history()
        
        # Run in thread
        threading.Thread(target=self._worker, args=(prompt, task), daemon=True).start()

    def _worker(self, prompt, task):
        # Route via Workflow Engine
        response = self.backend.workflow.run_workflow(task, prompt, self.current_role_id)
        self.backend.save_chat("assistant", response)
        self.after(0, self.refresh_history)

class SettingsModal(tk.Toplevel):
    def __init__(self, parent, backend):
        super().__init__(parent)
        self.title("System Config")
        self.geometry("400x300")
        self.configure(bg="#1e1e1e")
        self.backend = backend
        
        tk.Label(self, text="NEURAL CONFIGURATION", bg="#1e1e1e", fg="#facc15", font=("Arial", 10, "bold")).pack(pady=10)
        
        # Model Selection
        tk.Label(self, text="Inference Model (Architect):", bg="#1e1e1e", fg="#94a3b8").pack(anchor="w", padx=20)
        self.model_var = tk.StringVar()
        self.model_combo = ttk.Combobox(self, textvariable=self.model_var)
        self.model_combo.pack(fill="x", padx=20, pady=(0, 10))
        
        tk.Label(self, text="Helper Model (Summarizer):", bg="#1e1e1e", fg="#94a3b8").pack(anchor="w", padx=20)
        self.helper_var = tk.StringVar()
        self.helper_combo = ttk.Combobox(self, textvariable=self.helper_var)
        self.helper_combo.pack(fill="x", padx=20, pady=(0, 20))
        
        # Populate
        models = self.backend.get_models()
        if models:
            self.model_combo['values'] = models
            self.helper_combo['values'] = models
            self.model_var.set(models[0])
            if len(models) > 1: self.helper_var.set(models[1])
            else: self.helper_var.set(models[0])
            
        # Set current from backend if available
        if self.backend.active_model in models: self.model_var.set(self.backend.active_model)
        
        tk.Button(self, text="SAVE & CLOSE", bg="#15803d", fg="white", command=self.save_and_close).pack(pady=20)

    def save_and_close(self):
        self.backend.active_model = self.model_var.get()
        self.backend.helper_model = self.helper_var.get()
        self.destroy()

# ==============================================================================
# 3. MAIN APP
# ==============================================================================

class LocalMindApp:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("_LocalMIND v0.5 [Workbench]")
        self.root.geometry("1400x900")
        self.root.configure(bg="#0f172a")

        self.backend = LocalMindBackend(os.getcwd())

        # Main Layout: 3 Columns
        self.panes = tk.PanedWindow(self.root, orient="horizontal", bg="#0f172a", sashwidth=4, sashrelief="flat")
        self.panes.pack(fill="both", expand=True)

        # --- INSTANTIATION ---
        # Panels are now mostly independent due to backend state sharing
        self.draft_panel = DraftingPanel(self.panes, self.backend)
        self.work_panel = WorkbenchPanel(self.panes, self.backend)
        self.work_panel.link_draft(self.draft_panel) # Link for Context Access
        self.shelf_panel = ShelfPanel(self.panes, self.backend)

        # --- LAYOUT (Visual Order: Left -> Right) ---
        self.panes.add(self.draft_panel, width=300)
        self.panes.add(self.work_panel, width=700)
        self.panes.add(self.shelf_panel, width=400)

        # Status Bar
        self.status_var = tk.StringVar(value="System Ready.")
        self.status_bar = tk.Label(self.root, textvariable=self.status_var, bg="#0f172a", fg="#64748b", font=("Consolas", 8), anchor="w", padx=10, pady=2)
        self.status_bar.pack(side="bottom", fill="x")

    def log(self, msg):
        self.status_var.set(f"[{datetime.datetime.now().strftime('%H:%M:%S')}] {msg}")
        self.root.update_idletasks()

    # on_role_change is deprecated/handled internally

    def run(self):
        self.root.mainloop()

if __name__ == "__main__":
    app = LocalMindApp()
    app.run()






