from dataclasses import dataclass
from typing import List, Dict, Tuple

@dataclass
class Tile:
    x: int
    y: int
    zone_type: str
    name: str
    description: str
    symbol: str  
    color: str   
    items: List[str]
    exits: List[str]

class HomeGeneratrix:
    def __init__(self):
        self.width = 5
        self.height = 5
        self.tiles: Dict[Tuple[int, int], Tile] = {}

    def forge(self) -> Dict[Tuple[int, int], Tile]:
        # 1. Fill Yard (The "Path" Context)
        # We use a middle dot '·' to signify walkable ground that isn't a room.
        for x in range(self.width):
            for y in range(self.height):
                self.tiles[(x,y)] = Tile(
                    x, y, "outdoor", "Overgrown Yard", 
                    "Wild grass sways in the wind.", 
                    " · ", "#444", [], []  # Dim Grey Dot = Path
                )

        # 2. House Layout (The Floorplan)
        # We replace the '·' with specific icons for the house.
        house_layout = {
            (1,1): ("Living Room", "Cozy fireplace.", "🛋️", "#d79921", ["log"]),
            (2,1): ("Kitchen", "Smells of dust.",     "🍳", "#d79921", ["knife"]), 
            (3,1): ("Bathroom", "Cracked tiles.",     "🚽", "#458588", ["towel"]),
            (1,2): ("Bedroom", "A simple cot.",       "🛏️", "#b16286", ["tunic"]),     
            (2,2): ("Hallway", "Narrow passage.",     " ┼ ", "#928374", []), # Cross showing connectivity   
            (3,2): ("Study", "Books everywhere.",     "📚", "#d65d0e", ["book"])
        }
        
        for (hx, hy), (name, desc, sym, col, items) in house_layout.items():
            t = self.tiles[(hx, hy)]
            t.zone_type = "indoor"
            t.name = name
            t.description = desc
            t.symbol = sym
            t.color = col
            t.items = items

        # 3. The Gate (The Exit)
        g = self.tiles[(2, 4)]
        g.name = "Front Gate"
        g.symbol = "⛩️" # Distinct Landmark
        g.color = "#cc241d"

        # 4. Decoration (Optional: Make corners 'Trees' to show borders)
        # This helps frame the 'Path' feeling
        corners = [(0,0), (4,0), (0,4), (4,4)]
        for cx, cy in corners:
            self.tiles[(cx,cy)].symbol = "🌲"
            self.tiles[(cx,cy)].name = "Dense Thicket"
            self.tiles[(cx,cy)].color = "#689d6a"

        self._stitch_grid()
        return self.tiles

    def _stitch_grid(self):
        # Allow movement everywhere for now
        pass