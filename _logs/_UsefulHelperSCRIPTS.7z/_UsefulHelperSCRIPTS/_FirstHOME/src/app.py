import sys
import tkinter as tk
from tkinter import ttk, scrolledtext, font
try:
    from src.lib.blueprint import HomeGeneratrix
except ImportError:
    pass

# ---------- CORE ENGINE ----------
class HabitatEngine:
    def __init__(self):
        self.gen = HomeGeneratrix()
        self.world_map = self.gen.forge()
        self.player_pos = (1, 2)
        self.inventory = ["pocket_lint"] # Default item
        self.status = "Idling"

    def get_view(self):
        tile = self.world_map.get(self.player_pos)
        return {
            "tile": tile,
            "inv": self.inventory,
            "status": self.status
        }

    def move(self, dx, dy):
        cx, cy = self.player_pos
        nx, ny = cx + dx, cy + dy
        if (nx, ny) in self.world_map:
            self.player_pos = (nx, ny)
            self.status = f"Moving to {self.world_map[(nx,ny)].name}..."
            return True
        self.status = "Bumped into a wall."
        return False

# ---------- GUI ----------
def run_gui():
    engine = HabitatEngine()
    
    root = tk.Tk()
    root.title("_FirstHOME // Habitat Container")
    root.geometry("1400x900")
    root.configure(bg="#050505")

    # FONTS
    f_mono = font.Font(family="Consolas", size=10)
    f_map = font.Font(family="Consolas", size=14, weight="bold") # Larger for map icons
    f_ui = font.Font(family="Segoe UI", size=9)

    # === STATUS BAR (Bottom) ===
    status_var = tk.StringVar(value="System Online.")
    lbl_status = tk.Label(root, textvariable=status_var, bd=1, relief=tk.SUNKEN, anchor="w", bg="#222", fg="#888", font=f_ui)
    lbl_status.pack(side=tk.BOTTOM, fill=tk.X)

    # === MAIN SPLIT ===
    main_pane = tk.PanedWindow(root, orient=tk.HORIZONTAL, bg="#111", sashwidth=4, sashrelief=tk.RAISED)
    main_pane.pack(fill=tk.BOTH, expand=True)

    # ==========================
    # COL 1: THE MIND (Left)
    # ==========================
    col_mind = tk.Frame(main_pane, bg="#111")
    main_pane.add(col_mind, minsize=300, stretch="never")

    # 1. Thought Stream (Top - Expanded)
    tk.Label(col_mind, text=" :: NEURAL STREAM ::", bg="#000", fg="#0ff", font=f_mono).pack(fill=tk.X)
    txt_stream = scrolledtext.ScrolledText(col_mind, bg="#000", fg="#ccc", font=f_mono, insertbackground="white", height=30)
    txt_stream.pack(fill=tk.BOTH, expand=True, padx=2, pady=2)
    txt_stream.tag_config("ME", foreground="#ff00ff")   # User
    txt_stream.tag_config("AI", foreground="#00ffff")   # Agent
    txt_stream.tag_config("GM", foreground="#00ff00")   # System

    # 2. Input Box (Bottom - Fixed)
    frame_input = tk.Frame(col_mind, bg="#222", pady=5)
    frame_input.pack(fill=tk.X, side=tk.BOTTOM)
    tk.Label(frame_input, text="WHISPER >", bg="#222", fg="#ff00ff", font=f_mono).pack(side=tk.LEFT, padx=5)
    
    entry_cmd = tk.Entry(frame_input, bg="#111", fg="white", font=f_mono, insertbackground="white")
    entry_cmd.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)

    def send_whisper(event=None):
        msg = entry_cmd.get()
        if msg:
            txt_stream.insert(tk.END, f"\n[USER] {msg}\n", "ME")
            txt_stream.see(tk.END)
            entry_cmd.delete(0, tk.END)
            engine.status = "Processing User Input..."
            status_var.set(engine.status)
    entry_cmd.bind("<Return>", send_whisper)

    # ==========================
    # COL 2: THE WORLD (Center)
    # ==========================
    col_world = tk.Frame(main_pane, bg="#000")
    main_pane.add(col_world, minsize=600, stretch="always")

    # 1. Visual Cortex (Top - Image)
    frame_vis = tk.Frame(col_world, bg="#000", height=350)
    frame_vis.pack(fill=tk.X, pady=5)
    frame_vis.pack_propagate(False) # Force height
    
    # Placeholder for Stable Diffusion
    lbl_img_ph = tk.Label(frame_vis, text="[ VISUAL CORTEX BUFFER ]", bg="#050505", fg="#333", font=("Courier", 20))
    lbl_img_ph.pack(fill=tk.BOTH, expand=True)

    # 2. Description (Middle)
    lbl_room_name = tk.Label(col_world, text="ROOM NAME", bg="#000", fg="#fff", font=("Georgia", 16, "bold"))
    lbl_room_name.pack(fill=tk.X, pady=(10, 0))
    
    lbl_desc = tk.Label(col_world, text="Description goes here...", bg="#000", fg="#aaa", font=("Georgia", 11), wraplength=550)
    lbl_desc.pack(fill=tk.X, pady=10)

    # 3. Interaction & Logs (Bottom)
    frame_bottom_center = tk.Frame(col_world, bg="#111")
    frame_bottom_center.pack(fill=tk.BOTH, expand=True)

    # A. Visible Items (Pinned Top)
    lbl_items_header = tk.Label(frame_bottom_center, text="-- VISIBLE OBJECTS --", bg="#111", fg="#ebdbb2", font=f_mono)
    lbl_items_header.pack(fill=tk.X)
    list_items = tk.Listbox(frame_bottom_center, bg="#1a1a1a", fg="#ebdbb2", height=4, bd=0, font=f_mono)
    list_items.pack(fill=tk.X, padx=5)

    # B. Action Log (Stream Below)
    lbl_log_header = tk.Label(frame_bottom_center, text="-- ACTIVITY LOG --", bg="#111", fg="#888", font=f_mono)
    lbl_log_header.pack(fill=tk.X, pady=(5,0))
    txt_action_log = scrolledtext.ScrolledText(frame_bottom_center, bg="#000", fg="#888", font=f_mono, height=8)
    txt_action_log.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

    # ==========================
    # COL 3: SYSTEM (Right)
    # ==========================
    col_sys = tk.Frame(main_pane, bg="#0a0a0a")
    main_pane.add(col_sys, minsize=300, stretch="never")

    # 1. ANSI Map (Top)
    tk.Label(col_sys, text=":: SAT-LINK ::", bg="#0a0a0a", fg="#3f0", font=f_mono).pack(fill=tk.X)
    # Using Text widget for colored characters
    txt_map = tk.Text(col_sys, bg="#000", fg="#555", font=f_map, height=12, width=20, state=tk.DISABLED, cursor="arrow")
    txt_map.pack(fill=tk.X, padx=10, pady=10)
    txt_map.tag_config("PLAYER", foreground="#00ff00", background="#004400") # Bright Green Cursor

    # 2. Stats (Middle)
    frame_stats = tk.LabelFrame(col_sys, text="BIO-METRICS", bg="#0a0a0a", fg="#555", font=f_mono)
    frame_stats.pack(fill=tk.X, padx=10, pady=10)
    
    lbl_health = tk.Label(frame_stats, text="HEALTH: 100%", bg="#0a0a0a", fg="#ff5555", font=f_mono, anchor="w")
    lbl_health.pack(fill=tk.X)
    lbl_fatigue = tk.Label(frame_stats, text="FATIGUE: 0%", bg="#0a0a0a", fg="#aaa", font=f_mono, anchor="w")
    lbl_fatigue.pack(fill=tk.X)

    # 3. Inventory (Bottom)
    frame_inv = tk.LabelFrame(col_sys, text="INVENTORY", bg="#0a0a0a", fg="#555", font=f_mono)
    frame_inv.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
    list_inv = tk.Listbox(frame_inv, bg="#050505", fg="#00e5ff", bd=0, font=f_mono)
    list_inv.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

    # --- REFRESH LOGIC ---
    def render_map(data):
        txt_map.config(state=tk.NORMAL)
        txt_map.delete("1.0", tk.END)
        
        width = engine.gen.width
        height = engine.gen.height
        
        for y in range(height - 1, -1, -1):
            for x in range(width):
                tile = engine.world_map.get((x,y))
                tag_name = f"COLOR_{x}_{y}"
                
                # Configure the tag for this tile's specific color
                color = tile.color if tile else "#333"
                txt_map.tag_config(tag_name, foreground=color)

                if (x,y) == engine.player_pos:
                    txt_map.insert(tk.END, " @ ", "PLAYER")
                else:
                    sym = tile.symbol if tile else "   "
                    txt_map.insert(tk.END, f"{sym}", tag_name)
            
            txt_map.insert(tk.END, "\n")
            
        txt_map.config(state=tk.DISABLED)

    def update_ui():
        view = engine.get_view()
        tile = view["tile"]
        
        # Update Desc
        lbl_room_name.config(text=tile.name.upper())
        lbl_desc.config(text=tile.description)
        
        # Update Visible Items
        list_items.delete(0, tk.END)
        if tile.items:
            for i in tile.items:
                list_items.insert(tk.END, f"• {i}")
        else:
            list_items.insert(tk.END, "(Nothing of interest)")

        # Update Inventory
        list_inv.delete(0, tk.END)
        for i in view["inv"]:
            list_inv.insert(tk.END, i)

        # Update Status
        status_var.set(f"System: {view['status']}")
        
        # Render Map
        render_map(view)

    # CONTROLS (Temp Mapped to Arrow Keys)
    def handle_key(event):
        moved = False
        if event.keysym == 'Up': moved = engine.move(0, 1)
        elif event.keysym == 'Down': moved = engine.move(0, -1)
        elif event.keysym == 'Left': moved = engine.move(-1, 0)
        elif event.keysym == 'Right': moved = engine.move(1, 0)
        
        if moved:
            update_ui()
            txt_action_log.insert(tk.END, f"> Moved to {engine.world_map[engine.player_pos].name}\n")
            txt_action_log.see(tk.END)

    root.bind("<Up>", handle_key)
    root.bind("<Down>", handle_key)
    root.bind("<Left>", handle_key)
    root.bind("<Right>", handle_key)

    # Initial Draw
    update_ui()
    txt_stream.insert(tk.END, "Initializing Neural Link...\nConnection Established.\n", "GM")
    
    root.mainloop()

# ... (Rest of main/CLI boilerplate) ...
def main():
    run_gui()

if __name__ == "__main__":
    main()