import sys
import os
import argparse
import tkinter as tk
from tkinter import ttk, scrolledtext, filedialog, messagebox
import json
import re

# ==============================================================================
# 1. CORE ENGINE (Business Logic)
# ==============================================================================
class WhitespaceEngine:
    """
    Parses code into a granular map of (Indent + Content + Trailing).
    Can Normalize structure and generate 'Hunk' patches.
    """
    def __init__(self):
        self.raw_lines = []
        self.nodes = []
        self.normalized_text = ""
        self.patch_data = {"hunks": []}
        self.current_filepath = None # Track the currently loaded file

    def load_source(self, text, filepath=None):
        self.raw_lines = text.splitlines()
        self.nodes = []
        self.current_filepath = filepath
        
        # State trackers
        indent_stack = [0] # Stack of indentation widths
        last_line_was_block_starter = False # Did previous line end with ':'?
        
        for i, line in enumerate(self.raw_lines):
            # 1. Parse content
            match = re.match(r"^([ \t]*)(.*?)([ \t]*)$", line)
            if not match:
                self.nodes.append({"id": i, "indent": "", "content": line, "depth": 0, "is_empty": True})
                continue
            
            indent, content, trailing = match.groups()
            is_empty = (len(content) == 0)
            
            # 2. Calculate Raw Width (Tab = 4 spaces)
            current_width = 0
            for char in indent:
                current_width += 4 if char == '\t' else 1

            # 3. Determine Depth
            if is_empty:
                # Empty lines preserve the current context
                depth = len(indent_stack) - 1
            else:
                # --- THE COLON GUARD ---
                # We only allow PUSHING a new level if the previous line opened a block.
                # Otherwise, we treat extra indent as just "bad formatting" and clamp it.
                
                # Logic: Should we indent deeper?
                if current_width > indent_stack[-1]:
                    if last_line_was_block_starter:
                        # Legitimate block entry
                        indent_stack.append(current_width)
                    else:
                        # "False Nesting" detected (Staircase Effect). 
                        pass 

                # Logic: Should we dedent?
                # We always respect dedents (moving back out)
                while len(indent_stack) > 1 and current_width < indent_stack[-1]:
                    indent_stack.pop()
                
                depth = len(indent_stack) - 1
                
                # Update tracker for NEXT line
                clean_content = content.split("#")[0].strip()
                last_line_was_block_starter = clean_content.endswith(":")

            self.nodes.append({
                "id": i,
                "raw_indent": indent,
                "depth": depth, 
                "content": content,
                "trailing": trailing,
                "is_empty": is_empty
            })

    def normalize(self, use_tabs=False, space_count=4):
        """Reconstructs the code with strict indentation rules."""
        char = "\t" if use_tabs else (" " * space_count)
        clean_lines = []
        
        for node in self.nodes:
            if node["is_empty"]:
                clean_lines.append("") # Strip whitespace on empty lines
            else:
                new_indent = char * node["depth"]
                clean_lines.append(f"{new_indent}{node['content']}")
        
        self.normalized_text = "\n".join(clean_lines)
        return self.normalized_text

    def generate_patch(self):
        """
        Compares Raw vs Normalized and generates the JSON Schema Hunks.
        """
        clean_lines = self.normalized_text.splitlines()
        if not clean_lines: 
            return {"hunks": []}

        hunks = []
        current_hunk = None
        
        for i, (raw, clean) in enumerate(zip(self.raw_lines, clean_lines)):
            if raw != clean:
                if current_hunk is None:
                    current_hunk = {
                        "start_line": i,
                        "raw_block": [raw],
                        "clean_block": [clean]
                    }
                else:
                    # Check continuity
                    if i == current_hunk["start_line"] + len(current_hunk["raw_block"]):
                        current_hunk["raw_block"].append(raw)
                        current_hunk["clean_block"].append(clean)
                    else:
                        self._finalize_hunk(hunks, current_hunk)
                        current_hunk = {
                            "start_line": i,
                            "raw_block": [raw],
                            "clean_block": [clean]
                        }
            else:
                if current_hunk:
                    self._finalize_hunk(hunks, current_hunk)
                    current_hunk = None

        if current_hunk:
            self._finalize_hunk(hunks, current_hunk)

        self.patch_data = {"hunks": hunks}
        return self.patch_data

    def _finalize_hunk(self, hunks_list, hunk_data):
        search_txt = "\n".join(hunk_data["raw_block"])
        replace_txt = "\n".join(hunk_data["clean_block"])
        schema_hunk = {
            "description": f"Normalize indentation (Lines {hunk_data['start_line']}-{hunk_data['start_line'] + len(hunk_data['raw_block'])})",
            "search_block": search_txt,
            "replace_block": replace_txt,
            "use_patch_indent": False
        }
        hunks_list.append(schema_hunk)

# ==============================================================================
# 2. GUI LAYER (The Visual Cortex)
# ==============================================================================
class AppGUI:
    def __init__(self, root, engine):
        self.root = root
        self.engine = engine
        
        self.root.title("IndentArchitect // Normalization Protocol")
        self.root.geometry("1400x850")
        self.root.configure(bg="#1e1e1e")

        # Styles
        style = ttk.Style()
        style.theme_use('clam')
        style.configure("TButton", background="#333", foreground="#eee", borderwidth=1)
        style.map("TButton", background=[("active", "#444")])
        style.configure("TCheckbutton", background="#252526", foreground="#eee")
        style.configure("TLabel", background="#252526", foreground="#eee")
        
        self.font_mono = ("Consolas", 10)
        self.font_ui = ("Segoe UI", 9)

        # Variables
        self.var_use_tabs = tk.BooleanVar(value=False)
        self.var_space_count = tk.IntVar(value=4)
        self.var_use_suffix = tk.BooleanVar(value=True)
        self.var_suffix = tk.StringVar(value="_clean")
        
        self.setup_layout()

    def setup_layout(self):
        # --- HEADER / TOOLBAR ---
        header = tk.Frame(self.root, bg="#252526", height=50)
        header.pack(fill=tk.X, pady=(0, 2))
        
        # Section 1: Branding & Load
        f_load = tk.Frame(header, bg="#252526")
        f_load.pack(side=tk.LEFT, padx=10)
        tk.Label(f_load, text="INDENT ARCHITECT", bg="#252526", fg="#007acc", font=("Segoe UI", 11, "bold")).pack(side=tk.LEFT, padx=(0, 10))
        tk.Button(f_load, text="Load File...", command=self.load_file, bg="#3c3c3c", fg="white", relief=tk.FLAT).pack(side=tk.LEFT)

        # Separator
        ttk.Separator(header, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=10, pady=5)

        # Section 2: Indentation Settings
        f_settings = tk.Frame(header, bg="#252526")
        f_settings.pack(side=tk.LEFT)
        
        tk.Label(f_settings, text="Format:", font=self.font_ui).pack(side=tk.LEFT, padx=(0,5))
        
        self.chk_tabs = ttk.Checkbutton(f_settings, text="Use Tabs", variable=self.var_use_tabs, command=self.run_normalization)
        self.chk_tabs.pack(side=tk.LEFT, padx=5)
        
        tk.Label(f_settings, text="Spaces:", font=self.font_ui).pack(side=tk.LEFT, padx=(5,2))
        self.spin_spaces = tk.Spinbox(f_settings, from_=1, to=8, textvariable=self.var_space_count, width=3, bg="#333", fg="white", buttonbackground="#444")
        self.spin_spaces.pack(side=tk.LEFT)
        # Re-run norm when spinbox changes (bind release/enter)
        self.spin_spaces.bind("<KeyRelease>", lambda e: self.run_normalization())
        self.spin_spaces.bind("<ButtonRelease-1>", lambda e: self.run_normalization())

        # Separator
        ttk.Separator(header, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=10, pady=5)

        # Section 3: Action & Save
        f_action = tk.Frame(header, bg="#252526")
        f_action.pack(side=tk.LEFT)

        tk.Button(f_action, text="Re-Normalize", command=self.run_normalization, bg="#0e639c", fg="white", relief=tk.FLAT).pack(side=tk.LEFT, padx=5)
        
        # Versioning Controls
        f_ver = tk.Frame(f_action, bg="#2d2d2d", padx=5, pady=2) # Slightly darker grouping
        f_ver.pack(side=tk.LEFT, padx=10)
        
        ttk.Checkbutton(f_ver, text="Add Suffix:", variable=self.var_use_suffix).pack(side=tk.LEFT)
        tk.Entry(f_ver, textvariable=self.var_suffix, width=8, bg="#333", fg="#888", insertbackground="white").pack(side=tk.LEFT, padx=2)
        
        # Save Buttons
        tk.Button(f_action, text="Save", command=self.save_file, bg="#2da042", fg="white", relief=tk.FLAT).pack(side=tk.LEFT, padx=5)
        tk.Button(f_action, text="Save As...", command=self.save_as_file, bg="#333", fg="white", relief=tk.FLAT).pack(side=tk.LEFT, padx=0)

        # --- MAIN PANE ---
        paned = tk.PanedWindow(self.root, orient=tk.HORIZONTAL, bg="#1e1e1e", sashwidth=4)
        paned.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        # Pane 1: Dirty Input
        f1 = tk.LabelFrame(paned, text="Raw Input (Dirty)", bg="#1e1e1e", fg="#888")
        paned.add(f1, minsize=350)
        self.txt_input = scrolledtext.ScrolledText(f1, bg="#1e1e1e", fg="#d4d4d4", font=self.font_mono, insertbackground="white", undo=True)
        self.txt_input.pack(fill=tk.BOTH, expand=True)

        # Pane 2: Clean Output
        f2 = tk.LabelFrame(paned, text="Normalized Output (Preview)", bg="#1e1e1e", fg="#888")
        paned.add(f2, minsize=350)
        self.txt_clean = scrolledtext.ScrolledText(f2, bg="#1e1e1e", fg="#a6e22e", font=self.font_mono, insertbackground="white")
        self.txt_clean.pack(fill=tk.BOTH, expand=True)

        # Pane 3: JSON Patch
        f3 = tk.LabelFrame(paned, text="Patch Logic (JSON)", bg="#1e1e1e", fg="#888")
        paned.add(f3, minsize=300)
        self.txt_json = scrolledtext.ScrolledText(f3, bg="#2d2d2d", fg="#66d9ef", font=self.font_mono)
        self.txt_json.pack(fill=tk.BOTH, expand=True)

        # --- STATUS BAR ---
        self.status_var = tk.StringVar(value="Ready.")
        sb = tk.Label(self.root, textvariable=self.status_var, bg="#007acc", fg="white", anchor="w", font=self.font_ui)
        sb.pack(side=tk.BOTTOM, fill=tk.X)

    def load_file(self):
        path = filedialog.askopenfilename(filetypes=[("Python Files", "*.py"), ("All Files", "*.*")])
        if path:
            try:
                with open(path, "r", encoding="utf-8") as f:
                    content = f.read()
                self.txt_input.delete("1.0", tk.END)
                self.txt_input.insert("1.0", content)
                
                # Load into engine with filepath awareness
                self.engine.load_source(content, filepath=path)
                self.status_var.set(f"Loaded: {path}")
                
                # Auto-normalize on load
                self.run_normalization()
            except Exception as e:
                messagebox.showerror("Error", str(e))

    def run_normalization(self):
        raw_text = self.txt_input.get("1.0", tk.END).strip("\n")
        
        # Load text again (in case user edited the dirty pane)
        self.engine.load_source(raw_text, filepath=self.engine.current_filepath)
        
        # Get Settings
        use_tabs = self.var_use_tabs.get()
        try:
            space_count = int(self.var_space_count.get())
        except ValueError:
            space_count = 4

        clean_text = self.engine.normalize(use_tabs=use_tabs, space_count=space_count)
        patch_data = self.engine.generate_patch()

        # Update GUI
        self.txt_clean.delete("1.0", tk.END)
        self.txt_clean.insert("1.0", clean_text)
        
        self.txt_json.delete("1.0", tk.END)
        self.txt_json.insert("1.0", json.dumps(patch_data, indent=2))
        
        self.status_var.set(f"Normalized: {len(patch_data['hunks'])} adjustments made.")

    def save_file(self):
        """Smart Save: Overwrites or Versions based on checkbox."""
        content = self.txt_clean.get("1.0", tk.END).strip("\n")
        if not content:
            messagebox.showwarning("Warning", "Nothing to save!")
            return

        original_path = self.engine.current_filepath
        if not original_path:
            self.save_as_file()
            return

        target_path = original_path
        
        # Versioning Logic
        if self.var_use_suffix.get():
            directory, filename = os.path.split(original_path)
            name, ext = os.path.splitext(filename)
            suffix = self.var_suffix.get()
            target_path = os.path.join(directory, f"{name}{suffix}{ext}")

        try:
            with open(target_path, "w", encoding="utf-8") as f:
                f.write(content)
            self.status_var.set(f"Saved to: {target_path}")
            messagebox.showinfo("Success", f"File saved:\n{target_path}")
        except Exception as e:
            messagebox.showerror("Error", f"Could not save file:\n{e}")

    def save_as_file(self):
        content = self.txt_clean.get("1.0", tk.END).strip("\n")
        target_path = filedialog.asksaveasfilename(
            defaultextension=".py",
            filetypes=[("Python Files", "*.py"), ("All Files", "*.*")]
        )
        if target_path:
            try:
                with open(target_path, "w", encoding="utf-8") as f:
                    f.write(content)
                self.status_var.set(f"Saved As: {target_path}")
            except Exception as e:
                messagebox.showerror("Error", str(e))

# ==============================================================================
# 3. CLI LAYER (Utility)
# ==============================================================================
def run_cli():
    parser = argparse.ArgumentParser(description="IndentArchitect CLI")
    parser.add_argument("file", help="Path to python file to normalize")
    parser.add_argument("--json", action="store_true", help="Output JSON patch only")
    parser.add_argument("--write", action="store_true", help="Overwrite file with normalized version")
    parser.add_argument("--spaces", type=int, default=4, help="Number of spaces (default 4)")
    parser.add_argument("--tabs", action="store_true", help="Use tabs instead of spaces")
    args = parser.parse_args()

    engine = WhitespaceEngine()
    
    try:
        with open(args.file, "r", encoding="utf-8") as f:
            content = f.read()
            
        engine.load_source(content, filepath=args.file)
        normalized = engine.normalize(use_tabs=args.tabs, space_count=args.spaces)
        
        if args.json:
            patch = engine.generate_patch()
            print(json.dumps(patch, indent=2))
        elif args.write:
            with open(args.file, "w", encoding="utf-8") as f:
                f.write(normalized)
            print(f"File normalized: {args.file}")
        else:
            print(normalized)
            
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)

# ==============================================================================
# 4. ENTRY POINT
# ==============================================================================
def main():
    if len(sys.argv) > 1:
        run_cli()
    else:
        root = tk.Tk()
        engine = WhitespaceEngine()
        app = AppGUI(root, engine)
        root.mainloop()

if __name__ == "__main__":
    main()