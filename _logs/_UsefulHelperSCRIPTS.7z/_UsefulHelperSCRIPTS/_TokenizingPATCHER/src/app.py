import sys
import argparse
import tkinter as tk
from tkinter import ttk, filedialog, scrolledtext
import os
import json
import re
import datetime
import difflib
from dataclasses import dataclass, field

# ==============================================================================
# INTERNAL UI HELPERS (Dependency Replacement)
# ==============================================================================

@dataclass
class ButtonConfig:
    text: str
    command: callable
    bg_color: str
    active_bg_color: str
    fg_color: str = "#FFFFFF"

@dataclass
class LinkConfig:
    """Configuration for the 'Linked' state (The Trap)"""
    trap_bg: str = "#7C3AED"    # Deep Purple
    btn_bg: str = "#8B5CF6"     # Lighter Purple
    text_color: str = "#FFFFFF"

class LocalUnifiedButtonGroup(tk.Frame):
    """
    The robust 'UnifiedButtonGroup' that supports linking actions (The Trap).
    """
    def __init__(self, parent, left_btn: ButtonConfig, right_btn: ButtonConfig, link_config: LinkConfig = None, **kwargs):
        super().__init__(parent, **kwargs)
        
        self.left_cfg = left_btn
        self.right_cfg = right_btn
        self.link_cfg = link_config or LinkConfig()
        
        self.is_linked = False
        # Try to grab parent bg, default to dark theme if failing
        try: 
            self.default_bg = parent.cget("bg")
        except: 
            self.default_bg = "#0f172a"

        self._setup_ui()
        self._update_state()

    def _setup_ui(self):
        self.config(padx=4, pady=4)
        
        # Base style for buttons
        common_style = {"relief": "flat", "font": ("Segoe UI", 9, "bold"), "bd": 0, "cursor": "hand2", "padx": 15, "pady": 5}
        link_style = {"relief": "flat", "font": ("Segoe UI", 10, "bold"), "bd": 0, "cursor": "hand2"}

        # 1. Left Button
        self.btn_left = tk.Button(self, command=lambda: self._execute("left"), **common_style)
        self.btn_left.pack(side="left", fill="y", padx=(0, 2))

        # 2. Link Toggle (The Chain)
        self.btn_link = tk.Button(self, text="&", width=3, command=self._toggle_link, **link_style)
        self.btn_link.pack(side="left", fill="y", padx=(0, 2))

        # 3. Right Button
        self.btn_right = tk.Button(self, command=lambda: self._execute("right"), **common_style)
        self.btn_right.pack(side="left", fill="y")

    def _toggle_link(self):
        self.is_linked = not self.is_linked
        self._update_state()

    def _update_state(self):
        if self.is_linked:
            # --- LINKED STATE (The Trap) ---
            self.config(bg=self.link_cfg.trap_bg)
            
            # Both buttons look identical in the "Trap"
            for btn in (self.btn_left, self.btn_right, self.btn_link):
                btn.config(bg=self.link_cfg.btn_bg, fg=self.link_cfg.text_color, activebackground=self.link_cfg.trap_bg)
            
            # Keep original text
            self.btn_left.config(text=self.left_cfg.text)
            self.btn_right.config(text=self.right_cfg.text)

        else:
            # --- INDEPENDENT STATE ---
            self.config(bg=self.default_bg)

            # Restore Left Button
            self.btn_left.config(
                text=self.left_cfg.text, 
                bg=self.left_cfg.bg_color, 
                fg=self.left_cfg.fg_color,
                activebackground=self.left_cfg.active_bg_color
            )

            # Restore Right Button
            self.btn_right.config(
                text=self.right_cfg.text, 
                bg=self.right_cfg.bg_color, 
                fg=self.left_cfg.fg_color,
                activebackground=self.right_cfg.active_bg_color
            )

            # Restore Link Button (Neutral Gray/Dark)
            self.btn_link.config(bg="#334155", fg="#94a3b8", activebackground="#475569")

    def _execute(self, source):
        if self.is_linked:
            # Chain them: Left then Right
            self.left_cfg.command()
            self.right_cfg.command()
        else:
            if source == "left": self.left_cfg.command()
            elif source == "right": self.right_cfg.command()

# ==============================================================================
# CORE LOGIC (Headless/Shared)
# ==============================================================================

class PatchError(Exception):
    pass

class StructuredLine:
    """Represents a single line split into indent + content + trailing whitespace."""
    __slots__ = ["indent", "content", "trailing", "original"]

    def __init__(self, line: str):
        self.original = line
        # Capture leading whitespace, core content, and trailing whitespace
        m = re.match(r"(^[ \t]*)(.*?)([ \t]*$)", line, re.DOTALL)
        if m:
            self.indent, self.content, self.trailing = m.group(1), m.group(2), m.group(3)
        else:
            self.indent, self.content, self.trailing = "", line, ""

    def reconstruct(self) -> str:
        return f"{self.indent}{self.content}{self.trailing}"

def tokenize_text(text: str):
    """Tokenize the raw file into StructuredLine objects and detect newline style."""
    if "\r\n" in text:
        newline = "\r\n"
    elif "\n" in text:
        newline = "\n"
    else:
        newline = "\n"

    raw_lines = text.splitlines()
    lines = [StructuredLine(l) for l in raw_lines]
    return lines, newline

def locate_hunk(file_lines, search_lines, floating=False):
    """Locate the hunk's search_lines inside file_lines."""
    if not search_lines:
        return []

    matches = []
    max_start = len(file_lines) - len(search_lines)
    for start in range(max_start + 1):
        ok = True
        for i, s in enumerate(search_lines):
            f = file_lines[start + i]
            if floating:
                # Compare logical content only
                if f.content != s.content:
                    ok = False
                    break
            else:
                # Compare fully reconstructed lines
                if f.reconstruct() != s.reconstruct():
                    ok = False
                    break
        if ok:
            matches.append(start)

    return matches

def apply_patch_text(original_text: str, patch_obj: dict, global_force_indent: bool = False) -> str:
    """Apply a patch schema instance to original_text and return the new text."""
    if not isinstance(patch_obj, dict) or "hunks" not in patch_obj:
        raise PatchError("Patch must be a dict with a 'hunks' list.")

    hunks = patch_obj.get("hunks", [])
    if not isinstance(hunks, list):
        raise PatchError("'hunks' must be a list.")

    file_lines, newline = tokenize_text(original_text)

    # First pass: compute all applications (start/end/replacements)
    applications = []
    for idx, hunk in enumerate(hunks, start=1):
        search_block = hunk.get("search_block")
        replace_block = hunk.get("replace_block")
        use_patch_indent = hunk.get("use_patch_indent", global_force_indent)

        if search_block is None or replace_block is None:
            raise PatchError(f"Hunk {idx}: Missing 'search_block' or 'replace_block'.")

        s_lines = [StructuredLine(l) for l in search_block.splitlines()]
        r_lines = [StructuredLine(l) for l in replace_block.splitlines()]

        # 1. Strict match
        matches = locate_hunk(file_lines, s_lines, floating=False)
        # 2. Fallback: content-only match
        if not matches:
            matches = locate_hunk(file_lines, s_lines, floating=True)

        if not matches:
            raise PatchError(f"Hunk {idx}: Search block not found.")
        if len(matches) > 1:
            raise PatchError(f"Hunk {idx}: Ambiguous match ({len(matches)} found).")

        start = matches[0]
        applications.append(
            {
                "start": start,
                "end": start + len(s_lines),
                "replace_lines": r_lines,
                "use_patch_indent": bool(use_patch_indent),
                "id": idx,
            }
        )

    # Collision check: ensure no overlapping edit ranges
    applications.sort(key=lambda a: a["start"])
    for i in range(len(applications) - 1):
        if applications[i]["end"] > applications[i + 1]["start"]:
            raise PatchError(
                f"Hunks {applications[i]['id']} and {applications[i+1]['id']} overlap in the target file."
            )

    # Apply from bottom up
    for app in reversed(applications):
        start = app["start"]
        end = app["end"]
        r_lines = app["replace_lines"]
        use_patch_indent = app["use_patch_indent"]

        base_indent = ""
        # Get the indentation of the anchor point in the FILE
        if 0 <= start < len(file_lines):
            base_indent = file_lines[start].indent

        # Get the indentation of the anchor point in the PATCH (First non-empty line)
        patch_base_indent = ""
        for rl in r_lines:
            if rl.content.strip():
                patch_base_indent = rl.indent
                break

        final_block = []
        for rl in r_lines:
            # If we are strictly using patch indent, do nothing.
            # Otherwise, calculate relative indentation.
            if not use_patch_indent:
                if rl.content.strip():
                    # 1. Remove the patch's baseline indent from this line
                    #    (Careful: this assumes rl.indent starts with patch_base_indent)
                    if rl.indent.startswith(patch_base_indent):
                        relative_indent = rl.indent[len(patch_base_indent):]
                    else:
                        # Fallback: if patch is weirdly dedented, keep original
                        relative_indent = rl.indent
                    
                    # 2. Add the file's base indent + the relative indent
                    rl.indent = base_indent + relative_indent
                
                # OPTIONAL: Handle empty lines (copy base indent or leave empty?)
                # Usually leaving them empty (just \n) is safer for git/linting.

            final_block.append(rl)

        file_lines[start:end] = final_block

    return newline.join([l.reconstruct() for l in file_lines])


# ==============================================================================
# GUI MODE (Default / Showcase)
# ==============================================================================

class App:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("_TokenizingPATCHER v4.3 [System Ecosystem]")
        self.root.geometry("1100x850")
        self.root.configure(bg="#0f172a")

        self.loaded_filepath = None

        # State variables
        self.version_enabled_var = tk.BooleanVar(value=False)
        self.version_suffix_var = tk.StringVar(value="_v1.0")
        self.force_indent_var = tk.BooleanVar(value=False)
        self.is_blinking = False

        # Validation / diff preview state
        self.validation_preview_text = None
        self.validation_valid = False
        self.diff_view_var = tk.BooleanVar(value=False)

        self.setup_styles()
        self.build_ui()

    def setup_styles(self):
        style = ttk.Style()
        style.theme_use("clam")
        style.configure(
            "TButton",
            padding=6,
            relief="flat",
            background="#334155",
            foreground="white",
        )
        style.map("TButton", background=[("active", "#475569")])

        self.colors = {
            "bg": "#0f172a",
            "panel_bg": "#1e293b",
            "text": "#e2e8f0",
            "accent": "#6366f1",
            "success": "#22c55e",
            "error": "#ef4444",
            "working": "#facc15",
            "log_bg": "#020617",
            "log_fg": "#94a3b8",
        }

    def build_ui(self):
        # --- Top Toolbar ---
        toolbar = tk.Frame(self.root, bg=self.colors["bg"])
        toolbar.pack(fill="x", padx=15, pady=10)

        # File operations
        tk.Button(
            toolbar,
            text="📂 Load File",
            command=self.load_file,
            bg="#334155",
            fg="white",
            relief="flat",
        ).pack(side="left", padx=(0, 5))

        tk.Button(
            toolbar,
            text="💾 Save Result",
            command=self.save_file,
            bg="#334155",
            fg="white",
            relief="flat",
        ).pack(side="left", padx=5)

        # Versioning controls
        v_frame = tk.Frame(toolbar, bg=self.colors["bg"])
        v_frame.pack(side="left", padx=15)

        chk_ver = tk.Checkbutton(
            v_frame,
            text="Version",
            variable=self.version_enabled_var,
            bg=self.colors["bg"],
            fg="#cbd5e1",
            selectcolor=self.colors["bg"],
            activebackground=self.colors["bg"],
            activeforeground="white",
        )
        chk_ver.pack(side="left")

        tk.Label(
            v_frame,
            text="Suffix:",
            bg=self.colors["bg"],
            fg="#64748b",
        ).pack(side="left", padx=(10, 5))

        tk.Entry(
            v_frame,
            textvariable=self.version_suffix_var,
            width=10,
        ).pack(side="left")

        # --- Main Paned Layout ---
        paned = tk.PanedWindow(
            self.root,
            orient="horizontal",
            sashrelief="raised",
            bg=self.colors["bg"],
        )
        paned.pack(fill="both", expand=True, padx=15, pady=5)

        # LEFT PANE
        left_frame = tk.Frame(paned, bg=self.colors["panel_bg"])
        l_hdr = tk.Frame(left_frame, bg=self.colors["panel_bg"])
        l_hdr.pack(fill="x", padx=5, pady=5)

        self.lbl_left_title = tk.Label(
            l_hdr,
            text="TARGET SOURCE CODE",
            fg="#94a3b8",
            bg=self.colors["panel_bg"],
            font=("Segoe UI", 8, "bold"),
        )
        self.lbl_left_title.pack(side="left")

        self.txt_file = scrolledtext.ScrolledText(
            left_frame,
            bg=self.colors["panel_bg"],
            fg=self.colors["text"],
            insertbackground="white",
            borderwidth=0,
        )
        self.txt_file.pack(fill="both", expand=True)

        paned.add(left_frame)

        # RIGHT PANE
        right_frame = tk.Frame(paned, bg=self.colors["panel_bg"])
        r_hdr = tk.Frame(right_frame, bg=self.colors["panel_bg"])
        r_hdr.pack(fill="x", padx=5, pady=5)

        self.lbl_patch_title = tk.Label(
            r_hdr,
            text="Patch: UNVALIDATED",
            fg="#94a3b8",
            bg=self.colors["panel_bg"],
            font=("Segoe UI", 8, "bold"),
        )
        self.lbl_patch_title.pack(side="left")

        tk.Button(
            r_hdr,
            text="📋 Schema",
            command=self.copy_schema_to_clipboard,
            bg="#334155",
            fg="white",
            font=("Segoe UI", 8),
            relief="flat",
        ).pack(side="right", padx=5)

        self.txt_patch = scrolledtext.ScrolledText(
            right_frame,
            bg="#020617",
            fg="#cbd5e1",
            insertbackground="white",
            borderwidth=0,
        )
        self.txt_patch.pack(fill="both", expand=True)
        self.txt_patch.insert("1.0", self.get_schema_template())

        paned.add(right_frame)

        # --- Action Footer ---
        footer = tk.Frame(self.root, bg=self.colors["bg"])
        footer.pack(fill="x", padx=15, pady=10)

        chk_indent = tk.Checkbutton(
            footer,
            text="Force Patch Indentation (Strict Whitespace)",
            variable=self.force_indent_var,
            bg=self.colors["bg"],
            fg="#cbd5e1",
            selectcolor=self.colors["bg"],
            activebackground=self.colors["bg"],
            activeforeground="white",
        )
        chk_indent.pack(side="left")

        chk_diff = tk.Checkbutton(
            footer,
            text="Show Diff Preview",
            variable=self.diff_view_var,
            bg=self.colors["bg"],
            fg="#cbd5e1",
            selectcolor=self.colors["bg"],
            activebackground=self.colors["bg"],
            activeforeground="white",
            command=self.on_diff_toggle,
        )
        chk_diff.pack(side="left", padx=(10, 0))

        # Unified Validate / Apply group
        btn_val_config = ButtonConfig(
            text="Validate",
            command=self.validate_patch,
            bg_color="#10B981",  # Emerald Green
            active_bg_color="#059669"
        )

        btn_apply_config = ButtonConfig(
            text="Apply",
            command=self.apply_patch,
            bg_color="#2563EB",  # Royal Blue
            active_bg_color="#1D4ED8"
        )

        # Using the Local replacement here
        self.button_group = LocalUnifiedButtonGroup(
            parent=footer,
            left_btn=btn_val_config,
            right_btn=btn_apply_config
        )
        self.button_group.pack(side="right")

        # --- Log Window ---
        self.debug_out = scrolledtext.ScrolledText(
            self.root,
            height=6,
            bg=self.colors["log_bg"],
            fg=self.colors["log_fg"],
            insertbackground="white",
            borderwidth=0,
            font=("Consolas", 9),
        )
        self.debug_out.pack(fill="x", padx=15, pady=(0, 5))

        # --- Status Bar (Blinking) ---
        self.status_bar = tk.Label(
            self.root,
            text="Ready",
            bg=self.colors["bg"],
            fg=self.colors["success"],
            font=("Consolas", 10),
            anchor="w",
            padx=15,            pady=5,
        )
        self.status_bar.pack(fill="x", side="bottom")

    # --- Status / Blink Helpers ---

    def set_status(self, msg, state="info"):
        colors = {
            "info": self.colors["success"],
            "error": self.colors["error"],
            "working": self.colors["working"],
        }
        color = colors.get(state, self.colors["success"])

        # 1. Status label text
        self.status_bar.config(text=msg, fg=color)
        if state == "working":
            self.start_blink()
        else:
            self.stop_blink()

        # 2. Log window
        timestamp = datetime.datetime.now().strftime("%H:%M:%S")
        prefix = "ERROR: " if state == "error" else ""
        log_entry = f"[{timestamp}] {prefix}{msg}\n"
        self.debug_out.insert(tk.END, log_entry)
        self.debug_out.see(tk.END)

    def start_blink(self):
        self.is_blinking = True
        self._blink_loop()

    def stop_blink(self):
        self.is_blinking = False
        # Reset to working color when stopping from blink
        try:
            self.status_bar.config(fg=self.colors["success"])
        except Exception:
            pass

    def _blink_loop(self):
        if not self.is_blinking:
            return
        current_fg = self.status_bar.cget("foreground")
        next_fg = self.colors["bg"] if current_fg == self.colors["working"] else self.colors["working"]
        self.status_bar.config(fg=next_fg)
        self.root.after(600, self._blink_loop)

    # --- File Logic & Diff Preview ---

    def load_file(self):
        path = filedialog.askopenfilename()
        if not path:
            return
        try:
            with open(path, "r", encoding="utf-8") as f:
                content = f.read()
            self.txt_file.delete("1.0", tk.END)
            self.txt_file.insert("1.0", content)
            self.loaded_filepath = path

            # Reset panel titles
            self.lbl_left_title.config(text="TARGET SOURCE CODE")
            self.lbl_patch_title.config(text="Patch: UNVALIDATED")

            # Reset validation / diff state
            self.validation_preview_text = None
            self.validation_valid = False
            self.diff_view_var.set(False)

            self.set_status(f"Loaded: {path}", "info")
        except Exception as e:
            self.set_status(f"Error loading file: {e}", "error")

    def save_file(self):
        orig = self.loaded_filepath
        if orig and self.version_enabled_var.get():
            d, f = os.path.split(orig)
            base, ext = os.path.splitext(f)
            suffix = self.version_suffix_var.get()
            if suffix and not suffix.startswith("_"):
                suffix = "_" + suffix
            filename = f"{base}{suffix}{ext}"
            path = os.path.join(d, filename)
        elif orig:
            path = orig
        else:
            path = filedialog.asksaveasfilename(defaultextension=".txt")

        if not path:
            return

        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write(self.txt_file.get("1.0", tk.END))
            self.set_status(f"Saved to: {os.path.basename(path)}", "info")
        except Exception as e:
            self.set_status(f"Save failed: {e}", "error")

    def get_schema_template(self):
        return (
            "{\n"
            "  \"hunks\": [\n"
            "    {\n"
            "      \"description\": \"Short human description\",\n"
            "      \"search_block\": \"exact text to find\\n(can span multiple lines)\",\n"
            "      \"replace_block\": \"replacement text\\n(same or different length)\",\n"
            "      \"use_patch_indent\": false\n"
            "    }\n"
            "  ]\n"
            "}\n"
        )

    def copy_schema_to_clipboard(self):
        self.root.clipboard_clear()
        self.root.clipboard_append(self.get_schema_template())
        self.set_status("Schema copied to clipboard.", "info")

    def _show_diff_view(self, original_text: str, preview_text: str):
        orig_lines = original_text.splitlines()
        new_lines = preview_text.splitlines()
        diff_lines = difflib.unified_diff(
            orig_lines,
            new_lines,
            fromfile="original",
            tofile="preview",
            lineterm="",
        )
        diff_text = "\n".join(diff_lines) or "(No differences)\n"
        self.txt_file.delete("1.0", tk.END)
        self.txt_file.insert("1.0", diff_text)

    def on_diff_toggle(self):
        # Only meaningful if we have a valid preview
        if not self.validation_valid or not self.validation_preview_text:
            return

        current_source = self.txt_file.get("1.0", tk.END)
        # If diff is being turned on, show diff between current source and preview
        if self.diff_view_var.get():
            self._show_diff_view(current_source, self.validation_preview_text)
        else:
            # Restore plain source view (just show current source as-is)
            self.txt_file.delete("1.0", tk.END)
            self.txt_file.insert("1.0", current_source)

    # --- Validate / Apply ---

    def validate_patch(self):
        original_text = self.txt_file.get("1.0", tk.END)
        patch_text = self.txt_patch.get("1.0", tk.END)
        force = self.force_indent_var.get()

        try:
            patch_obj = json.loads(patch_text)
            preview_text = apply_patch_text(
                original_text,
                patch_obj,
                global_force_indent=force,
            )

            self.validation_preview_text = preview_text
            self.validation_valid = True

            self.lbl_patch_title.config(text="Patch: VALIDATED (DRY RUN)")
            self.set_status("Validation succeeded (dry run).", "info")

            if self.diff_view_var.get():
                self._show_diff_view(original_text, preview_text)
            else:
                # Ensure left panel shows the original text
                self.txt_file.delete("1.0", tk.END)
                self.txt_file.insert("1.0", original_text)

        except json.JSONDecodeError:
            self.validation_preview_text = None
            self.validation_valid = False
            self.lbl_patch_title.config(text="Patch: UNVALIDATED")
            self.set_status("Error: Invalid JSON. Check formatting.", "error")

        except PatchError as e:
            self.validation_preview_text = None
            self.validation_valid = False
            self.lbl_patch_title.config(text="Patch: UNVALIDATED")
            self.set_status(f"Patch Error during validation: {e}", "error")

        except Exception as e:
            self.validation_preview_text = None
            self.validation_valid = False
            self.lbl_patch_title.config(text="Patch: UNVALIDATED")
            self.set_status(
                f"System Error during validation: {e}",
                "error",
            )

    def apply_patch(self):
        target_text = self.txt_file.get("1.0", tk.END)
        patch_text = self.txt_patch.get("1.0", tk.END)
        force = self.force_indent_var.get()

        try:
            if self.validation_valid and self.validation_preview_text:
                new_text = self.validation_preview_text
            else:
                patch_obj = json.loads(patch_text)
                new_text = apply_patch_text(
                    target_text,
                    patch_obj,
                    global_force_indent=force,
                )

            self.txt_file.delete("1.0", tk.END)
            self.txt_file.insert("1.0", new_text)

            # Clear validation/diff state after commit
            self.validation_preview_text = None
            self.validation_valid = False
            self.diff_view_var.set(False)

            self.lbl_left_title.config(text="PATCHED SOURCE CODE")
            self.lbl_patch_title.config(text="Patch: VALIDATED & APPLIED")
            self.set_status("Success: Patch Applied.", "info")

        except json.JSONDecodeError:
            self.lbl_patch_title.config(text="Patch: UNVALIDATED")
            self.set_status("Error: Invalid JSON.", "error")

        except PatchError as e:
            self.lbl_patch_title.config(text="Patch: UNVALIDATED")
            self.set_status(f"Patch Error: {e}", "error")

        except Exception as e:
            self.lbl_patch_title.config(text="Patch: UNVALIDATED")
            self.set_status(f"System Error: {e}", "error")

    def start(self):
        self.root.mainloop()

def run_gui():
    print("Launching GUI Mode...")
    app = App()
    app.start()

# ==============================================================================
# CLI MODE (Utility)
# ==============================================================================

def run_cli():
    """
    Command Line Interface Entry Point.
    """
    parser = argparse.ArgumentParser(description="_TokenizingPATCHER CLI")
    parser.add_argument("target", help="Path to the target source file")
    parser.add_argument("patch", help="Path to the JSON patch file")
    parser.add_argument("--output", "-o", help="Path to save the result (defaults to print stdout)")
    parser.add_argument("--force-indent", action="store_true", help="Force patch indentation")
    parser.add_argument("--dry-run", action="store_true", help="Validate only, do not write")
    
    args = parser.parse_args()
    
    # 1. Read Target
    try:
        with open(args.target, "r", encoding="utf-8") as f:
            target_text = f.read()
    except FileNotFoundError:
        print(f"Error: Target file not found: {args.target}")
        sys.exit(1)

    # 2. Read Patch
    try:
        with open(args.patch, "r", encoding="utf-8") as f:
            patch_obj = json.load(f)
    except FileNotFoundError:
        print(f"Error: Patch file not found: {args.patch}")
        sys.exit(1)
    except json.JSONDecodeError:
        print(f"Error: Patch file is not valid JSON.")
        sys.exit(1)

    # 3. Apply
    try:
        new_text = apply_patch_text(target_text, patch_obj, global_force_indent=args.force_indent)
        
        if args.dry_run:
            print("Dry Run Successful. Patch applies cleanly.")
        else:
            if args.output:
                with open(args.output, "w", encoding="utf-8") as f:
                    f.write(new_text)
                print(f"Success: Patched file written to {args.output}")
            else:
                print(new_text)
                
    except PatchError as e:
        print(f"Patch Failed: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"Unexpected Error: {e}")
        sys.exit(1)

# ==============================================================================
# HYBRID ENTRY POINT
# ==============================================================================

def main():
    if len(sys.argv) > 1:
        run_cli()
    else:
        run_gui()

if __name__ == "__main__":
    main()
