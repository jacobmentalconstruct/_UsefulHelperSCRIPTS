import sys
import pygame
import random
import time
import math

# ==============================================================================
#   C O N F I G U R A T I O N
# ==============================================================================
CONFIG = {
    "WINDOW_TITLE": "OBS Neon/Gothic Board",
    "INITIAL_W": 1280,
    "INITIAL_H": 720,
    "FPS": 60,
    "PADDING": 80,
    "TOOLBAR_HEIGHT": 60,
    
    "DEFAULT_SIZE": 130,
    "MIN_SIZE": 20,
    "MAX_SIZE": 300,
    
    # Palette Presets for Cycling
    "PALETTES": [
        (245, 245, 240), # Off-White
        (188, 19, 254),  # Neon Purple
        (0, 255, 65),    # Matrix Green
        (255, 50, 50),   # Alert Red
        (50, 150, 255),  # Ice Blue
        (255, 180, 0),   # Amber
        (5, 5, 5),       # Black
    ],
    
    "COLORS": {
        "BLACK": (5, 5, 5),
        "UI_BG": (30, 30, 30),
        "UI_TEXT": (200, 200, 200),
        "UI_HOVER": (60, 60, 60)
    }
}

# ==============================================================================
#   U T I L I T I E S
# ==============================================================================
def lerp_color(c1, c2, t):
    """Linear interpolate between color c1 and c2 by factor t (0.0 to 1.0)"""
    return (
        int(c1[0] + (c2[0] - c1[0]) * t),
        int(c1[1] + (c2[1] - c1[1]) * t),
        int(c1[2] + (c2[2] - c1[2]) * t)
    )

# ==============================================================================
#   E F F E C T S   E N G I N E
# ==============================================================================
class MatrixColumn:
    """A single falling column for Matrix II"""
    def __init__(self, x, h, font_size):
        self.x = x
        self.max_h = h
        self.y = random.randint(-h, 0)
        self.speed = random.randint(5, 12)
        self.font_size = font_size
        self.chars = []
        self.rebuild_chars()

    def rebuild_chars(self):
        # Fill column with random chars
        count = (self.max_h // self.font_size) + 2
        self.chars = [chr(random.randint(33, 126)) for _ in range(count)]

    def update(self, h):
        self.y += self.speed
        if self.y > h:
            self.y = random.randint(-h // 2, 0)
            self.speed = random.randint(5, 12)
            # Randomly morph a character occasionally
        if random.random() < 0.05:
            idx = random.randint(0, len(self.chars) - 1)
            self.chars[idx] = chr(random.randint(33, 126))

    def draw(self, screen, font):
        # Draw the "Stream" relative to y
        # We only draw the bottom N characters to look like a trail
        trail_len = 15
        grid_y = int(self.y // self.font_size)
        
        for i in range(trail_len):
            char_idx = (grid_y - i) % len(self.chars)
            if grid_y - i < 0: continue # Don't draw above screen
            
            char = self.chars[char_idx]
            draw_y = (grid_y - i) * self.font_size
            
            # Alpha fade
            alpha = 255 - (i * (255 // trail_len))
            if alpha < 0: alpha = 0
            
            # Color Logic: Head is White, Tail is Green
            color = (200, 255, 200) if i == 0 else (0, 255, 65)
            
            s = font.render(char, True, color)
            s.set_alpha(alpha)
            screen.blit(s, (self.x, draw_y))

class Particle:
    def __init__(self, w, h, p_type):
        self.w, self.h = w, h
        self.reset(p_type, random_y=True)

    def reset(self, p_type, random_y=False):
        self.type = p_type
        self.x = random.randint(0, self.w)
        self.y = random.randint(0, self.h) if random_y else -20
        
        if self.type == "rain":
            self.speed_y = random.randint(15, 25)
            self.size = random.randint(10, 20)
            self.color = (100, 100, 100)
        elif self.type == "snow":
            self.speed_y = random.randint(2, 5)
            self.x = random.randint(0, self.w)
            self.size = random.randint(2, 4)
            self.color = (200, 200, 200)
        elif self.type == "embers":
            self.y = random.randint(0, self.h) if random_y else self.h + 20
            self.speed_y = random.uniform(-1, -4)
            self.size = random.randint(2, 6)
            self.color = (255, 100, 20)
        elif self.type == "stars":
            self.speed_x = random.uniform(-0.5, -3.0)
            self.size = random.randint(1, 3)
            self.color = (255, 255, 255)
        elif self.type == "matrix":
            self.speed_y = random.randint(10, 20)
            self.size = random.randint(14, 20)
            self.char_idx = random.randint(33, 126)
            self.color = (0, 255, 65)

    def update(self, w, h, global_wind):
        if self.type == "stars":
            self.x += self.speed_x
            if self.x < 0: self.x = w
        elif self.type == "embers":
            self.x += math.sin(time.time() * 5 + self.y) * 0.5
            self.y += self.speed_y
            if self.y < -10: self.reset(self.type)
        else:
            self.y += self.speed_y
            self.x += global_wind * (0.5 if self.type == "snow" else 0.1)
            if self.y > h: self.reset(self.type)
            if self.x > w: self.x = 0
            elif self.x < 0: self.x = w

    def draw(self, screen):
        if self.type == "rain":
            pygame.draw.line(screen, self.color, (self.x, self.y), (self.x, self.y + self.size), 1)
        elif self.type == "snow" or self.type == "stars":
            pygame.draw.circle(screen, self.color, (int(self.x), int(self.y)), self.size)
        elif self.type == "embers":
            s = pygame.Surface((self.size*2, self.size*2), pygame.SRCALPHA)
            pygame.draw.circle(s, (*self.color, 150), (self.size, self.size), self.size)
            screen.blit(s, (self.x, self.y))
        elif self.type == "matrix" and font_matrix:
            char = chr(self.char_idx)
            s = font_matrix.render(char, True, self.color)
            screen.blit(s, (self.x, self.y))

class EffectManager:
    def __init__(self):
        self.particles = []
        self.matrix_cols = []
        self.active_modes = {
            "rain": False, "snow": False, "embers": False, 
            "stars": False, "storm": False, "matrix": False, "matrix2": False
        }
        self.wind_time = 0
        self.lightning_intensity = 0
        self.next_lightning = 0
        self.matrix_font = pygame.font.SysFont("consolas", 14)

    def toggle(self, mode, w, h):
        self.active_modes[mode] = not self.active_modes[mode]
        self._rebuild(w, h)

    def _rebuild(self, w, h):
        self.particles = []
        # Standard Particles
        if self.active_modes["rain"]: 
            for _ in range(100): self.particles.append(Particle(w, h, "rain"))
        if self.active_modes["snow"]:
            for _ in range(150): self.particles.append(Particle(w, h, "snow"))
        if self.active_modes["embers"]:
            for _ in range(60): self.particles.append(Particle(w, h, "embers"))
        if self.active_modes["stars"]:
            for _ in range(100): self.particles.append(Particle(w, h, "stars"))
        if self.active_modes["matrix"]:
            for _ in range(50): self.particles.append(Particle(w, h, "matrix"))
            
        # Matrix II Setup
        self.matrix_cols = []
        if self.active_modes["matrix2"]:
            col_size = 14 # roughly font width
            num_cols = w // col_size
            for i in range(num_cols):
                self.matrix_cols.append(MatrixColumn(i * col_size, h, 14))

    def update(self, w, h):
        self.wind_time += 0.01
        wind = math.sin(self.wind_time) * 2
        
        for p in self.particles: p.update(w, h, wind)
        for col in self.matrix_cols: col.update(h)

        if self.active_modes["storm"]:
            now = time.time()
            if self.lightning_intensity <= 0 and now > self.next_lightning:
                self.next_lightning = now + random.uniform(0.5, 3.0)
                self.lightning_intensity = random.randint(50, 200)
            if self.lightning_intensity > 0:
                self.lightning_intensity -= 15
        else:
            self.lightning_intensity = 0

    def draw(self, screen):
        # Draw Matrix II Bottom Layer
        for col in self.matrix_cols: col.draw(screen, self.matrix_font)
        
        # Draw Particles
        for p in self.particles: p.draw(screen)
            
        if self.lightning_intensity > 0:
            s = pygame.Surface(screen.get_size())
            s.fill((255, 255, 255))
            s.set_alpha(max(0, self.lightning_intensity))
            screen.blit(s, (0, 0))

# ==============================================================================
#   U I
# ==============================================================================
class Button:
    def __init__(self, x, y, w, h, text, callback, param=None):
        self.rect = pygame.Rect(x, y, w, h)
        self.text = text
        self.callback = callback
        self.param = param
        self.is_hovered = False

    def draw(self, screen, font):
        bg = CONFIG["COLORS"]["UI_HOVER"] if self.is_hovered else CONFIG["COLORS"]["UI_BG"]
        pygame.draw.rect(screen, bg, self.rect, border_radius=5)
        pygame.draw.rect(screen, (80, 80, 80), self.rect, 1, border_radius=5)
        txt = font.render(self.text, True, CONFIG["COLORS"]["UI_TEXT"])
        screen.blit(txt, txt.get_rect(center=self.rect.center))

    def check_hover(self, pos): self.is_hovered = self.rect.collidepoint(pos)
    def check_click(self, pos):
        if self.rect.collidepoint(pos):
            if self.param is not None: self.callback(self.param)
            else: self.callback()
            return True
        return False

# ==============================================================================
#   M A I N   E N G I N E
# ==============================================================================
class NeonBoardEngine:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((CONFIG["INITIAL_W"], CONFIG["INITIAL_H"]), pygame.RESIZABLE)
        pygame.display.set_caption(CONFIG["WINDOW_TITLE"])
        
        self.running = True
        self.text = "TYPE HERE"
        
        # State
        self.bg_color = CONFIG["COLORS"]["BLACK"]
        self.fg_color_idx = 0 # White
        self.aux_color_idx = 1 # Purple
        
        self.text_style = "normal" 
        self.font_size = CONFIG["DEFAULT_SIZE"]
        self.is_bold = True
        self.is_italic = False
        self.font_index = 0
        self.preferred_fonts = ["arial", "couriernew", "georgia", "impact", "timesnewroman"]
        
        self.effects = EffectManager()
        self.buttons = []
        self.ui_font = pygame.font.SysFont("arial", 12)
        self._init_buttons()

    def _init_buttons(self):
        y = CONFIG["INITIAL_H"] - 50
        h = 35
        # Layout: [Font/Colors] ... [Styles] ... [Weather]
        self.buttons = [
            # Color & Font
            Button(10, y, 30, h, "B", self.toggle_bold),
            Button(45, y, 30, h, "I", self.toggle_italic),
            Button(80, y, 40, h, "Font", self.cycle_font),
            Button(125, y, 30, h, "FG", self.cycle_fg),
            Button(160, y, 30, h, "Aux", self.cycle_aux),
            
            # Styles
            Button(200, y, 40, h, "Norm", self.set_style, "normal"),
            Button(245, y, 40, h, "Neon", self.set_style, "neon"),
            Button(290, y, 40, h, "Shadw", self.set_style, "shadow"),
            Button(335, y, 40, h, "Wave", self.set_style, "wave"),
            Button(380, y, 40, h, "Gltch", self.set_style, "glitch"),
            Button(425, y, 40, h, "Pop", self.set_style, "pop"),

            # Weather
            Button(480, y, 35, h, "Rain", self.toggle_fx, "rain"),
            Button(520, y, 35, h, "Snow", self.toggle_fx, "snow"),
            Button(560, y, 35, h, "Fire", self.toggle_fx, "embers"),
            Button(600, y, 35, h, "Star", self.toggle_fx, "stars"),
            Button(640, y, 35, h, "Mtrx1", self.toggle_fx, "matrix"),
            Button(680, y, 35, h, "Mtrx2", self.toggle_fx, "matrix2"),
            Button(720, y, 35, h, "Strm", self.toggle_fx, "storm"),
        ]

    def _recalc_buttons_y(self):
        y = self.screen.get_height() - 50
        for btn in self.buttons: btn.rect.y = y

    # --- Actions ---
    def toggle_bold(self): self.is_bold = not self.is_bold
    def toggle_italic(self): self.is_italic = not self.is_italic
    def cycle_font(self): self.font_index = (self.font_index + 1) % len(self.preferred_fonts)
    
    def cycle_fg(self): self.fg_color_idx = (self.fg_color_idx + 1) % len(CONFIG["PALETTES"])
    def cycle_aux(self): self.aux_color_idx = (self.aux_color_idx + 1) % len(CONFIG["PALETTES"])
    
    def set_style(self, style): 
        if self.text_style == style and style != "normal":
            self.text_style = "normal"
        else:
            self.text_style = style

    def toggle_fx(self, name): 
        self.effects.toggle(name, self.screen.get_width(), self.screen.get_height())

    # --- Run Loop ---
    def run(self):
        clock = pygame.time.Clock()
        while self.running:
            self.handle_events()
            self.effects.update(self.screen.get_width(), self.screen.get_height())
            self.draw()
            pygame.display.flip()
            clock.tick(CONFIG["FPS"])
        pygame.quit()

    def handle_events(self):
        mouse_pos = pygame.mouse.get_pos()
        for btn in self.buttons: btn.check_hover(mouse_pos)

        for event in pygame.event.get():
            if event.type == pygame.QUIT: self.running = False
            elif event.type == pygame.VIDEORESIZE: self._recalc_buttons_y()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if not any(btn.check_click(event.pos) for btn in self.buttons): pass
            elif event.type == pygame.KEYDOWN:
                # F-Key Background Themes
                if event.key == pygame.K_F1: self.bg_color = CONFIG["COLORS"]["BLACK"]
                elif event.key == pygame.K_F2: self.bg_color = (0, 0, 0) # Terminal
                elif event.key == pygame.K_F3: self.bg_color = (43, 58, 40) # Chalk
                elif event.key == pygame.K_F4: self.bg_color = (15, 15, 15) # Gothic
                
                elif event.key == pygame.K_ESCAPE: self.text = ""
                elif event.key == pygame.K_BACKSPACE: self.text = self.text[:-1]
                elif event.key == pygame.K_RETURN: self.text += "\n"
                else:
                    if self.text == "TYPE HERE": self.text = ""
                    if len(event.unicode) > 0 and event.unicode.isprintable(): self.text += event.unicode

    # --- Draw ---
    def draw(self):
        w, h = self.screen.get_size()
        self.screen.fill(self.bg_color)

        # 1. Effects
        self.effects.draw(self.screen)

        # 2. Text Configuration
        font_name = self.preferred_fonts[self.font_index]
        font = pygame.font.SysFont(font_name, self.font_size, self.is_bold, self.is_italic)
        
        fg = CONFIG["PALETTES"][self.fg_color_idx]
        aux = CONFIG["PALETTES"][self.aux_color_idx]
        
        lines = self.wrap_text(self.text, font, w - (CONFIG["PADDING"]*2))
        total_h = len(lines) * font.get_linesize()
        start_y = (h // 2) - (total_h // 2)

        # 3. Render Text
        for i, line in enumerate(lines):
            line_y = start_y + (i * font.get_linesize())
            line_w = font.size(line)[0]
            line_x = (w // 2) - (line_w // 2)
            
            # Universal "Cutout" Stroke (The standard graphic design trap)
            # We draw a thin stroke in BG color around EVERYTHING to separate it from particles
            self._render_stroke(line, line_x, line_y, font, self.bg_color, 2)
            
            if self.text_style == "normal":
                # Clean Look (Subtle outline)
                self._render_stroke(line, line_x, line_y, font, aux, 2)
                self.screen.blit(font.render(line, True, fg), (line_x, line_y))
            
            elif self.text_style == "neon":
                self._render_neon(line, line_x, line_y, font, fg, aux)

            elif self.text_style == "shadow":
                self._render_shadow(line, line_x, line_y, font, fg)

            elif self.text_style == "wave":
                self._render_wave(line, line_x, line_y, font, fg)
                
            elif self.text_style == "glitch":
                self._render_glitch(line, line_x, line_y, font, fg)
                
            elif self.text_style == "pop":
                # THE SMART TRAP: 20% FG / 80% BG
                trap_col = lerp_color(fg, self.bg_color, 0.8)
                # Thick stroke with transition color
                self._render_stroke(line, line_x, line_y, font, trap_col, 6)
                # Main Text
                self.screen.blit(font.render(line, True, fg), (line_x, line_y))

        # 4. UI
        pygame.draw.rect(self.screen, (10,10,10), (0, h-CONFIG["TOOLBAR_HEIGHT"], w, CONFIG["TOOLBAR_HEIGHT"]))
        for btn in self.buttons: btn.draw(self.screen, self.ui_font)

    # --- Renderers ---
    def wrap_text(self, text, font, max_w):
        lines = []
        for raw in text.split('\n'):
            words = raw.split(' ')
            cur = []
            for word in words:
                if font.size(' '.join(cur + [word]))[0] < max_w: cur.append(word)
                else: lines.append(' '.join(cur)); cur = [word]
            lines.append(' '.join(cur))
        return lines

    def _render_stroke(self, text, x, y, font, color, width):
        # Brute force 8-way stroke
        s = font.render(text, True, color)
        for ox in range(-width, width+1):
            for oy in range(-width, width+1):
                if ox == 0 and oy == 0: continue
                self.screen.blit(s, (x+ox, y+oy))

    def _render_neon(self, text, x, y, font, color, glow):
        if random.random() < 0.02:
            temp_glow = (max(0, glow[0]-100), max(0, glow[1]-100), max(0, glow[2]-100))
            self._render_stroke(text, x, y, font, temp_glow, 4)
        else:
            self._render_stroke(text, x, y, font, glow, 4)
        self.screen.blit(font.render(text, True, color), (x, y))

    def _render_shadow(self, text, x, y, font, color):
        s_shad = font.render(text, True, (0, 0, 0))
        self.screen.blit(s_shad, (x+6, y+6))
        self.screen.blit(font.render(text, True, color), (x, y))

    def _render_wave(self, text, x, y, font, color):
        off_x = x
        t = time.time() * 5
        for i, char in enumerate(text):
            cy = y + math.sin(t + i*0.5) * 10
            s = font.render(char, True, color)
            self.screen.blit(s, (off_x, cy))
            off_x += s.get_width()

    def _render_glitch(self, text, x, y, font, color):
        s = font.render(text, True, color)
        w, h = s.get_size()
        s.set_alpha(200)
        self.screen.blit(s, (x, y))
        if random.random() < 0.9: 
            rect = pygame.Rect(0, 0, w, h//2)
            self.screen.blit(s, (x + random.choice([-5, 5]), y), area=rect)

if __name__ == "__main__":
    NeonBoardEngine().run()
