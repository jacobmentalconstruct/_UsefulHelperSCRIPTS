#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
== Tasklist Chat Prototype (Tkinter + Ollama) ==

A basic chat interface with:
- chat transcript
- tasklist editor popup (add/edit/remove steps)
- thought bubbles side panel (helper model summaries per step)

Entry:
- GUI (default): py -m src.app
- CLI (optional later): py -m src.app --help
"""

import sys
import argparse
import tkinter as tk
from tkinter import ttk, messagebox

from src._microservices.runner import run_tasklist


# -----------------------------
# Core (importable)
# -----------------------------

def new_state() -> dict:
    return {
        "chat": {
            "history": [],
            "last_user": "",
            "last_response": ""
        },
        "working": {
            "step_outputs": {},
            "thoughts": [],
            "notes": []
        },
        "outputs": {
            "final": ""
        }
    }


def default_tasklist() -> dict:
    """
    Start with something that demonstrates chaining + thought bubbles.
    """
    return {
        "name": "default_v0",
        "steps": [
            {
                "id": "S1",
                "name": "Draft answer",
                "enabled": True,
                "model": "",  # empty -> use selected chat model
                "ollama_options": {"temperature": 0.4},
                "system_prompt": "You are a helpful assistant. Answer clearly.",
                "user_prompt_template": "{{state.chat.last_user}}",
                "chain_mode": "none",
                "expects": "text",
                "output_key": "working.step_outputs.S1",
                "thought_enabled": True
            },
            {
                "id": "S2",
                "name": "Refine / tighten",
                "enabled": True,
                "model": "",  # empty -> use selected chat model
                "ollama_options": {"temperature": 0.2},
                "system_prompt": "Rewrite the prior answer to be tighter and more actionable.",
                "user_prompt_template": "Improve the following answer:\n\n{{last}}",
                "chain_mode": "replace",
                "expects": "text",
                "output_key": "outputs.final",
                "thought_enabled": True
            }
        ]
    }


# -----------------------------
# Tkinter UI
# -----------------------------

DARK_BG = "#0f1115"
PANEL_BG = "#141822"
ENTRY_BG = "#0b0e14"
FG = "#e7e7e7"
ACCENT = "#2a6ef2"


class TasklistEditor(tk.Toplevel):
    """
    Minimal “form-like” editor:
    - list of steps
    - add/edit/remove
    """
    def __init__(self, master, tasklist: dict):
        super().__init__(master)
        self.title("Tasklist Editor")
        self.configure(bg=DARK_BG)
        self.geometry("900x500")
        self.transient(master)
        self.grab_set()

        self.tasklist = tasklist

        self.columnconfigure(0, weight=1)
        self.rowconfigure(0, weight=1)

        frame = ttk.Frame(self, style="Panel.TFrame")
        frame.grid(row=0, column=0, sticky="nsew", padx=10, pady=10)
        frame.columnconfigure(0, weight=1)
        frame.rowconfigure(0, weight=1)

        self.tree = ttk.Treeview(frame, columns=("enabled", "name", "chain"), show="headings")
        self.tree.heading("enabled", text="On")
        self.tree.heading("name", text="Name")
        self.tree.heading("chain", text="Chain")
        self.tree.column("enabled", width=50, anchor="center")
        self.tree.column("name", width=350)
        self.tree.column("chain", width=120, anchor="center")
        self.tree.grid(row=0, column=0, sticky="nsew")

        btns = ttk.Frame(frame, style="Panel.TFrame")
        btns.grid(row=1, column=0, sticky="ew", pady=(10, 0))
        btns.columnconfigure(5, weight=1)

        ttk.Button(btns, text="Add Step", command=self.add_step).grid(row=0, column=0, padx=5)
        ttk.Button(btns, text="Edit Step", command=self.edit_selected).grid(row=0, column=1, padx=5)
        ttk.Button(btns, text="Remove", command=self.remove_selected).grid(row=0, column=2, padx=5)
        ttk.Button(btns, text="Close", command=self.destroy).grid(row=0, column=6, padx=5)

        self.refresh()

    def refresh(self):
        for i in self.tree.get_children():
            self.tree.delete(i)
        for step in self.tasklist.get("steps", []):
            self.tree.insert(
                "",
                "end",
                iid=step["id"],
                values=("✓" if step.get("enabled", True) else "", step.get("name", ""), step.get("chain_mode", "none"))
            )

    def add_step(self):
        step_id = f"S{len(self.tasklist.get('steps', [])) + 1}"
        self.tasklist["steps"].append({
            "id": step_id,
            "name": f"Step {step_id}",
            "enabled": True,
            "model": "",
            "ollama_options": {"temperature": 0.3},
            "system_prompt": "",
            "user_prompt_template": "{{last}}",
            "chain_mode": "replace",
            "expects": "text",
            "output_key": f"working.step_outputs.{step_id}",
            "thought_enabled": True
        })
        self.refresh()

    def _get_selected_step(self):
        sel = self.tree.selection()
        if not sel:
            return None
        sid = sel[0]
        for step in self.tasklist.get("steps", []):
            if step.get("id") == sid:
                return step
        return None

    def edit_selected(self):
        step = self._get_selected_step()
        if not step:
            return

        StepEditor(self, step, on_save=self.refresh)

    def remove_selected(self):
        step = self._get_selected_step()
        if not step:
            return
        self.tasklist["steps"] = [s for s in self.tasklist.get("steps", []) if s.get("id") != step.get("id")]
        self.refresh()


class StepEditor(tk.Toplevel):
    def __init__(self, master, step: dict, on_save):
        super().__init__(master)
        self.title(f"Edit Step: {step.get('id')}")
        self.configure(bg=DARK_BG)
        self.geometry("820x560")
        self.transient(master)
        self.grab_set()

        self.step = step
        self.on_save = on_save

        self.columnconfigure(0, weight=1)
        self.rowconfigure(3, weight=1)
        self.rowconfigure(5, weight=2)

        top = ttk.Frame(self, style="Panel.TFrame")
        top.grid(row=0, column=0, sticky="ew", padx=10, pady=10)
        top.columnconfigure(1, weight=1)

        self.enabled_var = tk.BooleanVar(value=step.get("enabled", True))
        ttk.Checkbutton(top, text="Enabled", variable=self.enabled_var).grid(row=0, column=0, sticky="w", padx=5)

        ttk.Label(top, text="Name:").grid(row=1, column=0, sticky="w", padx=5, pady=(8, 0))
        self.name_var = tk.StringVar(value=step.get("name", ""))
        ttk.Entry(top, textvariable=self.name_var).grid(row=1, column=1, sticky="ew", padx=5, pady=(8, 0))

        ttk.Label(top, text="Chain Mode:").grid(row=2, column=0, sticky="w", padx=5, pady=(8, 0))
        self.chain_var = tk.StringVar(value=step.get("chain_mode", "replace"))
        ttk.Combobox(top, textvariable=self.chain_var, values=("none", "last", "replace"), state="readonly").grid(
            row=2, column=1, sticky="w", padx=5, pady=(8, 0)
        )

        ttk.Label(self, text="System Prompt:", style="Header.TLabel").grid(row=1, column=0, sticky="w", padx=12)
        self.sys_txt = tk.Text(self, height=6, bg=ENTRY_BG, fg=FG, insertbackground=FG, wrap="word")
        self.sys_txt.grid(row=2, column=0, sticky="ew", padx=12)
        self.sys_txt.insert("1.0", step.get("system_prompt", ""))

        ttk.Label(self, text="User Prompt Template:", style="Header.TLabel").grid(row=3, column=0, sticky="nw", padx=12)
        self.tpl_txt = tk.Text(self, bg=ENTRY_BG, fg=FG, insertbackground=FG, wrap="word")
        self.tpl_txt.grid(row=4, column=0, sticky="nsew", padx=12)
        self.tpl_txt.insert("1.0", step.get("user_prompt_template", ""))

        ttk.Label(self, text="Thought Bubble Template (helper):", style="Header.TLabel").grid(row=5, column=0, sticky="nw", padx=12, pady=(10, 0))
        self.thought_txt = tk.Text(self, bg=ENTRY_BG, fg=FG, insertbackground=FG, wrap="word", height=8)
        self.thought_txt.grid(row=6, column=0, sticky="nsew", padx=12, pady=(0, 10))
        self.thought_txt.insert("1.0", step.get("thought_prompt_template", "STEP: {{step_name}}\n\nOUTPUT:\n{{step_output}}\n\nReturn 1-3 bullets."))

        bottom = ttk.Frame(self, style="Panel.TFrame")
        bottom.grid(row=7, column=0, sticky="ew", padx=10, pady=(0, 10))
        bottom.columnconfigure(0, weight=1)

        ttk.Button(bottom, text="Save", command=self.save).grid(row=0, column=1, padx=5)
        ttk.Button(bottom, text="Cancel", command=self.destroy).grid(row=0, column=2, padx=5)

    def save(self):
        self.step["enabled"] = bool(self.enabled_var.get())
        self.step["name"] = self.name_var.get().strip() or self.step.get("id", "")
        self.step["chain_mode"] = self.chain_var.get().strip().lower()
        self.step["system_prompt"] = self.sys_txt.get("1.0", "end-1c")
        self.step["user_prompt_template"] = self.tpl_txt.get("1.0", "end-1c")
        self.step["thought_prompt_template"] = self.thought_txt.get("1.0", "end-1c")
        self.on_save()
        self.destroy()


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Tasklist Chat Prototype")
        self.configure(bg=DARK_BG)
        self.geometry("1300x780")

        self._build_style()

        self.state_obj = new_state()
        self.tasklist = default_tasklist()

        # models are just strings here; you can wire in /api/tags later
        self.chat_model = tk.StringVar(value="qwen2.5:7b")     # set to whatever you have locally
        self.helper_model = tk.StringVar(value="qwen2.5:1.5b") # small summarizer

        self._build_layout()

    def _build_style(self):
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass

        style.configure("TFrame", background=DARK_BG)
        style.configure("Panel.TFrame", background=PANEL_BG)
        style.configure("TLabel", background=PANEL_BG, foreground=FG)
        style.configure("Header.TLabel", background=PANEL_BG, foreground=FG, font=("Segoe UI", 11, "bold"))
        style.configure("TButton", font=("Segoe UI", 10))

    def _build_layout(self):
        self.columnconfigure(0, weight=4)
        self.columnconfigure(1, weight=1)
        self.rowconfigure(0, weight=1)

        left = ttk.Frame(self, style="Panel.TFrame")
        left.grid(row=0, column=0, sticky="nsew", padx=10, pady=10)
        left.columnconfigure(0, weight=1)
        left.rowconfigure(1, weight=1)

        header = ttk.Frame(left, style="Panel.TFrame")
        header.grid(row=0, column=0, sticky="ew")
        header.columnconfigure(6, weight=1)

        ttk.Label(header, text="Chat Model:").grid(row=0, column=0, padx=(5, 2))
        ttk.Entry(header, textvariable=self.chat_model, width=22).grid(row=0, column=1, padx=2)

        ttk.Label(header, text="Helper Model:").grid(row=0, column=2, padx=(10, 2))
        ttk.Entry(header, textvariable=self.helper_model, width=22).grid(row=0, column=3, padx=2)

        ttk.Button(header, text="Edit Tasklist", command=self.open_tasklist_editor).grid(row=0, column=4, padx=(10, 2))
        ttk.Button(header, text="Clear", command=self.clear_all).grid(row=0, column=5, padx=2)

        self.chat_txt = tk.Text(left, bg=ENTRY_BG, fg=FG, insertbackground=FG, wrap="word")
        self.chat_txt.grid(row=1, column=0, sticky="nsew", padx=5, pady=5)

        entry_bar = ttk.Frame(left, style="Panel.TFrame")
        entry_bar.grid(row=2, column=0, sticky="ew", padx=5, pady=(0, 5))
        entry_bar.columnconfigure(0, weight=1)

        self.user_entry = ttk.Entry(entry_bar)
        self.user_entry.grid(row=0, column=0, sticky="ew", padx=(0, 6))
        self.user_entry.bind("<Return>", lambda e: self.send())

        ttk.Button(entry_bar, text="Send / Run Tasklist", command=self.send).grid(row=0, column=1)

        # Right thoughts panel
        right = ttk.Frame(self, style="Panel.TFrame")
        right.grid(row=0, column=1, sticky="nsew", padx=(0, 10), pady=10)
        right.columnconfigure(0, weight=1)
        right.rowconfigure(1, weight=1)

        ttk.Label(right, text="Thoughts", style="Header.TLabel").grid(row=0, column=0, sticky="w", padx=8, pady=(8, 0))
        self.thoughts_txt = tk.Text(right, bg=ENTRY_BG, fg=FG, insertbackground=FG, wrap="word")
        self.thoughts_txt.grid(row=1, column=0, sticky="nsew", padx=8, pady=8)

    def open_tasklist_editor(self):
        TasklistEditor(self, self.tasklist)

    def clear_all(self):
        self.state_obj = new_state()
        self.chat_txt.delete("1.0", "end")
        self.thoughts_txt.delete("1.0", "end")

    def _append_chat(self, role: str, content: str):
        self.chat_txt.insert("end", f"{role.upper()}:\n{content}\n\n")
        self.chat_txt.see("end")

    def _render_thoughts(self):
        self.thoughts_txt.delete("1.0", "end")
        for t in self.state_obj["working"].get("thoughts", []):
            self.thoughts_txt.insert("end", f"{t.get('step_id')} — {t.get('name')}\n{t.get('summary')}\n\n")
        self.thoughts_txt.see("end")

    def send(self):
        user_text = self.user_entry.get().strip()
        if not user_text:
            return

        self.user_entry.delete(0, "end")

        # store user message
        self.state_obj["chat"]["last_user"] = user_text
        self.state_obj["chat"]["history"].append({"role": "user", "content": user_text})
        self._append_chat("user", user_text)

        try:
            self.state_obj = run_tasklist(
                state=self.state_obj,
                tasklist=self.tasklist,
                chat_model_default=self.chat_model.get().strip(),
                helper_model_default=self.helper_model.get().strip(),
            )
        except Exception as e:
            messagebox.showerror("Run failed", str(e))
            return

        final = self.state_obj["outputs"].get("final") or self.state_obj["chat"].get("last_response") or ""
        self.state_obj["chat"]["history"].append({"role": "assistant", "content": final})
        self._append_chat("assistant", final)

        self._render_thoughts()


# -----------------------------
# CLI / Entrypoint
# -----------------------------

def main():
    parser = argparse.ArgumentParser(description="Tasklist Chat Prototype (GUI by default).")
    parser.add_argument("--nogui", action="store_true", help="Do not launch GUI (placeholder for future CLI mode).")
    args = parser.parse_args()

    if args.nogui:
        print("CLI mode not implemented yet. Run without --nogui to launch the GUI.")
        return 0

    app = App()
    app.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
