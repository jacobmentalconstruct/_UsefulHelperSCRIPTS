# Microservice Dependency Report

- Root: `C:\Users\petya\Documents\Jacob's BIN\_UsefulHelperSCRIPTS\_MicroserviceLIBRARY`
- Files scanned: **58**
- Parsed OK: **58**
- Rewritten files: **58**

## Per-file summary

| File | Parsed | Changed | Internal deps | External deps | Notes/Errors |
|---|---:|---:|---|---|---|
| `_ArchiveBotMS.py` | ✅ | ✅ | base_service, microservice_std_lib |  |  |
| `_AuthMS.py` | ✅ | ✅ | microservice_std_lib |  |  |
| `_CartridgeServiceMS.py` | ✅ | ✅ | base_service, microservice_std_lib | sqlite_vec |  |
| `_ChalkBoardMS.py` | ✅ | ✅ | base_service, microservice_std_lib | webview |  |
| `_ChunkingRouterMS.py` | ✅ | ✅ | _PythonChunkerMS, base_service, microservice_std_lib |  |  |
| `_CodeChunkerMS.py` | ✅ | ✅ | base_service, microservice_std_lib |  |  |
| `_CodeFormatterMS.py` | ✅ | ✅ | microservice_std_lib |  |  |
| `_CodeGrapherMS.py` | ✅ | ✅ | base_service, microservice_std_lib |  |  |
| `_CodeJanitorMS.py` | ✅ | ✅ | microservice_std_lib |  |  |
| `_CognitiveMemoryMS.py` | ✅ | ✅ | base_service, microservice_std_lib | pydantic |  |
| `_ContentExtractorMS.py` | ✅ | ✅ | microservice_std_lib | beautifulsoup4, bs4, pypdf |  |
| `_ContextAggregatorMS.py` | ✅ | ✅ | microservice_std_lib |  |  |
| `_ContextPackerMS.py` | ✅ | ✅ | microservice_std_lib |  |  |
| `_DiffEngineMS.py` | ✅ | ✅ | microservice_std_lib |  |  |
| `_EnvironmentManagerMS.py` | ✅ | ✅ | microservice_std_lib |  |  |
| `_ExplorerWidgetMS.py` | ✅ | ✅ | base_service, microservice_std_lib | ttk |  |
| `_FingerprintScannerMS.py` | ✅ | ✅ | microservice_std_lib |  |  |
| `_GitPilotMS.py` | ✅ | ✅ | microservice_std_lib | git |  |
| `_HeuristicSumMS.py` | ✅ | ✅ | base_service, microservice_std_lib |  |  |
| `_IngestEngineMS.py` | ✅ | ✅ | base_service, microservice_std_lib | requests |  |
| `_IntakeServiceMS.py` | ✅ | ✅ | _CartridgeServiceMS, _ScannerMS, base_service, document_utils, microservice_std_lib | bs4, requests |  |
| `_IsoProcessMS.py` | ✅ | ✅ | microservice_std_lib |  |  |
| `_LexicalSearchMS.py` | ✅ | ✅ | microservice_std_lib |  |  |
| `_LibrarianMS.py` | ✅ | ✅ | microservice_std_lib | requests |  |
| `_LibrarianServiceMS.py` | ✅ | ✅ | microservice_std_lib | requests |  |
| `_LogViewMS.py` | ✅ | ✅ | microservice_std_lib |  |  |
| `_MonacoHostMS.py` | ✅ | ✅ | microservice_std_lib | webview |  |
| `_NetworkLayoutMS.py` | ✅ | ✅ | microservice_std_lib | networkx |  |
| `_NeuralGraphEngineMS.py` | ✅ | ✅ | base_service, microservice_std_lib | pygame |  |
| `_NeuralGraphViewerMS.py` | ✅ | ✅ | _NeuralGraphEngineMS, base_service, microservice_std_lib | PIL |  |
| `_NeuralServiceMS.py` | ✅ | ✅ | microservice_std_lib | requests |  |
| `_ProjectForgeMS.py` | ✅ | ✅ | microservice_std_lib |  |  |
| `_PromptOptimizerMS.py` | ✅ | ✅ | microservice_std_lib |  |  |
| `_PromptVaultMS.py` | ✅ | ✅ | microservice_std_lib | jinja2, pydantic |  |
| `_PythonChunkerMS.py` | ✅ | ✅ | microservice_std_lib |  |  |
| `_RefineryServiceMS.py` | ✅ | ✅ | _CartridgeServiceMS, _ChunkingRouterMS, _NeuralServiceMS, microservice_std_lib |  |  |
| `_RegexWeaverMS.py` | ✅ | ✅ | microservice_std_lib |  |  |
| `_RoleManagerMS.py` | ✅ | ✅ | microservice_std_lib | pydantic |  |
| `_SandboxManagerMS.py` | ✅ | ✅ | microservice_std_lib |  |  |
| `_ScannerMS.py` | ✅ | ✅ | base_service, microservice_std_lib |  |  |
| `_ScoutMS.py` | ✅ | ✅ | microservice_std_lib | bs4, requests |  |
| `_SearchEngineMS.py` | ✅ | ✅ | microservice_std_lib | requests, sqlite_vec |  |
| `_SemanticChunkerMS.py` | ✅ | ✅ | microservice_std_lib |  |  |
| `_ServiceRegistryMS.py` | ✅ | ✅ | microservice_std_lib |  |  |
| `_SpinnerThingyMaBobberMS.py` | ✅ | ✅ | microservice_std_lib |  |  |
| `_SysInspectorMS.py` | ✅ | ✅ | microservice_std_lib |  |  |
| `_TasklistVaultMS.py` | ✅ | ✅ | microservice_std_lib |  |  |
| `_TelemetryServiceMS.py` | ✅ | ✅ | microservice_std_lib |  |  |
| `_TextChunkerMS.py` | ✅ | ✅ | microservice_std_lib |  |  |
| `_ThoughtStreamMS.py` | ✅ | ✅ | microservice_std_lib |  |  |
| `_TkinterAppShellMS.py` | ✅ | ✅ | _TkinterThemeManagerMS, microservice_std_lib |  |  |
| `_TkinterSmartExplorerMS.py` | ✅ | ✅ | microservice_std_lib |  |  |
| `_TkinterThemeManagerMS.py` | ✅ | ✅ | microservice_std_lib |  |  |
| `_TkinterUniButtonMS.py` | ✅ | ✅ | microservice_std_lib |  |  |
| `_TreeMapperMS.py` | ✅ | ✅ | microservice_std_lib |  |  |
| `_VectorFactoryMS.py` | ✅ | ✅ | microservice_std_lib | chromadb, faiss, numpy |  |
| `_WebScraperMS.py` | ✅ | ✅ | microservice_std_lib | httpx, readability |  |
| `_WorkbenchLayoutMS.py` | ✅ | ✅ | microservice_std_lib |  |  |

## Aggregate external dependencies (requirements candidates)

- PIL
- beautifulsoup4
- bs4
- chromadb
- faiss
- git
- httpx
- jinja2
- networkx
- numpy
- pydantic
- pygame
- pypdf
- readability
- requests
- sqlite_vec
- ttk
- webview
