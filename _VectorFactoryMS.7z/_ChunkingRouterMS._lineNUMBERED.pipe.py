  1│ """
  2│ SERVICE_NAME: _ChunkingRouterMS
  3│ ENTRY_POINT: _ChunkingRouterMS.py
  4│ DEPENDENCIES: None
  5│ """
  6│ 
  7│ import re
  8│ from typing import Any, Dict, List, Optional
  9│ # [FIX] Import BaseService correctly
 10│ from microservice_std_lib import service_metadata, service_endpoint
 11│ from base_service import BaseService
 12│ 
 13│ # Attempt to import the specialist. If missing, we will fallback or warn.
 14│ try:
 15│     from _PythonChunkerMS import PythonChunkerMS, CodeChunk
 16│ except ImportError:
 17│     # Fallback mock for standalone testing if dependency is missing
 18│     class CodeChunk:
 19│         def __init__(self, name, type, content, start_line, end_line):
 20│             self.name = name; self.type = type; self.content = content
 21│             self.start_line = start_line; self.end_line = end_line
 22│         def __repr__(self): return f"<CodeChunk {self.name}>"
 23│     
 24│     class PythonChunkerMS:
 25│         def chunk(self, text): return [CodeChunk("mock", "text", text, 0, 0)]
 26│ 
 27│ # ==============================================================================
 28│ # SERVICE DEFINITION
 29│ # ==============================================================================
 30│ @service_metadata(
 31│     name="ChunkingRouterMS",
 32│     version="1.1.0",
 33│     description="The Dispatcher: Routes files to specialized chunkers based on extension (AST for Python, Recursive for Prose).",
 34│     tags=["orchestration", "chunking", "nlp"],
 35│     capabilities=["routing", "text-processing"],
 36│     dependencies=["re"],
 37│     side_effects=[]
 38│ )
 39│ class ChunkingRouterMS(BaseService):
 40│     """
 41│     The Editor: A 'Recursive' text splitter.
 42│     It respects the natural structure of text (Paragraphs -> Sentences -> Words)
 43│     rather than just hacking it apart by character count.
 44│     """
 45│     
 46│     def __init__(self, config: Optional[Dict[str, Any]] = None):
 47│         super().__init__("ChunkingRouterMS")
 48│         self.config = config or {}
 49│         self.python_specialist = PythonChunkerMS()
 50│         # Separators for the Prose Specialist logic
 51│         self.separators = ["\n\n", "\n", "(?<=[.?!])\s+", " ", ""]
 52│ 
 53│     @service_endpoint(
 54│         inputs={"text": "str", "filename": "str", "max_size": "int", "overlap": "int"},
 55│         outputs={"chunks": "list"},
 56│         description="Routes text to the appropriate specialist. Returns a list of CodeChunk objects or raw strings.",
 57│         tags=["routing", "chunking"]
 58│     )
 59│     def chunk_file(self, text: str, filename: str, max_size: int = 1000, overlap: int = 100) -> List[Any]:
 60│         """
 61│         Extension-aware router.
 62│         """
 63│         if filename.endswith(".py"):
 64│             return self.python_specialist.chunk(text)
 65│         
 66│         # Fallback to the internal Prose Specialist (Recursive Splitter)
 67│         raw_chunks = self._recursive_split(text, self.separators, max_size, overlap)
 68│         
 69│         # Standardize output for the Refinery: Wrap prose in CodeChunk objects
 70│         return [
 71│             CodeChunk(
 72│                 name=f"prose_chunk_{i}", 
 73│                 type="text", 
 74│                 content=c, 
 75│                 start_line=0, 
 76│                 end_line=0
 77│             ) for i, c in enumerate(raw_chunks)
 78│         ]
 79│ 
 80│     # ==========================================================================
 81│     # INTERNAL LOGIC (The Prose Specialist)
 82│     # ==========================================================================
 83│     def _recursive_split(self, text: str, separators: List[str], max_size: int, overlap: int) -> List[str]:
 84│         final_chunks = []
 85│         
 86│         # 1. Base Case: If the text fits, return it
 87│         if len(text) <= max_size:
 88│             return [text]
 89│         
 90│         # 2. Edge Case: No more separators, forced hard split
 91│         if not separators:
 92│             return self._hard_split(text, max_size, overlap)
 93│ 
 94│         # 3. Recursive Step: Try to split by the current separator
 95│         current_sep = separators[0]
 96│         next_separators = separators[1:]
 97│         
 98│         # Regex split to keep delimiters if possible (logic varies by regex complexity)
 99│         # For simple string splits like \n\n, we just split.
100│         if len(current_sep) > 1 and "(" in current_sep: 
101│             # It's a regex lookbehind (sentence splitter), use re.split
102│             splits = re.split(current_sep, text)
103│         else:
104│             splits = text.split(current_sep)
105│ 
106│         # Now we have a list of smaller pieces. We need to merge them back together
107│         # until they fill the 'max_size' bucket, then start a new bucket.
108│         current_doc = []
109│         current_length = 0
110│         
111│         for split in splits:
112│             if not split: continue
113│             
114│             # If a single split is STILL too big, recurse deeper on it
115│             if len(split) > max_size:
116│                 # If we have stuff in the buffer, flush it first
117│                 if current_doc:
118│                     final_chunks.append(current_sep.join(current_doc))
119│                     current_doc = []
120│                     current_length = 0
121│                 
122│                 # Recurse on the big chunk using the NEXT separator
123│                 sub_chunks = self._recursive_split(split, next_separators, max_size, overlap)
124│                 final_chunks.extend(sub_chunks)
125│                 continue
126│ 
127│             # Check if adding this split would overflow
128│             if current_length + len(split) + len(current_sep) > max_size:
129│                 # Flush the current buffer
130│                 doc_text = current_sep.join(current_doc)
131│                 final_chunks.append(doc_text)
132│                 
133│                 # For simplicity in recursion, we start fresh with the current split.
134│                 current_doc = [split]
135│                 current_length = len(split)
136│             else:
137│                 # Add to buffer
138│                 current_doc.append(split)
139│                 current_length += len(split) + len(current_sep)
140│ 
141│         # Flush remaining
142│         if current_doc:
143│             final_chunks.append(current_sep.join(current_doc))
144│ 
145│         return final_chunks
146│ 
147│     def _hard_split(self, text: str, chunk_size: int, overlap: int) -> List[str]:
148│         """Last resort: naive character sliding window."""
149│         chunks = []
150│         start = 0
151│         while start < len(text):
152│             end = start + chunk_size
153│             chunks.append(text[start:end])
154│             start += chunk_size - overlap
155│         return chunks
156│ 
157│ # ==============================================================================
158│ # SELF-TEST / RUNNER
159│ # ==============================================================================
160│ if __name__ == "__main__":
161│     chunker = ChunkingRouterMS()
162│     print(f"Service ready: {chunker}")
163│     
164│     # Example: A technical document with structure
165│     doc = """
166│     # Intro to AI
167│     Artificial Intelligence is great.
168│     It helps us code.
169│     
170│     ## How it works
171│     1. Ingestion: Reading data.
172│     2. Processing: Thinking about data.
173│     This is a very long paragraph that effectively serves as a stress test for the sentence splitter.
174│     It should hopefully not break in the middle of a thought! We want to keep sentences whole.
175│     """
176│     
177│     print("--- Testing Smart Chunking (Max 60 chars) ---")
178│     # We set max_size very small to force it to use the sentence/word splitters
179│     chunks = chunker.chunk_file(doc, "test.md", max_size=60, overlap=0)
180│     
181│     for i, c in enumerate(chunks):
182│         print(f"[{i}] {repr(c)}")