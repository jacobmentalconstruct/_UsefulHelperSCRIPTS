  1│ #!/usr/bin/env python3
  2│ """
  3│ sync-ms-deps.py
  4│ 
  5│ Crawls a microservice directory and keeps two kinds of dependency metadata in each service:
  6│ 
  7│   1) internal_dependencies
  8│      - Local Python modules that must be vendored alongside the service.
  9│ 
 10│   2) external_dependencies
 11│      - Third-party packages that belong in requirements.txt (pip-installable).
 12│ 
 13│ The script is AST-only: it does NOT import/execute any microservices.
 14│ 
 15│ It can:
 16│ - Produce a report (Markdown + optional JSON)
 17│ - Optionally rewrite @service_metadata(...) decorators to include/update:
 18│     internal_dependencies=[...]
 19│     external_dependencies=[...]
 20│ - Optionally write a requirements.txt derived from external_dependencies
 21│ 
 22│ Typical usage:
 23│   python sync-ms-deps.py . --report-only
 24│   python sync-ms-deps.py . --fix
 25│   python sync-ms-deps.py . --fix --write-requirements requirements.txt
 26│ """
 27│ 
 28│ from __future__ import annotations
 29│ 
 30│ import ast
 31│ import argparse
 32│ import json
 33│ import io
 34│ import re
 35│ import tokenize
 36│ from dataclasses import dataclass, asdict
 37│ from pathlib import Path
 38│ from typing import Dict, List, Optional, Set, Tuple, Any
 39│ 
 40│ MICROSERVICE_GLOB_DEFAULT = "*MS.py"
 41│ PY_GLOB = "*.py"
 42│ 
 43│ FALLBACK_STDLIB: Set[str] = {
 44│     "abc", "argparse", "array", "asyncio", "base64", "binascii", "bisect",
 45│     "calendar", "collections", "contextlib", "copy", "csv", "ctypes",
 46│     "dataclasses", "datetime", "decimal", "difflib", "email", "enum", "fnmatch",
 47│     "functools", "gc", "getpass", "glob", "gzip", "hashlib", "heapq", "hmac",
 48│     "html", "http", "importlib", "inspect", "io", "ipaddress", "itertools",
 49│     "json", "logging", "math", "mimetypes", "multiprocessing", "numbers",
 50│     "operator", "os", "pathlib", "pickle", "platform", "plistlib", "pprint",
 51│     "queue", "random", "re", "shlex", "shutil", "signal", "socket", "sqlite3",
 52│     "ssl", "statistics", "string", "struct", "subprocess", "sys", "tempfile",
 53│     "textwrap", "threading", "time", "tkinter", "traceback", "types",
 54│     "typing", "unittest", "urllib", "uuid", "warnings", "weakref", "xml", "zipfile",
 55│ }
 56│ 
 57│ INHERITANCE_TO_INTERNAL_MODULE: Dict[str, str] = {
 58│     "BaseService": "base_service",
 59│ }
 60│ 
 61│ META_KEY_INTERNAL = "internal_dependencies"
 62│ META_KEY_EXTERNAL = "external_dependencies"
 63│ 
 64│ 
 65│ @dataclass
 66│ class FileDeps:
 67│     internal: List[str]
 68│     external: List[str]
 69│     declared_internal: List[str]
 70│     errors: List[str]
 71│ 
 72│ 
 73│ @dataclass
 74│ class FileReport:
 75│     file: str
 76│     ok: bool
 77│     changed: bool
 78│     deps: FileDeps
 79│     notes: List[str]
 80│ 
 81│ 
 82│ def get_stdlib_names() -> Set[str]:
 83│     try:
 84│         import sys
 85│         names = set(getattr(sys, "stdlib_module_names", []))
 86│         return names | FALLBACK_STDLIB
 87│     except Exception:
 88│         return set(FALLBACK_STDLIB)
 89│ 
 90│ 
 91│ def module_root(mod: str) -> str:
 92│     return mod.split(".")[0].strip()
 93│ 
 94│ 
 95│ def normalize_dep_token(token: str) -> str:
 96│     t = token.strip().strip('"').strip("'")
 97│     if not t:
 98│         return ""
 99│     t = t.replace("\\", "/")
100│     if t.endswith(".py"):
101│         t = t[:-3]
102│         t = t.split("/")[-1]
103│     return t.strip()
104│ 
105│ 
106│ def ast_list_of_str(values: List[str]) -> ast.AST:
107│     return ast.List(elts=[ast.Constant(v) for v in values], ctx=ast.Load())
108│ 
109│ 
110│ def read_text(path: Path) -> str:
111│     return path.read_text(encoding="utf-8", errors="replace")
112│ 
113│ 
114│ def write_text(path: Path, text: str) -> None:
115│     path.write_text(text, encoding="utf-8", newline="\n")
116│ 
117│ 
118│ # NOTE:
119│ # Python emits SyntaxWarning for invalid escapes like "\s" inside normal string literals.
120│ # This is common when someone writes regexes as "\s+" instead of r"\s+".
121│ # We can repair those *in microservice files* before ast.parse(), so scanning stays clean.
122│ _REGEX_ESCAPE_SEQS = ("\\s", "\\S", "\\d", "\\D", "\\w", "\\W")
123│ 
124│ 
125│ def _string_token_is_raw(tok_string: str) -> bool:
126│     """Return True if a STRING token has a raw-string prefix (r/R anywhere in prefix)."""
127│     # Token looks like: r"...", fr"...", b"...", etc.
128│     # Prefix is everything before the first quote char.
129│     i = 0
130│     while i < len(tok_string) and tok_string[i] not in ("'", '"'):
131│         i += 1
132│     prefix = tok_string[:i]
133│     return ("r" in prefix.lower())
134│ 
135│ 
136│ def fix_invalid_escapes_in_source(src: str, sequences: Tuple[str, ...] = _REGEX_ESCAPE_SEQS) -> Tuple[str, int]:
137│     """Return (new_src, num_fixes) by escaping common regex sequences in non-raw string literals.
138│ 
139│     We only touch STRING tokens (via tokenize) to avoid modifying code/comments.
140│     Example: "\\s+" (invalid escape) -> "\\\\s+" (valid Python string that yields regex \s+).
141│     """
142│     fixes = 0
143│     out_tokens: List[tokenize.TokenInfo] = []
144│ 
145│     try:
146│         gen = tokenize.generate_tokens(io.StringIO(src).readline)
147│     except Exception:
148│         return src, 0
149│ 
150│     for tok in gen:
151│         if tok.type != tokenize.STRING:
152│             out_tokens.append(tok)
153│             continue
154│ 
155│         s = tok.string
156│         if _string_token_is_raw(s):
157│             out_tokens.append(tok)
158│             continue
159│ 
160│         new_s = s
161│         for seq in sequences:
162│             # Replace only when the backslash isn't already escaped.
163│             # Pattern matches: \s but not \\s
164│             pat = r"(?<!\\)" + re.escape(seq)
165│             repl = r"\\" + seq[1:]  # '\\' + 's' => '\\s'
166│             new_s, n = re.subn(pat, repl, new_s)
167│             fixes += n
168│ 
169│         if new_s != s:
170│             out_tokens.append(tok._replace(string=new_s))
171│         else:
172│             out_tokens.append(tok)
173│ 
174│     try:
175│         new_src = tokenize.untokenize(out_tokens)
176│     except Exception:
177│         return src, 0
178│ 
179│     return new_src, fixes
180│ 
181│ 
182│ def repair_invalid_escapes_in_file(path: Path) -> Tuple[bool, int]:
183│     """Repair invalid escape sequences in a file. Returns (changed, fixes)."""
184│     src = read_text(path)
185│     new_src, fixes = fix_invalid_escapes_in_source(src)
186│     if fixes > 0 and new_src != src:
187│         write_text(path, new_src)
188│         return True, fixes
189│     return False, 0
190│ 
191│ 
192│ def extract_string_collection(expr: ast.AST) -> Set[str]:
193│     out: Set[str] = set()
194│ 
195│     def add_str(node: ast.AST) -> None:
196│         if isinstance(node, ast.Constant) and isinstance(node.value, str):
197│             s = node.value.strip()
198│             if s:
199│                 out.add(s)
200│ 
201│     if isinstance(expr, (ast.List, ast.Tuple, ast.Set)):
202│         for elt in expr.elts:
203│             add_str(elt)
204│         return out
205│ 
206│     if isinstance(expr, ast.Call) and isinstance(expr.func, ast.Name) and expr.func.id in {"set", "list", "tuple"}:
207│         if expr.args:
208│             return extract_string_collection(expr.args[0])
209│         return out
210│ 
211│     if isinstance(expr, ast.Dict):
212│         for k in expr.keys:
213│             if k is not None:
214│                 add_str(k)
215│         return out
216│ 
217│     return out
218│ 
219│ 
220│ class DepVisitor(ast.NodeVisitor):
221│     def __init__(self) -> None:
222│         self.imports: Set[str] = set()
223│         self.from_imports: Set[str] = set()
224│         self.base_names: Set[str] = set()
225│         self.declared_dependencies: Set[str] = set()
226│ 
227│     def visit_Import(self, node: ast.Import) -> None:
228│         for alias in node.names:
229│             if alias.name:
230│                 self.imports.add(alias.name)
231│         self.generic_visit(node)
232│ 
233│     def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
234│         if node.module is not None:
235│             self.from_imports.add(node.module)
236│         else:
237│             self.from_imports.add(".")
238│         self.generic_visit(node)
239│ 
240│     def visit_ClassDef(self, node: ast.ClassDef) -> None:
241│         for base in node.bases:
242│             name = None
243│             if isinstance(base, ast.Name):
244│                 name = base.id
245│             elif isinstance(base, ast.Attribute):
246│                 name = base.attr
247│             if name:
248│                 self.base_names.add(name)
249│         self.generic_visit(node)
250│ 
251│     def visit_Assign(self, node: ast.Assign) -> None:
252│         for t in node.targets:
253│             if isinstance(t, ast.Name) and t.id == "DEPENDENCIES":
254│                 extracted = extract_string_collection(node.value)
255│                 if extracted:
256│                     self.declared_dependencies |= extracted
257│         self.generic_visit(node)
258│ 
259│ 
260│ def parse_service_metadata_dependencies(tree: ast.AST) -> Tuple[Set[str], Set[str]]:
261│     """Extract dependency hints from @service_metadata(...) decorators.
262│ 
263│     We store state on the visitor instance (self.internal/self.external) instead of
264│     mutating outer-scope variables from inside visit_* methods.
265│ 
266│     Reason: augmented assignment like `external |= ...` inside a method creates a
267│     local binding and can trigger UnboundLocalError.
268│     """
269│ 
270│     class _MetaVisitor(ast.NodeVisitor):
271│         def __init__(self) -> None:
272│             self.internal: Set[str] = set()
273│             self.external: Set[str] = set()
274│ 
275│         def visit_ClassDef(self, node: ast.ClassDef) -> None:
276│             for dec in node.decorator_list:
277│                 if not isinstance(dec, ast.Call):
278│                     continue
279│ 
280│                 func = dec.func
281│                 if not (isinstance(func, ast.Name) and func.id == "service_metadata"):
282│                     continue
283│ 
284│                 for kw in dec.keywords:
285│                     if not kw.arg:
286│                         continue
287│ 
288│                     if kw.arg in {"dependencies", META_KEY_EXTERNAL}:
289│                         self.external |= extract_string_collection(kw.value)
290│                     elif kw.arg == META_KEY_INTERNAL:
291│                         self.internal |= extract_string_collection(kw.value)
292│ 
293│             self.generic_visit(node)
294│ 
295│     v = _MetaVisitor()
296│     v.visit(tree)
297│     return v.internal, v.external
298│ 
299│ 
300│ class ServiceMetadataRewriter(ast.NodeTransformer):
301│     def __init__(self, internal: List[str], external: List[str], remove_legacy_dependencies_arg: bool = True) -> None:
302│         self.internal = internal
303│         self.external = external
304│         self.remove_legacy = remove_legacy_dependencies_arg
305│         self.touched = False
306│ 
307│     def visit_ClassDef(self, node: ast.ClassDef) -> ast.AST:
308│         if not node.decorator_list:
309│             return node
310│ 
311│         new_decorators: List[ast.AST] = []
312│         for dec in node.decorator_list:
313│             new_decorators.append(self._rewrite_decorator(dec))
314│         node.decorator_list = new_decorators
315│         return node
316│ 
317│     def _rewrite_decorator(self, dec: ast.AST) -> ast.AST:
318│         if not isinstance(dec, ast.Call):
319│             return dec
320│         func = dec.func
321│         if not (isinstance(func, ast.Name) and func.id == "service_metadata"):
322│             return dec
323│ 
324│         kw_map: Dict[str, ast.keyword] = {kw.arg: kw for kw in dec.keywords if kw.arg}
325│ 
326│         kw_map[META_KEY_INTERNAL] = ast.keyword(arg=META_KEY_INTERNAL, value=ast_list_of_str(self.internal))
327│         kw_map[META_KEY_EXTERNAL] = ast.keyword(arg=META_KEY_EXTERNAL, value=ast_list_of_str(self.external))
328│ 
329│         if self.remove_legacy and "dependencies" in kw_map:
330│             del kw_map["dependencies"]
331│ 
332│         original_order = [kw.arg for kw in dec.keywords if kw.arg]
333│         wanted: List[str] = []
334│         seen: Set[str] = set()
335│         for k in original_order:
336│             if k in kw_map and k not in seen:
337│                 wanted.append(k); seen.add(k)
338│         for k in (META_KEY_INTERNAL, META_KEY_EXTERNAL):
339│             if k in kw_map and k not in seen:
340│                 wanted.append(k); seen.add(k)
341│         for k in kw_map.keys():
342│             if k not in seen:
343│                 wanted.append(k); seen.add(k)
344│ 
345│         dec.keywords = [kw_map[k] for k in wanted if k in kw_map]
346│         self.touched = True
347│         return dec
348│ 
349│ 
350│ def analyze_file(
351│     path: Path,
352│     stdlib: Set[str],
353│     local_modules: Set[str],
354│     repair_invalid_escapes: bool = False,
355│ ) -> Tuple[FileDeps, List[str]]:
356│     errors: List[str] = []
357│     notes: List[str] = []
358│     internal: Set[str] = set()
359│     external: Set[str] = set()
360│     declared_internal: Set[str] = set()
361│ 
362│     # Optional pre-pass: repair invalid regex escapes like "\s" inside normal strings.
363│     if repair_invalid_escapes:
364│         changed, fixes = repair_invalid_escapes_in_file(path)
365│         if changed:
366│             notes.append(f"Repaired {fixes} invalid escape sequence(s) in string literals.")
367│ 
368│     try:
369│         src = read_text(path)
370│         # Pass filename so any warnings/errors point at the real file instead of <unknown>
371│         tree = ast.parse(src, filename=str(path))
372│     except SyntaxError as e:
373│         return FileDeps(internal=[], external=[], declared_internal=[], errors=[f"SyntaxError: {e}"]), ["Could not parse AST"]
374│ 
375│     dv = DepVisitor()
376│     dv.visit(tree)
377│ 
378│     import_roots = {module_root(m) for m in dv.imports if m}
379│     from_roots = {module_root(m) for m in dv.from_imports if m and m != "."}
380│     relative_present = "." in dv.from_imports
381│ 
382│     if relative_present:
383│         notes.append("Contains relative imports (treated as internal when resolvable).")
384│ 
385│     for mod in sorted(import_roots | from_roots):
386│         if not mod:
387│             continue
388│         if mod in stdlib:
389│             continue
390│         if mod in local_modules:
391│             internal.add(mod)
392│         else:
393│             external.add(mod)
394│ 
395│     for base in dv.base_names:
396│         if base in INHERITANCE_TO_INTERNAL_MODULE:
397│             internal.add(INHERITANCE_TO_INTERNAL_MODULE[base])
398│ 
399│     for raw in dv.declared_dependencies:
400│         t = normalize_dep_token(raw)
401│         if not t:
402│             continue
403│         if t in local_modules:
404│             declared_internal.add(t)
405│             internal.add(t)
406│             continue
407│         if t.endswith("MS"):
408│             underscored = f"_{t}"
409│             if underscored in local_modules:
410│                 declared_internal.add(underscored)
411│                 internal.add(underscored)
412│ 
413│     meta_internal, meta_external = parse_service_metadata_dependencies(tree)
414│ 
415│     for raw in meta_internal:
416│         t = normalize_dep_token(raw)
417│         if t in local_modules:
418│             internal.add(t)
419│ 
420│     for raw in meta_external:
421│         t = normalize_dep_token(raw)
422│         if t and (t not in stdlib) and (t not in local_modules):
423│             external.add(t)
424│ 
425│     external = {e for e in external if e and e not in stdlib}
426│ 
427│     deps = FileDeps(
428│         internal=sorted(internal),
429│         external=sorted(external),
430│         declared_internal=sorted(declared_internal),
431│         errors=errors,
432│     )
433│     return deps, notes
434│ 
435│ 
436│ def rewrite_file_decorators(
437│     path: Path,
438│     internal: List[str],
439│     external: List[str],
440│     remove_legacy: bool = True,
441│     repair_invalid_escapes: bool = False,
442│ ) -> Tuple[bool, str]:
443│     # Optional pre-pass repair so parsing/unparsing doesn't spam warnings.
444│     if repair_invalid_escapes:
445│         repair_invalid_escapes_in_file(path)
446│ 
447│     src = read_text(path)
448│     try:
449│         tree = ast.parse(src, filename=str(path))
450│     except SyntaxError:
451│         return False, src
452│ 
453│     rewriter = ServiceMetadataRewriter(internal, external, remove_legacy_dependencies_arg=remove_legacy)
454│     new_tree = rewriter.visit(tree)
455│     ast.fix_missing_locations(new_tree)
456│ 
457│     if not rewriter.touched:
458│         return False, src
459│ 
460│     try:
461│         new_src = ast.unparse(new_tree)
462│     except Exception:
463│         return False, src
464│ 
465│     if not new_src.endswith("\n"):
466│         new_src += "\n"
467│     return (new_src != src), new_src
468│ 
469│ 
470│ def render_report_md(reports: List[FileReport], root_dir: Path) -> str:
471│     lines: List[str] = []
472│     total = len(reports)
473│     ok = sum(1 for r in reports if r.ok)
474│     changed = sum(1 for r in reports if r.changed)
475│ 
476│     lines.append("# Microservice Dependency Report")
477│     lines.append("")
478│     lines.append(f"- Root: `{root_dir}`")
479│     lines.append(f"- Files scanned: **{total}**")
480│     lines.append(f"- Parsed OK: **{ok}**")
481│     lines.append(f"- Rewritten files: **{changed}**")
482│     lines.append("")
483│     lines.append("## Per-file summary")
484│     lines.append("")
485│     lines.append("| File | Parsed | Changed | Internal deps | External deps | Notes/Errors |")
486│     lines.append("|---|---:|---:|---|---|---|")
487│ 
488│     def fmt_list(xs: List[str]) -> str:
489│         return ", ".join(xs) if xs else ""
490│ 
491│     for r in reports:
492│         parsed = "✅" if r.ok else "❌"
493│         ch = "✅" if r.changed else ""
494│         notes = "; ".join((r.notes + r.deps.errors)[:3])
495│         if len(r.notes + r.deps.errors) > 3:
496│             notes += " …"
497│         lines.append(
498│             f"| `{r.file}` | {parsed} | {ch} | {fmt_list(r.deps.internal)} | {fmt_list(r.deps.external)} | {notes} |"
499│         )
500│ 
501│     all_external: Set[str] = set()
502│     for r in reports:
503│         all_external |= set(r.deps.external)
504│ 
505│     lines.append("")
506│     lines.append("## Aggregate external dependencies (requirements candidates)")
507│     lines.append("")
508│     for dep in sorted(all_external):
509│         lines.append(f"- {dep}")
510│     lines.append("")
511│     return "\n".join(lines)
512│ 
513│ 
514│ def main(argv: Optional[List[str]] = None) -> int:
515│     ap = argparse.ArgumentParser(description="Sync microservice dependency metadata (internal vs external).")
516│     ap.add_argument("path", nargs="?", default=".", help="Microservice directory (default: .)")
517│     ap.add_argument("--ms-glob", default=MICROSERVICE_GLOB_DEFAULT, help=f"Glob for microservice files (default: {MICROSERVICE_GLOB_DEFAULT})")
518│     ap.add_argument("--fix", action="store_true", help="Rewrite @service_metadata(...) in files.")
519│     ap.add_argument("--report-only", action="store_true", help="Do not modify files (default behavior).")
520│     ap.add_argument("--write-report", default="ms_deps_report.md", help="Write markdown report to this path (default: ms_deps_report.md)")
521│     ap.add_argument("--write-report-json", default=None, help="Optional JSON report path.")
522│     ap.add_argument("--write-requirements", default=None, help="Write requirements.txt to this path (external deps aggregate).")
523│     ap.add_argument(
524│         "--repair-invalid-escapes",
525│         action="store_true",
526│         help="Repair invalid regex escapes like \\s in non-raw string literals inside scanned microservices.",
527│     )
528│     ap.add_argument("--remove-legacy-dependencies-arg", action="store_true", help="Remove legacy 'dependencies=' arg when rewriting.")
529│     ap.add_argument("--no-remove-legacy-dependencies-arg", dest="remove_legacy_dependencies_arg", action="store_false", help="Keep legacy 'dependencies=' arg when rewriting.")
530│     ap.set_defaults(remove_legacy_dependencies_arg=True)
531│ 
532│     args = ap.parse_args(argv)
533│     root_dir = Path(args.path).resolve()
534│     if not root_dir.exists() or not root_dir.is_dir():
535│         print(f"[ERROR] Not a directory: {root_dir}")
536│         return 1
537│ 
538│     local_modules: Set[str] = set()
539│     for py in root_dir.glob(PY_GLOB):
540│         if py.name.startswith(".") or py.name == "__init__.py":
541│             continue
542│         local_modules.add(py.stem)
543│ 
544│     stdlib = get_stdlib_names()
545│ 
546│     ms_files = sorted(root_dir.glob(args.ms_glob))
547│     if not ms_files:
548│         md = render_report_md([], root_dir)
549│         write_text(Path(args.write_report).resolve(), md)
550│         print(f"[WARN] No files matched '{args.ms_glob}' in {root_dir}. Wrote empty report.")
551│         return 0
552│ 
553│     reports: List[FileReport] = []
554│ 
555│     for fp in ms_files:
556│         deps, notes = analyze_file(
557│             fp,
558│             stdlib=stdlib,
559│             local_modules=local_modules,
560│             repair_invalid_escapes=args.repair_invalid_escapes,
561│         )
562│         ok = not deps.errors
563│         changed = False
564│ 
565│         if ok:
566│             would_change, new_src = rewrite_file_decorators(
567│                 fp,
568│                 internal=deps.internal,
569│                 external=deps.external,
570│                 remove_legacy=args.remove_legacy_dependencies_arg,
571│                 repair_invalid_escapes=args.repair_invalid_escapes,
572│             )
573│ 
574│             if args.fix:
575│                 changed = would_change
576│                 if changed:
577│                     write_text(fp, new_src)
578│             else:
579│                 # dry run: mark files that *would* change
580│                 changed = would_change
581│ 
582│         reports.append(FileReport(
583│             file=fp.name,
584│             ok=ok,
585│             changed=changed,
586│             deps=deps,
587│             notes=notes,
588│         ))
589│ 
590│     md = render_report_md(reports, root_dir)
591│     report_path = Path(args.write_report).resolve()
592│     write_text(report_path, md)
593│ 
594│     if args.write_report_json:
595│         jp = Path(args.write_report_json).resolve()
596│         payload = {"root": str(root_dir), "files": [asdict(r) for r in reports]}
597│         write_text(jp, json.dumps(payload, indent=2, sort_keys=True))
598│ 
599│     if args.write_requirements:
600│         reqs: Set[str] = set()
601│         for r in reports:
602│             reqs |= set(r.deps.external)
603│         req_path = Path(args.write_requirements).resolve()
604│         write_text(req_path, "\n".join(sorted(reqs)) + ("\n" if reqs else ""))
605│ 
606│     print(f"[OK] Scanned {len(ms_files)} microservices in {root_dir}")
607│     print(f"     Report: {report_path}")
608│     if args.write_report_json:
609│         print(f"     JSON:   {Path(args.write_report_json).resolve()}")
610│     if args.write_requirements:
611│         print(f"     Reqs:   {Path(args.write_requirements).resolve()}")
612│     if args.fix:
613│         print(f"     Rewrote: {sum(1 for r in reports if r.changed)} file(s)")
614│     else:
615│         print(f"     (dry run) Would rewrite: {sum(1 for r in reports if r.changed)} file(s)")
616│ 
617│     return 0
618│ 
619│ 
620│ if __name__ == "__main__":
621│     raise SystemExit(main())
622│ 
623│ 
624│ 
