"""
PROJECT: _UsefulHelperSCRIPTS - Project Tidier
ROLE: Entry Point & Signal Bridge (The Ignition)
"""
import sys
import os
import logging
from pathlib import Path

# --- PATH INJECTION ---
# This allows microservices to find 'base_service' and each other
current_dir = Path(__file__).parent.resolve()
sys.path.insert(0, str(current_dir))                # Adds 'src'
sys.path.insert(0, str(current_dir / "microservices")) # Adds 'src/microservices'

# Standard Imports
from _SignalBusMS import SignalBusMS
from backend import ProjectTidierBackend
from ui import ProjectTidierUI
from _SessionRecorderMS import SessionRecorderMS

def main():
    # 1. Start the Signal Bus
    bus = SignalBusMS()

    # 2. Start the Auditor (The Black Box)
    recorder = SessionRecorderMS()

    # 2. Instantiate the Pillars
    backend = ProjectTidierBackend(bus)
    ui = ProjectTidierUI(bus)

    # 3. Establish Explicit Wiring
    bus.subscribe("start_tidy_process", backend._handle_start_request)
    bus.subscribe("hunk_ready_for_review", ui.display_review_hunk)
    bus.subscribe("user_approve_hunk", backend._commit_hunk)

    # Auditor Subscriptions
    bus.subscribe("start_tidy_process", recorder.on_scan_started)
    bus.subscribe("hunk_ready_for_review", recorder.on_hunk_detected)
    bus.subscribe("user_approve_hunk", recorder.on_user_decision)
    bus.subscribe("commit_success", recorder.on_commit_success)

    # 4. Ignition
    print("Project Tidier Initialized. Launching UI...")
    ui.launch()

if __name__ == "__main__":
    main()
