"""
PROJECT: _UsefulHelperSCRIPTS - Project Tidier
ROLE: UI Orchestrator (Pure Tkinter Edition)
"""
import tkinter as tk
from tkinter import ttk
import os

# Internal Microservice Imports
from _TkinterAppShellMS import TkinterAppShellMS
from _ExplorerWidgetMS import ExplorerWidgetMS
from _LogViewMS import LogViewMS
from _OllamaModelSelectorMS import OllamaModelSelectorMS
from _TkinterThemeManagerMS import TkinterThemeManagerMS
from _ThoughtStreamMS import ThoughtStreamMS

class ProjectTidierUI:
    """
    Manages the layout of the Project Tidier interface using standard Tkinter widgets.
    """
    def __init__(self, signal_bus):
        self.bus = signal_bus
        
        # 1. Initialize the AppShell container
        self.theme_mgr = TkinterThemeManagerMS()
        self.shell = TkinterAppShellMS({
            'title': 'Project Tidier | Pure Tkinter',
            'theme_manager': self.theme_mgr,
            'geometry': '1400x900'
        })
        
        self.container = self.shell.get_main_container()
        self.colors = self.theme_mgr.get_theme()
        
        self._setup_layout()
        self._wire_signals()

    def _setup_layout(self):
        # --- Top Toolbar (Model Selection & Launch) ---
        self.top_bar = tk.Frame(self.container, bg=self.colors['panel_bg'], height=50)
        self.top_bar.pack(side='top', fill='x', pady=(0, 5))
        
        self.model_selector = OllamaModelSelectorMS({
            'parent': self.top_bar,
            'bg': self.colors['panel_bg'],
            'on_change': lambda m: self.bus.emit("model_swapped", m)
        })
        self.model_selector.pack(side='left', padx=10)
        
        self.tidy_btn = tk.Button(
            self.top_bar, text="🚀 START TIDY", 
            command=self._on_tidy_click,
            bg=self.colors['accent'], fg='white', relief='flat', padx=20
        )
        self.tidy_btn.pack(side='right', padx=10, pady=5)

        # --- Paned Workspace (Explorer + Review) ---
        self.workspace = ttk.PanedWindow(self.container, orient='horizontal')
        self.workspace.pack(fill='both', expand=True)

        # Left Sidebar (Project Explorer)
        self.explorer_frame = tk.Frame(self.workspace)
        self.explorer = ExplorerWidgetMS({
            'parent': self.explorer_frame,
            'root_path': os.getcwd()
        })
        self.explorer.pack(fill='both', expand=True)
        self.workspace.add(self.explorer_frame, weight=1)

        # Center Stage (Review Pane)
        self.review_stage = tk.Frame(self.workspace, bg=self.colors['background'])
        self._setup_review_pane()
        self.workspace.add(self.review_stage, weight=4)

        # Right Panel (Neural Inspector)
        self.neural_inspector = ThoughtStreamMS({'parent': self.workspace})
        self.workspace.add(self.neural_inspector, weight=2)

        # --- Bottom Panel (Log Telemetry) ---
        self.log_panel = tk.Frame(self.container, height=200)
        self.log_panel.pack(side='bottom', fill='x', pady=(5, 0))
        
        self.console = LogViewMS({'parent': self.log_panel})
        self.console.pack(fill='both', expand=True)

    def _setup_review_pane(self):
        """Standard side-by-side text widgets for reviewing AI changes."""
        self.review_label = tk.Label(self.review_stage, text="Review Hunk: Waiting...", bg=self.colors['background'], fg=self.colors['foreground'])
        self.review_label.pack(pady=5)

        self.diff_container = tk.Frame(self.review_stage, bg=self.colors['background'])
        self.diff_container.pack(fill='both', expand=True, padx=10, pady=5)

        # Pure Tkinter Text Widgets for Original vs. Cleaned
        self.before_txt = tk.Text(self.diff_container, bg='#1e1e1e', fg='#d4d4d4', font=('Consolas', 10))
        self.after_txt = tk.Text(self.diff_container, bg='#1e1e1e', fg='#d4d4d4', font=('Consolas', 10))
        self.before_txt.pack(side='left', fill='both', expand=True, padx=5)
        self.after_txt.pack(side='left', fill='both', expand=True, padx=5)

        # Approval Buttons
        self.btn_frame = tk.Frame(self.review_stage, bg=self.colors['background'])
        self.btn_frame.pack(side='bottom', fill='x', pady=10)
        
        self.approve_btn = tk.Button(self.btn_frame, text="✅ APPROVE", state='disabled', 
                                    command=lambda: self.bus.emit("user_approve_hunk", True),
                                    bg=self.colors['success'], fg='white', width=15)
        self.approve_btn.pack(side='right', padx=10)

    def _wire_signals(self):
        """Links backend signals to display updates."""
        self.bus.subscribe("hunk_ready_for_review", self.display_review_hunk)
        self.bus.subscribe("new_ai_thought", self._on_new_thought)

    def _on_new_thought(self, data):
        """Updates the Neural Inspector with a thought bubble."""
        self.neural_inspector.add_thought_bubble(
            data['file'], data['chunk_id'], data['content'], 
            data['vector'], data['color']
        )

    def display_review_hunk(self, data):
        """Displays the 'before' and 'after' code for human confirmation."""
        self.review_label.config(text=f"Reviewing: {data['file']} > {data['hunk_name']}")
        
        self.before_txt.delete('1.0', 'end')
        self.before_txt.insert('1.0', data['before'])
        
        self.after_txt.delete('1.0', 'end')
        self.after_txt.insert('1.0', data['after'])
        self.approve_btn.config(state='normal')

    def _on_tidy_click(self):
        selected = self.explorer.get_selected_paths()
        model = self.model_selector.get_selected_model()
        self.bus.emit("start_tidy_process", {"paths": selected, "model": model})

    def launch(self):
        self.shell.launch()

