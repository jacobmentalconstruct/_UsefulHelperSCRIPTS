import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
import json
import urllib.request
import urllib.error
import os
import threading

class LogicInjector:
    def __init__(self, root):
        self.root = root
        self.root.title("_LogicINJECTOR (Threaded + Logs)")
        self.root.geometry("700x650") # Taller for logs
        
        # Variables
        self.origin_path = tk.StringVar()
        self.boiler_path = tk.StringVar()
        self.output_folder = tk.StringVar()
        self.output_name = tk.StringVar()
        self.selected_model = tk.StringVar()

        # Check/Create External Prompt
        self.prompt_file = "injector_prompt.txt"
        self.ensure_prompt_file()

        # UI Layout
        self.create_widgets()
        
        # Load models in background so we don't freeze on start
        threading.Thread(target=self.fetch_models, daemon=True).start()

    def ensure_prompt_file(self):
        """Creates a robust default prompt if missing."""
        if not os.path.exists(self.prompt_file):
            # UPDATED PROMPT based on your error report
            default_prompt = (
                "You are a strict Python Code Repair Agent.\n"
                "TASK: You have a BROKEN file (Origin) and a TEMPLATE file (Boilerplate).\n"
                "You must output a single, runnable Python file.\n\n"
                "STRICT RULES:\n"
                "1. IMPORTS: You MUST combine imports from BOTH files. If 'mp', 'logging', or 'time' appear anywhere, keep them.\n"
                "2. STRUCTURE: Use the BOILERPLATE class structure exactly. Do not flatten the class.\n"
                "3. INJECTION: Paste the ORIGIN logic into the 'execute' method, indented by 8 spaces (inside the class).\n"
                "4. HELPERS: If the boilerplate has methods starting with '_', keep them.\n"
                "5. VERIFICATION: Look at the final code. Are imports missing? Is indentation correct? Fix it before outputting."
            )
            with open(self.prompt_file, "w", encoding="utf-8") as f:
                f.write(default_prompt)

    def create_widgets(self):
        # ... (Standard UI boilerplate) ...
        paddings = {'padx': 10, 'pady': (5, 0)}
        
        tk.Label(self.root, text="1. Origin Logic File:").pack(anchor="w", **paddings)
        frame1 = tk.Frame(self.root); frame1.pack(fill="x", padx=10)
        tk.Entry(frame1, textvariable=self.origin_path).pack(side="left", fill="x", expand=True)
        tk.Button(frame1, text="Browse", command=lambda: self.pick_file(self.origin_path)).pack(side="right")

        tk.Label(self.root, text="2. Boilerplate File:").pack(anchor="w", **paddings)
        frame2 = tk.Frame(self.root); frame2.pack(fill="x", padx=10)
        tk.Entry(frame2, textvariable=self.boiler_path).pack(side="left", fill="x", expand=True)
        tk.Button(frame2, text="Browse", command=lambda: self.pick_file(self.boiler_path)).pack(side="right")

        tk.Label(self.root, text="3. Ollama Model:").pack(anchor="w", **paddings)
        self.model_combo = ttk.Combobox(self.root, textvariable=self.selected_model, state="readonly")
        self.model_combo.pack(fill="x", padx=10)

        tk.Label(self.root, text="4. Output Folder:").pack(anchor="w", **paddings)
        frame4 = tk.Frame(self.root); frame4.pack(fill="x", padx=10)
        tk.Entry(frame4, textvariable=self.output_folder).pack(side="left", fill="x", expand=True)
        tk.Button(frame4, text="Browse", command=lambda: self.pick_folder(self.output_folder)).pack(side="right")

        tk.Label(self.root, text="5. Output Filename:").pack(anchor="w", **paddings)
        tk.Entry(self.root, textvariable=self.output_name).pack(fill="x", padx=10)

        # START BUTTON
        self.btn_run = tk.Button(self.root, text="INJECT & SAVE", command=self.start_thread, bg="#dddddd", height=2)
        self.btn_run.pack(fill="x", padx=10, pady=15)

        # LOGGING WINDOW
        tk.Label(self.root, text="Process Log:").pack(anchor="w", padx=10)
        self.log_window = scrolledtext.ScrolledText(self.root, height=12, state='disabled', font=("Consolas", 9))
        self.log_window.pack(fill="both", expand=True, padx=10, pady=5)

    # --- Helper Functions ---
    def log(self, message):
        """Thread-safe logging to the text window."""
        def _append():
            self.log_window.config(state='normal')
            self.log_window.insert(tk.END, message + "\n")
            self.log_window.see(tk.END)
            self.log_window.config(state='disabled')
        self.root.after(0, _append)

    def pick_file(self, var):
        f = filedialog.askopenfilename()
        if f: var.set(f)
    
    def pick_folder(self, var):
        f = filedialog.askdirectory()
        if f: var.set(f)

    def fetch_models(self):
        try:
            with urllib.request.urlopen("http://localhost:11434/api/tags") as r:
                data = json.loads(r.read().decode())
                models = [m['name'] for m in data['models']]
                self.root.after(0, lambda: self.model_combo.config(values=models))
                if models: self.root.after(0, lambda: self.model_combo.current(0))
                self.log(f"Connected to Ollama. Found {len(models)} models.")
        except:
            self.log("Error: Could not auto-fetch models. Is Ollama running?")

    # --- Threading Logic ---
    def start_thread(self):
        """Starts the injection in a background thread."""
        if not all([self.origin_path.get(), self.boiler_path.get(), self.output_folder.get(), self.output_name.get()]):
            messagebox.showerror("Error", "All fields are required.")
            return
        
        self.btn_run.config(state="disabled", text="Running...")
        self.log_window.config(state='normal'); self.log_window.delete(1.0, tk.END); self.log_window.config(state='disabled')
        
        # Launch the heavy lifting in a separate thread
        threading.Thread(target=self.run_injection, daemon=True).start()

    def run_injection(self):
        try:
            self.log("--- Starting Injection Process ---")
            
            # 1. Read Files
            self.log(f"Reading Origin: {os.path.basename(self.origin_path.get())}")
            with open(self.origin_path.get(), 'r', encoding='utf-8', errors='ignore') as f: 
                origin_content = f.read()
            
            self.log(f"Reading Boilerplate: {os.path.basename(self.boiler_path.get())}")
            with open(self.boiler_path.get(), 'r', encoding='utf-8', errors='ignore') as f: 
                boiler_content = f.read()
            
            self.log("Reading Prompt Instructions...")
            with open(self.prompt_file, 'r', encoding='utf-8') as f:
                system_prompt_text = f.read()

            # 2. Build Payload
            user_prompt = (
                f"==== BOILERPLATE (PRESERVE IMPORTS & STRUCTURE) ====\n{boiler_content}\n\n"
                f"==== LOGIC TO INJECT ====\n{origin_content}"
            )

            payload = {
                "model": self.selected_model.get(),
                "messages": [
                    {"role": "system", "content": system_prompt_text},
                    {"role": "user", "content": user_prompt}
                ],
                "stream": False,
                "options": {
                    "temperature": 0.1, 
                    "num_ctx": 8192
                } 
            }

            self.log(f"Sending to Ollama ({self.selected_model.get()})...")
            self.log("Waiting for generation (this might take 30-60s)...")

            # 3. Network Request
            req = urllib.request.Request("http://localhost:11434/api/chat", 
                                         data=json.dumps(payload).encode('utf-8'), 
                                         headers={'Content-Type': 'application/json'})
            
            with urllib.request.urlopen(req) as response:
                result = json.loads(response.read().decode('utf-8'))
                generated_code = result['message']['content']
                
                self.log("Received response from Ollama.")
                self.log(f"Generated {len(generated_code)} characters.")

                # Cleanup Markdown
                if generated_code.startswith("```"):
                    lines = generated_code.splitlines()
                    # Remove first line (```python) and last line (```)
                    generated_code = "\n".join(lines[1:-1]) if lines[-1].strip() == "```" else "\n".join(lines[1:])
                
                # 4. Save
                final_path = os.path.join(self.output_folder.get(), self.output_name.get())
                with open(final_path, 'w', encoding='utf-8') as f:
                    f.write(generated_code)
                
                self.log(f"SUCCESS: Saved to {final_path}")
                self.root.after(0, lambda: messagebox.showinfo("Success", "Injection Complete!"))

        except Exception as e:
            self.log(f"CRITICAL ERROR: {str(e)}")
            print(e)
        finally:
            self.root.after(0, lambda: self.btn_run.config(state="normal", text="INJECT & SAVE"))

if __name__ == "__main__":
    root = tk.Tk()
    app = LogicInjector(root)
    root.mainloop()