#!/usr/bin/env python3
"""
sync-ms-deps.py

Crawls a microservice directory and updates each *_MS.py file to keep two kinds of deps:
  - internal_dependencies: local modules/services that must be vendored with the app
  - external_dependencies: third-party pip packages (requirements.txt)

It does NOT import/execute microservices. Uses AST only.

Usage:
  python sync_microservice_deps.py path/to/microservices --fix
  python sync_microservice_deps.py . --fix --write-requirements requirements.txt
  python sync_microservice_deps.py . --report-only

Notes:
- "internal" deps are module names, not filenames (e.g. "base_service", "microservice_std_lib").
- Stdlib imports are ignored.
- Relative imports are treated as internal when they resolve to local modules.
"""

from __future__ import annotations

import ast
import argparse
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

# ---------------------------
# Configuration knobs
# ---------------------------

MICROSERVICE_GLOB = "*MS.py"      # adjust if you use *_MS.py etc.
PY_GLOB = "*.py"

# A lightweight stdlib allowlist. We also use sys.stdlib_module_names when available.
FALLBACK_STDLIB: Set[str] = {
    "os", "sys", "json", "re", "math", "time", "datetime", "pathlib", "typing",
    "queue", "threading", "subprocess", "shutil", "hashlib", "logging",
    "itertools", "functools", "collections", "dataclasses", "traceback",
    "sqlite3", "tempfile", "inspect", "enum", "random", "string", "statistics",
    "textwrap", "base64", "csv", "pickle", "copy", "pprint", "platform",
    "urllib", "http", "email", "unittest"
}

# If a class inherits from BaseService, we can infer it needs base_service.
INHERITANCE_TO_INTERNAL_MODULE = {
    "BaseService": "base_service",
}

# Keys to enforce in @service_metadata(...)
META_KEY_INTERNAL = "internal_dependencies"
META_KEY_EXTERNAL = "external_dependencies"


# ---------------------------
# Helpers
# ---------------------------

def get_stdlib_names() -> Set[str]:
    try:
        import sys
        # Python 3.10+ provides stdlib_module_names (frozenset)
        names = set(getattr(sys, "stdlib_module_names", []))
        return names | FALLBACK_STDLIB
    except Exception:
        return set(FALLBACK_STDLIB)


def module_root(mod: str) -> str:
    # "foo.bar.baz" -> "foo"
    return mod.split(".")[0].strip()


@dataclass
class FileDeps:
    internal: Set[str]
    external: Set[str]
    declared_internal: Set[str]
    errors: List[str]


# ---------------------------
# AST Extraction
# ---------------------------

class DepVisitor(ast.NodeVisitor):
    def __init__(self) -> None:
        self.imports: Set[str] = set()
        self.from_imports: Set[str] = set()
        self.base_names: Set[str] = set()
        self.declared_dependencies: Set[str] = set()  # from DEPENDENCIES = [...]

    def visit_Import(self, node: ast.Import) -> None:
        for alias in node.names:
            if alias.name:
                self.imports.add(alias.name)
        self.generic_visit(node)

    def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
        # node.module can be None for "from . import x"
        if node.module:
            self.from_imports.add(node.module)
        else:
            # relative without module; treat as unknown internal signal
            self.from_imports.add("")
        self.generic_visit(node)

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        for base in node.bases:
            # base can be Name, Attribute, Subscript, Call, etc.
            name = None
            if isinstance(base, ast.Name):
                name = base.id
            elif isinstance(base, ast.Attribute):
                # Something.BaseService -> BaseService
                name = base.attr
            if name:
                self.base_names.add(name)
        self.generic_visit(node)

    def visit_Assign(self, node: ast.Assign) -> None:
        # Detect: DEPENDENCIES = [...]/set([...])/{...}
        for t in node.targets:
            if isinstance(t, ast.Name) and t.id == "DEPENDENCIES":
                extracted = extract_string_collection(node.value)
                if extracted:
                    self.declared_dependencies |= extracted
        self.generic_visit(node)


def extract_string_collection(expr: ast.AST) -> Set[str]:
    """
    Extract {"a","b"} or ["a","b"] or set(["a","b"]) etc into a set of strings.
    Returns empty set if not parseable.
    """
    out: Set[str] = set()

    def add_str(node: ast.AST) -> None:
        if isinstance(node, ast.Constant) and isinstance(node.value, str):
            s = node.value.strip()
            if s:
                out.add(s)

    if isinstance(expr, (ast.List, ast.Tuple, ast.Set)):
        for elt in expr.elts:
            add_str(elt)
        return out

    if isinstance(expr, ast.Call) and isinstance(expr.func, ast.Name) and expr.func.id in {"set", "list", "tuple"}:
        if expr.args:
            arg0 = expr.args[0]
            return extract_string_collection(arg0)

    if isinstance(expr, ast.Dict):
        # allow {"a": True, "b": True} style
        for k in expr.keys:
            if k is not None:
                add_str(k)
        return out

    return out


# ---------------------------
# Metadata rewrite for @service_metadata(...)
# ---------------------------

class ServiceMetadataRewriter(ast.NodeTransformer):
    """
    Finds @service_metadata(...) decorator and ensures it contains/updates:
      internal_dependencies=[...]
      external_dependencies=[...]
    """
    def __init__(self, internal: List[str], external: List[str]) -> None:
        self.internal = internal
        self.external = external
        self.touched = False

    def visit_ClassDef(self, node: ast.ClassDef) -> ast.AST:
        if not node.decorator_list:
            return node

        new_decorators = []
        for dec in node.decorator_list:
            new_decorators.append(self._rewrite_decorator(dec))
        node.decorator_list = new_decorators
        return node

    def _rewrite_decorator(self, dec: ast.AST) -> ast.AST:
        # match: @service_metadata(...)
        if isinstance(dec, ast.Call):
            func = dec.func
            if isinstance(func, ast.Name) and func.id == "service_metadata":
                # rewrite keyword args
                kw_map: Dict[str, ast.keyword] = {kw.arg: kw for kw in dec.keywords if kw._
